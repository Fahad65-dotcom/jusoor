from PIL import Image, ImageDraw, ImageFont
import os
APP='/home/user/workspace/jusoor_app'
TEAL=(62,142,138); TEALD=(44,110,106); TEALS=(220,237,235); SAND=(247,243,236)
INK=(46,58,64); APR=(233,179,132); WHITE=(255,255,255); SKY=(127,167,201); SAGE=(141,191,154)

def owl(d, x0,y0,w,h, mood='calm', body=TEAL, dark=TEALD, belly=TEALS):
    X=lambda f:x0+w*f; Y=lambda f:y0+h*f
    d.polygon([(X(.22),Y(.30)),(X(.26),Y(.08)),(X(.42),Y(.22))],fill=body)
    d.polygon([(X(.78),Y(.30)),(X(.74),Y(.08)),(X(.58),Y(.22))],fill=body)
    d.ellipse([X(.08),Y(.48),X(.26),Y(.80)],fill=dark)
    d.ellipse([X(.74),Y(.48),X(.92),Y(.80)],fill=dark)
    d.rounded_rectangle([X(.16),Y(.16),X(.84),Y(.96)],radius=w*.34,fill=body)
    d.ellipse([X(.30),Y(.52),X(.70),Y(.90)],fill=belly)
    for x in (.36,.64):
        r=w*.13; d.ellipse([X(x)-r,Y(.38)-r,X(x)+r,Y(.38)+r],fill=WHITE)
        if mood=='happy':
            r2=w*.06; d.arc([X(x)-r2,Y(.40)-r2,X(x)+r2,Y(.40)+r2],195,345,fill=INK,width=int(w*.035))
        else:
            r2=w*.055; d.ellipse([X(x)-r2,Y(.39)-r2,X(x)+r2,Y(.39)+r2],fill=INK)
            r3=w*.018; d.ellipse([X(x+.02)-r3,Y(.37)-r3,X(x+.02)+r3,Y(.37)+r3],fill=WHITE)
    d.polygon([(X(.45),Y(.50)),(X(.55),Y(.50)),(X(.50),Y(.58))],fill=APR)
    d.ellipse([X(.36),Y(.92),X(.46),Y(.98)],fill=APR); d.ellipse([X(.54),Y(.92),X(.64),Y(.98)],fill=APR)

def jusoor_icon(S=1024, bg=True, fg_scale=1.0):
    im=Image.new('RGBA',(S,S),SAND+(255,) if bg else (0,0,0,0)); d=ImageDraw.Draw(im)
    c=S/2
    d.ellipse([S*.12,S*.12,S*.88,S*.88],fill=TEALS)
    # جسر مقوس يصل بين فقاعتي الكلام
    d.arc([S*.22,S*.715,S*.78,S*1.02],180,360,fill=TEALD,width=int(S*.035))
    b=S*.15
    d.rounded_rectangle([S*.14,S*.30,S*.14+b*1.25,S*.30+b],radius=b*.45,fill=SKY)
    d.polygon([(S*.20,S*.30+b-4),(S*.26,S*.30+b-4),(S*.19,S*.30+b*1.35)],fill=SKY)
    d.rounded_rectangle([S*.86-b*1.25,S*.30,S*.86,S*.30+b],radius=b*.45,fill=SAGE)
    d.polygon([(S*.80,S*.30+b-4),(S*.74,S*.30+b-4),(S*.81,S*.30+b*1.35)],fill=SAGE)
    ow=S*.44; owl(d,c-ow/2,S*.28,ow,ow*1.02,mood='happy')
    return im

def save_png(im,path,size):
    os.makedirs(os.path.dirname(path),exist_ok=True)
    im.resize((size,size),Image.LANCZOS).save(path)

big=jusoor_icon(2048)
big.resize((1024,1024),Image.LANCZOS).save('jusoor_icon_1024.png')
big.convert('RGB').resize((1024,1024),Image.LANCZOS).save(APP+'/assets/brand/icon_1024.png')
big.resize((512,512),Image.LANCZOS).save('play_icon_512.png')
# logo transparent
lg=jusoor_icon(2048,bg=False); lg.resize((512,512),Image.LANCZOS).save(APP+'/assets/brand/logo.png')
# Android legacy mipmaps
res=APP+'/android/app/src/main/res'
for n,s in {'mdpi':48,'hdpi':72,'xhdpi':96,'xxhdpi':144,'xxxhdpi':192}.items():
    m=Image.new('RGBA',(2048,2048),(0,0,0,0)); mask=Image.new('L',(2048,2048),0)
    ImageDraw.Draw(mask).rounded_rectangle([0,0,2047,2047],radius=420,fill=255)
    m.paste(big,(0,0),mask); save_png(m,f'{res}/mipmap-{n}/ic_launcher.png',s)
    # adaptive foreground 108dp: content within 72dp safe zone
    fg=Image.new('RGBA',(2048,2048),(0,0,0,0)); inner=jusoor_icon(2048,bg=False).resize((1365,1365),Image.LANCZOS)
    fg.paste(inner,((2048-1365)//2,(2048-1365)//2),inner)
    save_png(fg,f'{res}/mipmap-{n}/ic_launcher_foreground.png',int(s*108/48))
os.makedirs(res+'/mipmap-anydpi-v26',exist_ok=True)
open(res+'/mipmap-anydpi-v26/ic_launcher.xml','w').write('''<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_background"/>
    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>
</adaptive-icon>
''')
os.makedirs(res+'/values',exist_ok=True)
open(res+'/values/ic_launcher_background.xml','w').write('''<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="ic_launcher_background">#F7F3EC</color>
</resources>
''')
# iOS AppIcon: replace each png in place with same dims (no alpha)
ios=APP+'/ios/Runner/Assets.xcassets/AppIcon.appiconset'
rgb=big.convert('RGB')
for f in os.listdir(ios):
    if f.endswith('.png'):
        sz=Image.open(os.path.join(ios,f)).size[0]
        rgb.resize((sz,sz),Image.LANCZOS).save(os.path.join(ios,f))
print('done')
