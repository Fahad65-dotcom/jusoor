from PIL import Image, ImageDraw, ImageFont
from brand import jusoor_icon, owl, SAND, TEAL, TEALD, TEALS, INK, APR, WHITE, SKY, SAGE
F='/home/user/workspace/jusoor_app/assets/fonts/Tajawal-'
def font(w,s): return ImageFont.truetype(F+w+'.ttf',s,layout_engine=ImageFont.Layout.RAQM)
S=1024
def nutqi():
    im=Image.new('RGBA',(S,S),(243,247,242,255)); d=ImageDraw.Draw(im)
    d.rounded_rectangle([170,170,854,700],radius=230,fill=(141,191,154))
    d.polygon([(330,690),(470,690),(300,860)],fill=(141,191,154))
    # sprout
    d.line([(512,600),(512,400)],fill=(60,120,80),width=28)
    d.ellipse([360,300,512,420],fill=(80,150,100)); d.ellipse([512,260,680,400],fill=(100,170,115))
    # turtle small
    d.ellipse([600,560,780,680],fill=(127,167,201)); d.ellipse([760,580,830,640],fill=(127,167,201))
    d.ellipse([795,595,812,612],fill=INK)
    return im
def kalimati():
    im=Image.new('RGBA',(S,S),(251,240,228,255)); d=ImageDraw.Draw(im)
    # puzzle piece
    d.rounded_rectangle([200,300,620,720],radius=60,fill=(233,179,132))
    d.ellipse([360,220,460,320],fill=(233,179,132)); d.ellipse([570,460,670,560],fill=(233,179,132))
    # bubble
    d.rounded_rectangle([520,180,840,420],radius=110,fill=(127,167,201))
    d.polygon([(600,410),(690,410),(570,500)],fill=(127,167,201))
    # camel hint: humps
    d.ellipse([260,560,380,660],fill=(190,130,90)); d.ellipse([360,540,480,660],fill=(190,130,90))
    d.rectangle([260,610,560,660],fill=(190,130,90)); d.ellipse([520,520,600,600],fill=(190,130,90))
    d.ellipse([560,545,575,560],fill=INK)
    return im
tiles=[(jusoor_icon(S),'جسور','Jusoor','بومة «سَنا» على جسر بين فقاعتي كلام','الهوية المعتمدة مبدئيًا'),
       (nutqi(),'نُطقي','Nutqi','فقاعة كلام ينبت منها برعم مع سلحفاة هادئة',''),
       (kalimati(),'كلمتي','Kalimati','قطعة أحجية وفقاعة كلام مع جمل صغير','')]
W=1800; H=820; sheet=Image.new('RGB',(W,H),(255,255,255)); d=ImageDraw.Draw(sheet)
d.text((W/2,50),'ثلاثة مقترحات للهوية',font=font('Bold',54),fill=INK,anchor='mm',direction='rtl')
for i,(im,ar,en,desc,tag) in enumerate(tiles):
    x=W-(i+1)*600+60  # RTL: first on right
    sheet.paste(im.convert('RGB').resize((480,480),Image.LANCZOS),(x,110))
    d.text((x+240,630),ar,font=font('Bold',56),fill=TEALD,anchor='mm',direction='rtl')
    d.text((x+240,690),en,font=font('Medium',34),fill=(107,122,128),anchor='mm')
    d.text((x+240,740),desc,font=font('Regular',26),fill=INK,anchor='mm',direction='rtl')
    if tag: d.text((x+240,785),tag,font=font('Bold',26),fill=TEAL,anchor='mm',direction='rtl')
sheet.save('brand_proposals.png')
