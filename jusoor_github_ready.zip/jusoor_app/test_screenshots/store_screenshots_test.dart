// يولّد لقطات المتجر من الواجهات الفعلية للتطبيق.
// التشغيل: flutter test test_screenshots --update-goldens
// ملاحظة: بيانات التقدم في اللقطات توضيحية لأغراض صفحة المتجر فقط.
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:jusoor/core/app_state.dart';
import 'package:jusoor/data/models.dart';
import 'package:jusoor/data/repository.dart';
import 'package:jusoor/features/child/session_screen.dart';
import 'package:jusoor/features/home/home_screen.dart';
import 'package:jusoor/features/parent/child_hub.dart';
import 'package:jusoor/features/shared/dashboard.dart';
import 'package:jusoor/features/specialist/target_editor.dart';

import '../test/support/harness.dart';

class Device {
  final String name;
  final Size px;
  final double dpr;
  const Device(this.name, this.px, this.dpr);
}

const devices = [
  Device('iphone_6.9', Size(1320, 2868), 3),
  Device('ipad_13', Size(2064, 2752), 2),
  Device('android_phone', Size(1080, 2400), 2.625),
  Device('android_tablet', Size(2560, 1600), 2),
];

Future<void> seedProgress(AppState s, Child c) async {
  final repo = s.repo;
  final targets = await repo.targets(c.id);
  final rng = Random(7);
  final now = DateTime.now();
  for (final t in targets.where((t) => t.skillId == 'listener' || t.skillId == 'matching' || t.skillId == 'mand')) {
    final items = await repo.resolveTargetItems(t);
    if (items.length < 2) continue;
    for (var d = 0; d < 6; d++) {
      final sess = await repo.startSession(childId: c.id, targetId: t.id, trainerName: d.isEven ? 'الأم' : 'الأب', plannedMinutes: 6);
      final day = now.subtract(Duration(days: 12 - d * 2)).millisecondsSinceEpoch;
      await repo.db.update('sessions', {'started_at': day, 'ended_at': day + 360000}, where: 'id=?', whereArgs: [sess.id]);
      final pIndep = 0.35 + d * 0.11;
      for (var n = 1; n <= 10; n++) {
        final indep = rng.nextDouble() < pIndep;
        final correct = indep || rng.nextDouble() < 0.8;
        final it = items[rng.nextInt(items.length)];
        await repo.insertTrial(
          TrialRecord(
            id: newId(), sessionId: sess.id, childId: c.id, targetId: t.id, skillId: t.skillId, trialNumber: n,
            stimulusItemId: it.id, stimulusLabel: it.labelAr, choiceItemIds: [it.id], fieldSize: t.skillId == 'mand' ? 1 : 3,
            promptCode: indep ? 'independent' : 'partial', isCorrection: false,
            outcome: correct ? TrialOutcome.correct : TrialOutcome.incorrect, independent: indep && correct,
            selectedItemId: it.id, latencyMs: 900 + rng.nextInt(2500), presentedAt: day + n * 30000, scoredBy: 'auto',
          ),
          const [],
        );
      }
      await repo.endSession(sess.id, 'completed');
    }
  }
}

void main() {
  setUpAll(() async {
    mockPlatformChannels();
    await loadFonts();
  });

  for (final dev in devices) {
    Future<(AppState, Child)> setup(WidgetTester t) async {
      t.view.physicalSize = dev.px;
      t.view.devicePixelRatio = dev.dpr;
      final s = (await t.runAsync(newState))!;
      final c = (await t.runAsync(() async {
        await s.createUser(UserRole.parent, 'أم سارة', '2468');
        await s.createUser(UserRole.specialist, 'أ. نورة', '1357');
        final c = await s.repo.createChild(name: 'سارة', birthDate: DateTime(2022, 3, 1));
        return c;
      }))!;
      return (s, c);
    }

    Future<void> shot(WidgetTester t, String name) async {
      await expectLater(find.byType(MaterialApp), matchesGoldenFile('../store/screenshots/${dev.name}/$name.png'));
    }

    testWidgets('${dev.name}: الرئيسية', (t) async {
      final (s, _) = await setup(t);
      await t.pumpWidget(wrap(s, const HomeScreen()));
      await settle(t);
      await shot(t, '1_home');
      t.view.reset();
    });

    Future<void> session(WidgetTester t, String skillId, String name) async {
      final (s, c) = await setup(t);
      final target = (await t.runAsync(() => s.repo.targets(c.id)))!.firstWhere((x) => x.skillId == skillId);
      final skill = (await t.runAsync(() => s.repo.skills()))!.firstWhere((x) => x.id == skillId);
      await t.pumpWidget(wrap(s, ChildSessionScreen(child: c, target: target, skill: skill, trainerName: 'الأم', minutes: 6, random: Random(5))));
      await settle(t);
      await t.tap(find.byIcon(Icons.play_arrow_rounded));
      await settle(t);
      await t.pump(const Duration(milliseconds: 800));
      await shot(t, name);
      await t.pumpWidget(const SizedBox());
      await settle(t);
      t.view.reset();
    }

    testWidgets('${dev.name}: جلسة الاستماع', (t) => session(t, 'listener', '2_listener'));
    testWidgets('${dev.name}: جلسة المطابقة', (t) => session(t, 'matching', '3_matching'));

    testWidgets('${dev.name}: مساحة ولي الأمر', (t) async {
      final (s, c) = await setup(t);
      await t.runAsync(() => seedProgress(s, c));
      await t.pumpWidget(wrap(s, ChildHub(child: c, onChanged: () {})));
      await settle(t, rounds: 10);
      await t.tap(find.text('الجلسات').last);
      await settle(t, rounds: 10);
      await shot(t, '4_parent');
      t.view.reset();
    });

    testWidgets('${dev.name}: لوحة التقدم', (t) async {
      final (s, c) = await setup(t);
      await t.runAsync(() => seedProgress(s, c));
      await t.pumpWidget(wrap(s, Scaffold(appBar: AppBar(title: const Text('تقدم سارة')), body: ProgressDashboard(childId: c.id))));
      await settle(t, rounds: 10);
      await shot(t, '5_progress');
      t.view.reset();
    });

    testWidgets('${dev.name}: ضبط الهدف للأخصائي', (t) async {
      final (s, c) = await setup(t);
      final target = (await t.runAsync(() => s.repo.targets(c.id)))!.firstWhere((x) => x.skillId == 'listener');
      await t.pumpWidget(wrap(s, TargetEditorScreen(targetId: target.id)));
      await settle(t);
      await t.drag(find.byType(ListView).first, const Offset(0, -500));
      await settle(t);
      await shot(t, '6_specialist');
      t.view.reset();
    });
  }
}
