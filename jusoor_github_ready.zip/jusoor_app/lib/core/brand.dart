/// الهوية البصرية. الاسم المعتمد مؤقتًا «جسور — Jusoor» ويمكن تغييره من هنا
/// (مع ملفات Android/iOS واسم الحزمة) بعد اختيار الهوية النهائية.
library;

import 'package:flutter/material.dart';

class Brand {
  static const nameAr = 'جسور';
  static const nameEn = 'Jusoor';
  static const taglineAr = 'جسور التواصل لطفلك';
  static const mascotName = 'سَنا';

  // لوحة ألوان هادئة منخفضة التشبع.
  static const teal = Color(0xFF3E8E8A);
  static const tealDark = Color(0xFF2C6E6A);
  static const tealSoft = Color(0xFFDCEDEB);
  static const sand = Color(0xFFF7F3EC);
  static const sky = Color(0xFF7FA7C9);
  static const skySoft = Color(0xFFE3EDF6);
  static const sage = Color(0xFF8DBF9A);
  static const sageSoft = Color(0xFFE5F1E8);
  static const apricot = Color(0xFFE9B384);
  static const apricotSoft = Color(0xFFFBEBDD);
  static const ink = Color(0xFF2E3A40);
  static const muted = Color(0xFF6B7A80);
  static const line = Color(0xFFE4DED4);

  static const disclaimerAr =
      'جسور أداة مساندة للجلسات العلاجية والتعليمية، وليس بديلًا عن الأخصائي أو التقييم المتخصص.';
}
