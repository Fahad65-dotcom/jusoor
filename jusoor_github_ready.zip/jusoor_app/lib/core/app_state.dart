/// الحالة العامة للتطبيق: فتح قاعدة البيانات المشفرة، الأدوار، النسخ
/// الاحتياطي والحذف الكامل.
library;

import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite_common/sqlite_api.dart';
import 'package:sqflite_sqlcipher/sqflite.dart' as cipher;

import '../data/database.dart';
import '../data/models.dart';
import '../data/repository.dart';
import '../services/backup_service.dart';
import '../services/media_service.dart';
import '../services/security.dart';

/// دالة فتح قاعدة البيانات قابلة للاستبدال في الاختبارات.
typedef DbOpener = Future<Database> Function(
    String path, String password, OpenDatabaseOptions options);

Future<Database> _cipherOpener(
        String path, String password, OpenDatabaseOptions o) =>
    cipher.openDatabase(
      path,
      password: password,
      version: o.version,
      onConfigure: o.onConfigure,
      onCreate: o.onCreate,
      onUpgrade: o.onUpgrade,
    );

class AppState extends ChangeNotifier {
  final DbOpener opener;
  final DbKeyStore keys;
  final Future<String> Function()? dbPathOverride;
  AppState({DbOpener? opener, DbKeyStore? keys, this.dbPathOverride})
      : opener = opener ?? _cipherOpener,
        keys = keys ?? DbKeyStore();

  late Database _db;
  late Repository repo;
  late Map<String, dynamic> curriculum;
  bool ready = false;
  bool hasParent = false;

  /// الدور الذي فتح المساحة الحالية (لا يُحفظ؛ ينتهي بإغلاق التطبيق).
  UserRole? unlockedRole;

  Future<String> _dbPath() async => dbPathOverride != null
      ? dbPathOverride!()
      : p.join(await cipher.getDatabasesPath(), 'jusoor.db');

  Future<void> init() async {
    curriculum = jsonDecode(
            await rootBundle.loadString('assets/content/curriculum.json'))
        as Map<String, dynamic>;
    await _open();
    ready = true;
    notifyListeners();
  }

  Future<void> _open() async {
    final key = await keys.getOrCreate();
    _db = await opener(await _dbPath(), key, AppDatabase.options(curriculum));
    repo = Repository(_db);
    hasParent = await repo.hasParent();
  }

  void refresh() => notifyListeners();

  // -------------------------------------------------------------- roles ---

  Future<void> createUser(UserRole role, String name, String pin) async {
    final salt = PinHasher.newSalt();
    final existing = await repo.userByRole(role);
    await repo.upsertUser(AppUser(
      id: existing?.id ?? newId(),
      name: name,
      role: role,
      pinHash: PinHasher.hash(pin, salt),
      pinSalt: salt,
      createdAt: existing?.createdAt ?? nowMs(),
    ));
    hasParent = await repo.hasParent();
    notifyListeners();
  }

  Future<bool> verifyPin(UserRole role, String pin) async {
    final u = await repo.userByRole(role);
    if (u == null) return false;
    return compute(_verify, [pin, u.pinSalt, u.pinHash]);
  }

  /// يقبل رمز ولي الأمر أو الأخصائي (للخروج من وضع الطفل).
  Future<bool> verifyAnyAdult(String pin) async =>
      await verifyPin(UserRole.parent, pin) ||
      await verifyPin(UserRole.specialist, pin);

  static bool _verify(List<String> a) => PinHasher.verify(a[0], a[1], a[2]);

  // ------------------------------------------------------------ backup ---

  Future<Uint8List> exportBackup(String password) async {
    final path = await _dbPath();
    await _db.close();
    try {
      final zip = BackupCodec.pack(
        dbFile: File(path),
        mediaDir: await MediaService.instance.root(),
        dbKey: (await keys.read())!,
        schemaVersion: kSchemaVersion,
      );
      return await BackupCodec.encrypt(zip, password);
    } finally {
      await _open();
    }
  }

  Future<void> restoreBackup(Uint8List data, String password) async {
    final zip = await BackupCodec.decrypt(data, password);
    final path = await _dbPath();
    final oldKey = await keys.read();
    final tmp = File('$path.restore_old');
    await _db.close();
    try {
      if (await File(path).exists()) await File(path).copy(tmp.path);
      final r = BackupCodec.unpack(zip,
          dbFile: File(path), mediaDir: await MediaService.instance.root());
      if (r.schema > kSchemaVersion) {
        throw BackupException('النسخة الاحتياطية من إصدار أحدث من التطبيق');
      }
      await keys.write(r.dbKey);
      await _open();
      if (await tmp.exists()) await tmp.delete();
    } catch (e) {
      // التراجع إلى الحالة السابقة.
      if (await tmp.exists()) await tmp.copy(path);
      if (oldKey != null) await keys.write(oldKey);
      await _open();
      rethrow;
    }
    unlockedRole = null;
    notifyListeners();
  }

  Future<void> deleteChild(String childId) async {
    final files = await repo.deleteChildCompletely(childId);
    await MediaService.instance.deleteFiles(files);
    notifyListeners();
  }

  /// حذف كل بيانات التطبيق (الأطفال والرموز والوسائط) وإعادة التهيئة.
  Future<void> wipeEverything() async {
    final path = await _dbPath();
    await _db.close();
    await cipher.deleteDatabase(path);
    await MediaService.instance.deleteAll();
    await keys.clear();
    unlockedRole = null;
    await _open();
    notifyListeners();
  }
}
