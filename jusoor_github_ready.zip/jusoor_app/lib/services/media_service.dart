/// إدارة ملفات الصور والتسجيلات داخل مجلد التطبيق الخاص (غير مرئي لبقية
/// التطبيقات، ومحمي بتشفير الجهاز وFile Protection على iOS).
library;

import 'dart:io';

import 'package:audioplayers/audioplayers.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:uuid/uuid.dart';

class MediaService {
  MediaService._();
  static final instance = MediaService._();

  Directory? _root;

  Future<Directory> root() async {
    if (_root != null) return _root!;
    final d = await getApplicationSupportDirectory();
    _root = Directory(p.join(d.path, 'media'));
    await _root!.create(recursive: true);
    return _root!;
  }

  /// المسارات تُخزَّن نسبية إلى مجلد الوسائط حتى تعمل بعد الاستعادة.
  Future<String> absolute(String relative) async =>
      p.isAbsolute(relative) ? relative : p.join((await root()).path, relative);

  Future<String> _newRelative(String ext) async {
    final name = '${const Uuid().v4()}.$ext';
    return name;
  }

  /// التقاط صورة بالكاميرا أو اختيارها من المعرض، وحفظ نسخة مصغرة داخليًا.
  Future<String?> pickImage({required bool camera}) async {
    final x = await ImagePicker().pickImage(
      source: camera ? ImageSource.camera : ImageSource.gallery,
      maxWidth: 1024,
      maxHeight: 1024,
      imageQuality: 85,
      requestFullMetadata: false,
    );
    if (x == null) return null;
    final ext = p.extension(x.path).replaceFirst('.', '').toLowerCase();
    final rel = await _newRelative(ext.isEmpty ? 'jpg' : ext);
    await File(x.path).copy(await absolute(rel));
    return rel;
  }

  Future<void> deleteFiles(Iterable<String> relatives) async {
    for (final r in relatives) {
      if (r.startsWith('assets/')) continue;
      try {
        final f = File(await absolute(r));
        if (await f.exists()) await f.delete();
      } catch (_) {}
    }
  }

  Future<void> deleteAll() async {
    final r = await root();
    if (await r.exists()) await r.delete(recursive: true);
    _root = null;
  }
}

/// تسجيل الأصوات البشرية (لا يستخدم التطبيق تحويل النص إلى كلام).
class Recorder {
  final AudioRecorder _rec = AudioRecorder();
  String? _current;

  Future<bool> hasPermission() => _rec.hasPermission();

  Future<bool> start() async {
    if (!await _rec.hasPermission()) return false;
    _current = '${const Uuid().v4()}.m4a';
    await _rec.start(
      const RecordConfig(encoder: AudioEncoder.aacLc, bitRate: 64000, sampleRate: 22050, numChannels: 1),
      path: await MediaService.instance.absolute(_current!),
    );
    return true;
  }

  Future<bool> get isRecording => _rec.isRecording();

  /// يعيد المسار النسبي للتسجيل.
  Future<String?> stop() async {
    await _rec.stop();
    final r = _current;
    _current = null;
    return r;
  }

  Future<void> cancel() async {
    final r = _current;
    await _rec.stop();
    _current = null;
    if (r != null) await MediaService.instance.deleteFiles([r]);
  }

  Future<void> dispose() => _rec.dispose();
}

/// تشغيل الأصوات مع احترام مستوى الصوت الذي يحدده ولي الأمر.
class Sound {
  Sound._();
  static final instance = Sound._();
  final AudioPlayer _voice = AudioPlayer(playerId: 'voice');
  final AudioPlayer _fx = AudioPlayer(playerId: 'fx');
  double volume = 0.8;

  Future<void> playPath(String path, {bool asset = false}) async {
    try {
      await _voice.stop();
      await _voice.setVolume(volume);
      if (asset) {
        await _voice.play(AssetSource(path.replaceFirst('assets/', '')));
      } else {
        await _voice.play(DeviceFileSource(await MediaService.instance.absolute(path)));
      }
      await _voice.onPlayerComplete.first.timeout(const Duration(seconds: 8));
    } catch (_) {}
  }

  /// يشغل عدة مقاطع متتالية (مثل «أين» + «الكرة»).
  Future<void> playSequence(List<(String, bool)> clips) async {
    for (final c in clips) {
      await playPath(c.$1, asset: c.$2);
    }
  }

  Future<void> chime() async {
    try {
      await _fx.stop();
      await _fx.setVolume(volume * 0.6);
      await _fx.play(AssetSource('audio/chime.wav'));
    } catch (_) {}
  }

  Future<void> stop() async {
    await _voice.stop();
    await _fx.stop();
  }
}
