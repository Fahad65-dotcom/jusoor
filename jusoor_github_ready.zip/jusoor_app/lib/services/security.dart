/// الحماية: رموز الدخول لمساحات البالغين ومفتاح تشفير قاعدة البيانات.
library;

import 'dart:convert';
import 'dart:math';

import 'package:crypto/crypto.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class PinHasher {
  static const iterations = 20000;

  static String newSalt() {
    final r = Random.secure();
    return base64Url.encode(List<int>.generate(16, (_) => r.nextInt(256)));
  }

  /// تجزئة متكررة (PBKDF2-HMAC-SHA256 مبسطة) حتى لا يُخزَّن الرمز نفسه.
  static String hash(String pin, String salt) {
    final key = utf8.encode(pin);
    final hmac = Hmac(sha256, key);
    var u = hmac.convert(utf8.encode(salt) + [0, 0, 0, 1]).bytes;
    final out = List<int>.from(u);
    for (var i = 1; i < iterations; i++) {
      u = hmac.convert(u).bytes;
      for (var j = 0; j < out.length; j++) {
        out[j] ^= u[j];
      }
    }
    return base64Url.encode(out);
  }

  static bool verify(String pin, String salt, String expected) {
    final h = hash(pin, salt);
    if (h.length != expected.length) return false;
    var diff = 0;
    for (var i = 0; i < h.length; i++) {
      diff |= h.codeUnitAt(i) ^ expected.codeUnitAt(i);
    }
    return diff == 0;
  }

  static bool isValidPin(String pin) => RegExp(r'^\d{4,6}$').hasMatch(pin);
}

/// مفتاح SQLCipher يُولَّد عشوائيًا عند أول تشغيل ويُحفظ في Keychain/Keystore.
class DbKeyStore {
  static const _k = 'db_key_v1';
  final FlutterSecureStorage _s;
  DbKeyStore([FlutterSecureStorage? s]) : _s = s ?? const FlutterSecureStorage();

  Future<String> getOrCreate() async {
    final existing = await _s.read(key: _k);
    if (existing != null) return existing;
    final r = Random.secure();
    final key = base64Url.encode(List<int>.generate(32, (_) => r.nextInt(256)));
    await _s.write(key: _k, value: key);
    return key;
  }

  Future<String?> read() => _s.read(key: _k);
  Future<void> write(String key) => _s.write(key: _k, value: key);
  Future<void> clear() => _s.delete(key: _k);
}
