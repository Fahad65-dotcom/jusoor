/// قفل وضع الطفل.
///
/// داخل التطبيق: تُمنع العودة ويُخفى شريط النظام، والخروج فقط بضغط مطوّل
/// على زر القفل ثم إدخال رمز البالغ.
/// على Android: يُفعَّل «تثبيت الشاشة» (Lock Task) عبر قناة أصلية.
/// على iOS: لا يسمح النظام للتطبيقات بقفل نفسها؛ يُرشَد ولي الأمر إلى تفعيل
/// «الوصول الموجَّه» (Guided Access) من الإعدادات.
library;

import 'dart:io';

import 'package:flutter/services.dart';

class KioskService {
  static const _ch = MethodChannel('sa.jusoor/kiosk');

  static Future<void> enter() async {
    await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    if (Platform.isAndroid) {
      try {
        await _ch.invokeMethod('startLockTask');
      } catch (_) {}
    }
  }

  static Future<void> exit() async {
    await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    if (Platform.isAndroid) {
      try {
        await _ch.invokeMethod('stopLockTask');
      } catch (_) {}
    }
  }

  /// هل يلزم تنبيه ولي الأمر بتفعيل الوصول الموجه (iOS فقط ولم يُفعَّل بعد)؟
  static Future<bool> shouldSuggestGuidedAccess() async =>
      Platform.isIOS && !(await isGuidedAccessOn());

  /// على iOS: هل الوصول الموجه مفعل؟
  static Future<bool> isGuidedAccessOn() async {
    if (!Platform.isIOS) return false;
    try {
      return (await _ch.invokeMethod<bool>('isGuidedAccessOn')) ?? false;
    } catch (_) {
      return false;
    }
  }
}
