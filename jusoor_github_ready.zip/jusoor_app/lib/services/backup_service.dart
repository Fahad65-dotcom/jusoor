/// النسخ الاحتياطي الاختياري واستعادته.
///
/// الملف الناتج (.jusoor) مشفر بكلمة مرور يختارها ولي الأمر (AES-256-GCM
/// مع اشتقاق المفتاح PBKDF2-HMAC-SHA256)، ويحتوي قاعدة البيانات والوسائط
/// ومفتاح قاعدة البيانات. لا يُرفع إلى أي خادم؛ ولي الأمر يختار مكان حفظه.
library;

import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:archive/archive.dart';
import 'package:cryptography/cryptography.dart';
import 'package:path/path.dart' as p;

const _magic = 'JSR1';

class BackupCodec {
  static const iterations = 120000;

  static Future<SecretKey> _key(String password, List<int> salt) =>
      Pbkdf2(macAlgorithm: Hmac.sha256(), iterations: iterations, bits: 256)
          .deriveKeyFromPassword(password: password, nonce: salt);

  static Future<Uint8List> encrypt(Uint8List plain, String password) async {
    final algo = AesGcm.with256bits();
    final salt = SecretKeyData.random(length: 16).bytes;
    final key = await _key(password, salt);
    final box = await algo.encrypt(plain, secretKey: key);
    return Uint8List.fromList([
      ...ascii.encode(_magic),
      ...salt,
      ...box.concatenation(),
    ]);
  }

  /// يرمي [BackupException] إذا كانت كلمة المرور خاطئة أو الملف تالفًا.
  static Future<Uint8List> decrypt(Uint8List data, String password) async {
    if (data.length < 4 + 16 + 12 + 16 ||
        ascii.decode(data.sublist(0, 4), allowInvalid: true) != _magic) {
      throw BackupException('الملف ليس نسخة احتياطية صالحة');
    }
    final salt = data.sublist(4, 20);
    final algo = AesGcm.with256bits();
    final box = SecretBox.fromConcatenation(data.sublist(20),
        nonceLength: 12, macLength: 16);
    try {
      final key = await _key(password, salt);
      return Uint8List.fromList(await algo.decrypt(box, secretKey: key));
    } on SecretBoxAuthenticationError {
      throw BackupException('كلمة المرور غير صحيحة أو الملف تالف');
    }
  }

  /// يجمع قاعدة البيانات والوسائط في أرشيف واحد.
  static Uint8List pack({
    required File dbFile,
    required Directory mediaDir,
    required String dbKey,
    required int schemaVersion,
  }) {
    final a = Archive();
    a.addFile(ArchiveFile.string('meta.json', jsonEncode({
      'format': 1,
      'schema': schemaVersion,
      'db_key': dbKey,
      'created_at': DateTime.now().toIso8601String(),
    })));
    a.addFile(ArchiveFile.bytes('app.db', dbFile.readAsBytesSync()));
    if (mediaDir.existsSync()) {
      for (final f in mediaDir.listSync(recursive: true).whereType<File>()) {
        final rel = p.relative(f.path, from: mediaDir.path);
        a.addFile(ArchiveFile.bytes('media/$rel', f.readAsBytesSync()));
      }
    }
    return ZipEncoder().encodeBytes(a);
  }

  /// يفك الأرشيف ويعيد مفتاح قاعدة البيانات ونسخة المخطط.
  static ({String dbKey, int schema}) unpack(
    Uint8List zip, {
    required File dbFile,
    required Directory mediaDir,
  }) {
    final a = ZipDecoder().decodeBytes(zip);
    final meta = a.findFile('meta.json');
    final db = a.findFile('app.db');
    if (meta == null || db == null) {
      throw BackupException('النسخة الاحتياطية غير مكتملة');
    }
    final m = jsonDecode(utf8.decode(meta.content)) as Map<String, dynamic>;
    if (mediaDir.existsSync()) mediaDir.deleteSync(recursive: true);
    mediaDir.createSync(recursive: true);
    for (final f in a.files) {
      if (!f.isFile || !f.name.startsWith('media/')) continue;
      final rel = f.name.substring('media/'.length);
      if (rel.contains('..')) continue;
      final out = File(p.join(mediaDir.path, rel));
      out.parent.createSync(recursive: true);
      out.writeAsBytesSync(f.content);
    }
    dbFile.writeAsBytesSync(db.content, flush: true);
    return (dbKey: m['db_key'] as String, schema: m['schema'] as int);
  }
}

class BackupException implements Exception {
  final String message;
  BackupException(this.message);
  @override
  String toString() => message;
}
