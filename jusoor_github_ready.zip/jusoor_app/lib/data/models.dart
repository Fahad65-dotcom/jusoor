/// نماذج البيانات الأساسية للتطبيق.
///
/// كل نموذج يطابق جدولًا في قاعدة البيانات المحلية (انظر `database.dart`).
/// القيم المشتقة (النسب، حالة الإتقان) لا تُخزَّن هنا؛ تُحسب دائمًا من سجلات
/// التجارب الأصلية عبر `engine/metrics.dart` و`engine/mastery.dart`.
library;

int nowMs() => DateTime.now().millisecondsSinceEpoch;

enum UserRole { parent, specialist }

class AppUser {
  final String id;
  final String name;
  final UserRole role;
  final String pinHash;
  final String pinSalt;
  final int createdAt;

  AppUser({
    required this.id,
    required this.name,
    required this.role,
    required this.pinHash,
    required this.pinSalt,
    required this.createdAt,
  });

  factory AppUser.fromMap(Map<String, Object?> m) => AppUser(
        id: m['id'] as String,
        name: m['name'] as String,
        role: UserRole.values.byName(m['role'] as String),
        pinHash: m['pin_hash'] as String,
        pinSalt: m['pin_salt'] as String,
        createdAt: m['created_at'] as int,
      );

  Map<String, Object?> toMap() => {
        'id': id,
        'name': name,
        'role': role.name,
        'pin_hash': pinHash,
        'pin_salt': pinSalt,
        'created_at': createdAt,
      };
}

class Child {
  final String id;
  final String name;
  final DateTime? birthDate;
  final String? photoPath;
  final int createdAt;

  Child({
    required this.id,
    required this.name,
    this.birthDate,
    this.photoPath,
    required this.createdAt,
  });

  /// العمر بالسنوات والأشهر لعرضه للبالغ.
  String get ageLabel {
    if (birthDate == null) return '';
    final now = DateTime.now();
    var months = (now.year - birthDate!.year) * 12 + now.month - birthDate!.month;
    if (now.day < birthDate!.day) months--;
    if (months < 0) months = 0;
    final y = months ~/ 12, m = months % 12;
    if (y == 0) return '$m شهرًا';
    return m == 0 ? '$y سنوات' : '$y سنوات و$m أشهر';
  }

  factory Child.fromMap(Map<String, Object?> m) => Child(
        id: m['id'] as String,
        name: m['name'] as String,
        birthDate: m['birth_date'] == null
            ? null
            : DateTime.tryParse(m['birth_date'] as String),
        photoPath: m['photo_path'] as String?,
        createdAt: m['created_at'] as int,
      );

  Map<String, Object?> toMap() => {
        'id': id,
        'name': name,
        'birth_date': birthDate?.toIso8601String().substring(0, 10),
        'photo_path': photoPath,
        'created_at': createdAt,
      };

  Child copyWith({String? name, DateTime? birthDate, String? photoPath}) =>
      Child(
        id: id,
        name: name ?? this.name,
        birthDate: birthDate ?? this.birthDate,
        photoPath: photoPath ?? this.photoPath,
        createdAt: createdAt,
      );
}

class Skill {
  final String id;
  final String nameAr;
  final String nameEn;
  final String descriptionAr;
  final String engine;
  final int phase;
  final bool enabled;
  final int sort;

  Skill({
    required this.id,
    required this.nameAr,
    required this.nameEn,
    required this.descriptionAr,
    required this.engine,
    required this.phase,
    required this.enabled,
    required this.sort,
  });

  /// المهارات المنفذة في النسخة الأولى.
  bool get isAvailable => phase == 1 && enabled;

  factory Skill.fromMap(Map<String, Object?> m) => Skill(
        id: m['id'] as String,
        nameAr: m['name_ar'] as String,
        nameEn: m['name_en'] as String,
        descriptionAr: (m['description_ar'] as String?) ?? '',
        engine: m['engine'] as String,
        phase: m['phase'] as int,
        enabled: (m['enabled'] as int) == 1,
        sort: m['sort'] as int,
      );
}

class PromptLevelDef {
  final String code;
  final String nameAr;
  final String descriptionAr;
  final int rank;
  final bool enabled;

  PromptLevelDef({
    required this.code,
    required this.nameAr,
    required this.descriptionAr,
    required this.rank,
    required this.enabled,
  });

  factory PromptLevelDef.fromMap(Map<String, Object?> m) => PromptLevelDef(
        code: m['code'] as String,
        nameAr: m['name_ar'] as String,
        descriptionAr: (m['description_ar'] as String?) ?? '',
        rank: m['rank'] as int,
        enabled: (m['enabled'] as int) == 1,
      );
}

enum ImageKind { illustration, photo }

class ItemImage {
  final String id;
  final String itemId;
  final String path;

  /// `asset` للصور المضمنة، `file` للصور التي يضيفها ولي الأمر.
  final String source;
  final ImageKind kind;

  ItemImage({
    required this.id,
    required this.itemId,
    required this.path,
    required this.source,
    required this.kind,
  });

  bool get isAsset => source == 'asset';

  factory ItemImage.fromMap(Map<String, Object?> m) => ItemImage(
        id: m['id'] as String,
        itemId: m['item_id'] as String,
        path: m['path'] as String,
        source: m['source'] as String,
        kind: ImageKind.values.byName(m['kind'] as String),
      );
}

class AudioClip {
  final String id;
  final String? itemId;
  final String? childId;

  /// label: اسم البند، question: سؤال خاص بالبند، praise: تشجيع،
  /// generic: تعليمة عامة (مفتاحها في [key]).
  final String purpose;
  final String? key;
  final String path;
  final String source;

  AudioClip({
    required this.id,
    this.itemId,
    this.childId,
    required this.purpose,
    this.key,
    required this.path,
    required this.source,
  });

  bool get isAsset => source == 'asset';

  factory AudioClip.fromMap(Map<String, Object?> m) => AudioClip(
        id: m['id'] as String,
        itemId: m['item_id'] as String?,
        childId: m['child_id'] as String?,
        purpose: m['purpose'] as String,
        key: m['key'] as String?,
        path: m['path'] as String,
        source: m['source'] as String,
      );
}

/// بند تدريبي (مثير): صورة/صور + اسم + تسجيل صوتي اختياري.
class Item {
  final String id;
  final String labelAr;

  /// object | animal | food | reinforcer | custom
  final String category;
  final String? childId;
  final bool isBuiltin;
  final List<ItemImage> images;
  final AudioClip? labelAudio;
  final AudioClip? questionAudio;
  final Set<String> skillIds;

  Item({
    required this.id,
    required this.labelAr,
    required this.category,
    this.childId,
    required this.isBuiltin,
    this.images = const [],
    this.labelAudio,
    this.questionAudio,
    this.skillIds = const {},
  });

  ItemImage? get illustration =>
      images.where((i) => i.kind == ImageKind.illustration).firstOrNull ??
      images.firstOrNull;

  ItemImage? get photo =>
      images.where((i) => i.kind == ImageKind.photo).firstOrNull;

  /// الصورة المفضلة للعرض: الصورة الحقيقية من بيئة الطفل أولًا إن وجدت.
  ItemImage? get primaryImage => photo ?? illustration;

  static const categoryNames = {
    'object': 'أشياء',
    'animal': 'حيوانات',
    'food': 'أطعمة',
    'reinforcer': 'معززات',
    'custom': 'أخرى',
  };
}

enum PromptOrder { mostToLeast, leastToMost }

enum TargetStatus { active, paused, mastered }

class MasteryCriteria {
  final double percent;
  final int consecutiveSessions;
  final int minTrainers;
  final int minTrialsPerSession;
  final int minDistinctIndependent;

  const MasteryCriteria({
    required this.percent,
    required this.consecutiveSessions,
    this.minTrainers = 1,
    this.minTrialsPerSession = 5,
    this.minDistinctIndependent = 0,
  });

  factory MasteryCriteria.fromMap(Map<String, Object?> m) => MasteryCriteria(
        percent: (m['percent_threshold'] as num).toDouble(),
        consecutiveSessions: m['consecutive_sessions'] as int,
        minTrainers: m['min_trainers'] as int,
        minTrialsPerSession: m['min_trials'] as int,
        minDistinctIndependent: m['min_distinct_independent'] as int,
      );

  Map<String, Object?> toMap(String targetId) => {
        'target_id': targetId,
        'percent_threshold': percent,
        'consecutive_sessions': consecutiveSessions,
        'min_trainers': minTrainers,
        'min_trials': minTrialsPerSession,
        'min_distinct_independent': minDistinctIndependent,
      };

  String get summaryAr {
    final b = StringBuffer(
        '${percent.round()}% استجابات صحيحة مستقلة في $consecutiveSessions جلسات متتالية');
    if (minTrainers > 1) b.write('، وبوجود $minTrainers مدربين على الأقل');
    if (minDistinctIndependent > 0) {
      b.write('، مع طلب $minDistinctIndependent عناصر مختلفة دون تلقين');
    }
    return b.toString();
  }
}

/// هدف تدريبي لطفل محدد، مع إعدادات المحرك التي يضبطها الأخصائي.
class Target {
  final String id;
  final String childId;
  final String skillId;
  final int levelId;
  final String titleAr;
  final String descriptionAr;
  final TargetStatus status;
  final bool enabledForParent;
  final int trialsPerSession;
  final int waitSeconds;
  final List<int> fieldSizes;
  final int advanceAfterCorrect;
  final int stepBackAfterErrors;
  final PromptOrder promptOrder;
  final List<String> promptLadder;
  final String startPrompt;
  final bool carryOverPrompt;
  final int breakAfterErrors;
  final int breakAfterNoResponse;

  /// familiar | reinforcers | with_photo | custom
  final String itemSource;

  /// same | photo_to_illustration (للمطابقة)
  final String sampleKind;
  final String? templateCode;
  final int sort;
  final MasteryCriteria mastery;

  Target({
    required this.id,
    required this.childId,
    required this.skillId,
    required this.levelId,
    required this.titleAr,
    required this.descriptionAr,
    required this.status,
    required this.enabledForParent,
    required this.trialsPerSession,
    required this.waitSeconds,
    required this.fieldSizes,
    required this.advanceAfterCorrect,
    required this.stepBackAfterErrors,
    required this.promptOrder,
    required this.promptLadder,
    required this.startPrompt,
    required this.carryOverPrompt,
    required this.breakAfterErrors,
    required this.breakAfterNoResponse,
    required this.itemSource,
    required this.sampleKind,
    this.templateCode,
    required this.sort,
    required this.mastery,
  });

  factory Target.fromMap(Map<String, Object?> m, MasteryCriteria mastery,
          List<String> ladder) =>
      Target(
        id: m['id'] as String,
        childId: m['child_id'] as String,
        skillId: m['skill_id'] as String,
        levelId: m['level_id'] as int,
        titleAr: m['title_ar'] as String,
        descriptionAr: (m['description_ar'] as String?) ?? '',
        status: TargetStatus.values.byName(m['status'] as String),
        enabledForParent: (m['enabled_for_parent'] as int) == 1,
        trialsPerSession: m['trials_per_session'] as int,
        waitSeconds: m['wait_seconds'] as int,
        fieldSizes: (m['field_sizes'] as String)
            .split(',')
            .where((s) => s.trim().isNotEmpty)
            .map((s) => int.parse(s.trim()))
            .toList(),
        advanceAfterCorrect: m['advance_after_correct'] as int,
        stepBackAfterErrors: m['step_back_after_errors'] as int,
        promptOrder: PromptOrder.values.byName(m['prompt_order'] as String),
        promptLadder: ladder,
        startPrompt: m['start_prompt'] as String,
        carryOverPrompt: (m['carry_over_prompt'] as int) == 1,
        breakAfterErrors: m['break_after_errors'] as int,
        breakAfterNoResponse: m['break_after_no_response'] as int,
        itemSource: m['item_source'] as String,
        sampleKind: (m['sample_kind'] as String?) ?? 'same',
        templateCode: m['template_code'] as String?,
        sort: m['sort'] as int,
        mastery: mastery,
      );

  Map<String, Object?> toMap() => {
        'id': id,
        'child_id': childId,
        'skill_id': skillId,
        'level_id': levelId,
        'title_ar': titleAr,
        'description_ar': descriptionAr,
        'status': status.name,
        'enabled_for_parent': enabledForParent ? 1 : 0,
        'trials_per_session': trialsPerSession,
        'wait_seconds': waitSeconds,
        'field_sizes': fieldSizes.join(','),
        'advance_after_correct': advanceAfterCorrect,
        'step_back_after_errors': stepBackAfterErrors,
        'prompt_order': promptOrder.name,
        'start_prompt': startPrompt,
        'carry_over_prompt': carryOverPrompt ? 1 : 0,
        'break_after_errors': breakAfterErrors,
        'break_after_no_response': breakAfterNoResponse,
        'item_source': itemSource,
        'sample_kind': sampleKind,
        'template_code': templateCode,
        'sort': sort,
      };

  Target copyWith({
    String? titleAr,
    String? descriptionAr,
    TargetStatus? status,
    bool? enabledForParent,
    int? trialsPerSession,
    int? waitSeconds,
    List<int>? fieldSizes,
    int? advanceAfterCorrect,
    int? stepBackAfterErrors,
    PromptOrder? promptOrder,
    List<String>? promptLadder,
    String? startPrompt,
    bool? carryOverPrompt,
    int? breakAfterErrors,
    int? breakAfterNoResponse,
    String? itemSource,
    MasteryCriteria? mastery,
  }) =>
      Target(
        id: id,
        childId: childId,
        skillId: skillId,
        levelId: levelId,
        titleAr: titleAr ?? this.titleAr,
        descriptionAr: descriptionAr ?? this.descriptionAr,
        status: status ?? this.status,
        enabledForParent: enabledForParent ?? this.enabledForParent,
        trialsPerSession: trialsPerSession ?? this.trialsPerSession,
        waitSeconds: waitSeconds ?? this.waitSeconds,
        fieldSizes: fieldSizes ?? this.fieldSizes,
        advanceAfterCorrect: advanceAfterCorrect ?? this.advanceAfterCorrect,
        stepBackAfterErrors: stepBackAfterErrors ?? this.stepBackAfterErrors,
        promptOrder: promptOrder ?? this.promptOrder,
        promptLadder: promptLadder ?? this.promptLadder,
        startPrompt: startPrompt ?? this.startPrompt,
        carryOverPrompt: carryOverPrompt ?? this.carryOverPrompt,
        breakAfterErrors: breakAfterErrors ?? this.breakAfterErrors,
        breakAfterNoResponse: breakAfterNoResponse ?? this.breakAfterNoResponse,
        itemSource: itemSource ?? this.itemSource,
        sampleKind: sampleKind,
        templateCode: templateCode,
        sort: sort,
        mastery: mastery ?? this.mastery,
      );
}

class Reinforcer {
  final String id;
  final String childId;
  final String itemId;
  final bool enabled;
  final int sort;

  Reinforcer({
    required this.id,
    required this.childId,
    required this.itemId,
    required this.enabled,
    required this.sort,
  });

  factory Reinforcer.fromMap(Map<String, Object?> m) => Reinforcer(
        id: m['id'] as String,
        childId: m['child_id'] as String,
        itemId: m['item_id'] as String,
        enabled: (m['enabled'] as int) == 1,
        sort: m['sort'] as int,
      );
}

class SessionRecord {
  final String id;
  final String childId;
  final String targetId;
  final String trainerName;
  final int startedAt;
  final int? endedAt;
  final int plannedMinutes;
  final String? endReason;

  SessionRecord({
    required this.id,
    required this.childId,
    required this.targetId,
    required this.trainerName,
    required this.startedAt,
    this.endedAt,
    required this.plannedMinutes,
    this.endReason,
  });

  Duration get duration => Duration(
      milliseconds: (endedAt ?? startedAt) - startedAt);

  factory SessionRecord.fromMap(Map<String, Object?> m) => SessionRecord(
        id: m['id'] as String,
        childId: m['child_id'] as String,
        targetId: m['target_id'] as String,
        trainerName: (m['trainer_name'] as String?) ?? '',
        startedAt: m['started_at'] as int,
        endedAt: m['ended_at'] as int?,
        plannedMinutes: m['planned_minutes'] as int,
        endReason: m['end_reason'] as String?,
      );
}

enum TrialOutcome { correct, incorrect, noResponse }

/// سجل تجربة منفصلة واحدة كما خُزّن في قاعدة البيانات.
class TrialRecord {
  final String id;
  final String sessionId;
  final String childId;
  final String targetId;
  final String skillId;
  final int trialNumber;
  final String? stimulusItemId;
  final String stimulusLabel;
  final List<String> choiceItemIds;
  final int fieldSize;
  final String promptCode;
  final bool isCorrection;
  final TrialOutcome outcome;
  final bool independent;
  final String? selectedItemId;
  final int? latencyMs;
  final int presentedAt;
  final String scoredBy;
  final String? recordingPath;

  TrialRecord({
    required this.id,
    required this.sessionId,
    required this.childId,
    required this.targetId,
    required this.skillId,
    required this.trialNumber,
    this.stimulusItemId,
    required this.stimulusLabel,
    required this.choiceItemIds,
    required this.fieldSize,
    required this.promptCode,
    required this.isCorrection,
    required this.outcome,
    required this.independent,
    this.selectedItemId,
    this.latencyMs,
    required this.presentedAt,
    required this.scoredBy,
    this.recordingPath,
  });

  bool get isCorrect => outcome == TrialOutcome.correct;

  factory TrialRecord.fromMap(Map<String, Object?> m) => TrialRecord(
        id: m['id'] as String,
        sessionId: m['session_id'] as String,
        childId: m['child_id'] as String,
        targetId: m['target_id'] as String,
        skillId: m['skill_id'] as String,
        trialNumber: m['trial_number'] as int,
        stimulusItemId: m['stimulus_item_id'] as String?,
        stimulusLabel: (m['stimulus_label'] as String?) ?? '',
        choiceItemIds: ((m['choice_item_ids'] as String?) ?? '')
            .split(',')
            .where((s) => s.isNotEmpty)
            .toList(),
        fieldSize: m['field_size'] as int,
        promptCode: m['prompt_code'] as String,
        isCorrection: (m['is_correction'] as int) == 1,
        outcome: _outcomeFrom(m['outcome'] as String),
        independent: (m['independent'] as int) == 1,
        selectedItemId: m['selected_item_id'] as String?,
        latencyMs: m['latency_ms'] as int?,
        presentedAt: m['presented_at'] as int,
        scoredBy: (m['scored_by'] as String?) ?? 'auto',
        recordingPath: m['recording_path'] as String?,
      );

  static TrialOutcome _outcomeFrom(String s) => switch (s) {
        'correct' => TrialOutcome.correct,
        'incorrect' => TrialOutcome.incorrect,
        _ => TrialOutcome.noResponse,
      };

  static String outcomeToDb(TrialOutcome o) => switch (o) {
        TrialOutcome.correct => 'correct',
        TrialOutcome.incorrect => 'incorrect',
        TrialOutcome.noResponse => 'no_response',
      };
}
