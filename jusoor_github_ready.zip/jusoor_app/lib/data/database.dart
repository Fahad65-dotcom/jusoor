/// قاعدة البيانات المحلية (SQLite مشفرة عبر SQLCipher على الأجهزة).
///
/// الكيانات: المستخدمون والأدوار، ملف الطفل، المستويات، المهارات، مستويات
/// التلقين، البنود التدريبية، الصور، التسجيلات الصوتية، ربط البنود بالمهارات،
/// قوالب الأهداف، الأهداف التدريبية، سلم التلقين لكل هدف، بنود كل هدف،
/// معايير الإتقان، المعززات، الجلسات، التجارب، الاستجابات، الإعدادات.
///
/// الترقية: كل تغيير مستقبلي في البنية يضاف كخطوة في [_migrations] مع رفع
/// [kSchemaVersion]، فلا يحتاج التطبيق إلى إعادة بناء قاعدة البيانات.
/// جدول `sync_outbox` مُجهَّز للمزامنة السحابية في المرحلة الثانية ولا
/// يُستخدم في النسخة الأولى.
library;

import 'dart:convert';

import 'package:sqflite_common/sqlite_api.dart';

const int kSchemaVersion = 1;

const List<String> _schemaV1 = [
  '''CREATE TABLE users(
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('parent','specialist')),
    pin_hash TEXT NOT NULL,
    pin_salt TEXT NOT NULL,
    created_at INTEGER NOT NULL)''',
  '''CREATE TABLE children(
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    birth_date TEXT,
    photo_path TEXT,
    created_at INTEGER NOT NULL)''',
  '''CREATE TABLE levels(
    id INTEGER PRIMARY KEY,
    name_ar TEXT NOT NULL,
    enabled INTEGER NOT NULL DEFAULT 1)''',
  '''CREATE TABLE skills(
    id TEXT PRIMARY KEY,
    name_ar TEXT NOT NULL,
    name_en TEXT NOT NULL,
    description_ar TEXT,
    engine TEXT NOT NULL,
    phase INTEGER NOT NULL DEFAULT 1,
    enabled INTEGER NOT NULL DEFAULT 1,
    sort INTEGER NOT NULL DEFAULT 0)''',
  '''CREATE TABLE prompt_levels(
    code TEXT PRIMARY KEY,
    name_ar TEXT NOT NULL,
    description_ar TEXT,
    rank INTEGER NOT NULL,
    enabled INTEGER NOT NULL DEFAULT 1)''',
  '''CREATE TABLE items(
    id TEXT PRIMARY KEY,
    label_ar TEXT NOT NULL,
    category TEXT NOT NULL,
    child_id TEXT REFERENCES children(id) ON DELETE CASCADE,
    is_builtin INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL)''',
  '''CREATE TABLE images(
    id TEXT PRIMARY KEY,
    item_id TEXT NOT NULL REFERENCES items(id) ON DELETE CASCADE,
    path TEXT NOT NULL,
    source TEXT NOT NULL CHECK(source IN ('asset','file')),
    kind TEXT NOT NULL CHECK(kind IN ('illustration','photo')),
    child_id TEXT REFERENCES children(id) ON DELETE CASCADE,
    created_at INTEGER NOT NULL)''',
  '''CREATE TABLE audio_clips(
    id TEXT PRIMARY KEY,
    item_id TEXT REFERENCES items(id) ON DELETE CASCADE,
    child_id TEXT REFERENCES children(id) ON DELETE CASCADE,
    purpose TEXT NOT NULL CHECK(purpose IN ('label','question','praise','generic')),
    key TEXT,
    path TEXT NOT NULL,
    source TEXT NOT NULL CHECK(source IN ('asset','file')),
    created_at INTEGER NOT NULL)''',
  '''CREATE TABLE item_skills(
    item_id TEXT NOT NULL REFERENCES items(id) ON DELETE CASCADE,
    skill_id TEXT NOT NULL REFERENCES skills(id) ON DELETE CASCADE,
    PRIMARY KEY(item_id, skill_id))''',
  '''CREATE TABLE target_templates(
    code TEXT PRIMARY KEY,
    skill_id TEXT NOT NULL REFERENCES skills(id),
    json TEXT NOT NULL)''',
  '''CREATE TABLE targets(
    id TEXT PRIMARY KEY,
    child_id TEXT NOT NULL REFERENCES children(id) ON DELETE CASCADE,
    skill_id TEXT NOT NULL REFERENCES skills(id),
    level_id INTEGER NOT NULL REFERENCES levels(id),
    title_ar TEXT NOT NULL,
    description_ar TEXT,
    status TEXT NOT NULL DEFAULT 'active',
    enabled_for_parent INTEGER NOT NULL DEFAULT 1,
    trials_per_session INTEGER NOT NULL,
    wait_seconds INTEGER NOT NULL,
    field_sizes TEXT NOT NULL,
    advance_after_correct INTEGER NOT NULL DEFAULT 2,
    step_back_after_errors INTEGER NOT NULL DEFAULT 2,
    prompt_order TEXT NOT NULL DEFAULT 'mostToLeast',
    start_prompt TEXT NOT NULL,
    carry_over_prompt INTEGER NOT NULL DEFAULT 1,
    break_after_errors INTEGER NOT NULL DEFAULT 3,
    break_after_no_response INTEGER NOT NULL DEFAULT 3,
    item_source TEXT NOT NULL,
    sample_kind TEXT,
    template_code TEXT,
    sort INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL)''',
  '''CREATE TABLE target_prompt_levels(
    target_id TEXT NOT NULL REFERENCES targets(id) ON DELETE CASCADE,
    prompt_code TEXT NOT NULL REFERENCES prompt_levels(code),
    position INTEGER NOT NULL,
    PRIMARY KEY(target_id, prompt_code))''',
  '''CREATE TABLE target_items(
    target_id TEXT NOT NULL REFERENCES targets(id) ON DELETE CASCADE,
    item_id TEXT NOT NULL REFERENCES items(id) ON DELETE CASCADE,
    PRIMARY KEY(target_id, item_id))''',
  '''CREATE TABLE mastery_criteria(
    target_id TEXT PRIMARY KEY REFERENCES targets(id) ON DELETE CASCADE,
    percent_threshold REAL NOT NULL,
    consecutive_sessions INTEGER NOT NULL,
    min_trainers INTEGER NOT NULL DEFAULT 1,
    min_trials INTEGER NOT NULL DEFAULT 5,
    min_distinct_independent INTEGER NOT NULL DEFAULT 0)''',
  '''CREATE TABLE reinforcers(
    id TEXT PRIMARY KEY,
    child_id TEXT NOT NULL REFERENCES children(id) ON DELETE CASCADE,
    item_id TEXT NOT NULL REFERENCES items(id) ON DELETE CASCADE,
    enabled INTEGER NOT NULL DEFAULT 1,
    sort INTEGER NOT NULL DEFAULT 0,
    UNIQUE(child_id, item_id))''',
  '''CREATE TABLE sessions(
    id TEXT PRIMARY KEY,
    child_id TEXT NOT NULL REFERENCES children(id) ON DELETE CASCADE,
    target_id TEXT NOT NULL REFERENCES targets(id) ON DELETE CASCADE,
    trainer_name TEXT,
    started_at INTEGER NOT NULL,
    ended_at INTEGER,
    planned_minutes INTEGER NOT NULL,
    end_reason TEXT)''',
  '''CREATE TABLE trials(
    id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
    child_id TEXT NOT NULL REFERENCES children(id) ON DELETE CASCADE,
    target_id TEXT NOT NULL REFERENCES targets(id) ON DELETE CASCADE,
    skill_id TEXT NOT NULL,
    trial_number INTEGER NOT NULL,
    stimulus_item_id TEXT,
    stimulus_label TEXT,
    choice_item_ids TEXT,
    field_size INTEGER NOT NULL,
    prompt_code TEXT NOT NULL,
    is_correction INTEGER NOT NULL DEFAULT 0,
    outcome TEXT NOT NULL CHECK(outcome IN ('correct','incorrect','no_response')),
    independent INTEGER NOT NULL,
    latency_ms INTEGER,
    presented_at INTEGER NOT NULL,
    scored_by TEXT NOT NULL DEFAULT 'auto')''',
  '''CREATE TABLE responses(
    id TEXT PRIMARY KEY,
    trial_id TEXT NOT NULL REFERENCES trials(id) ON DELETE CASCADE,
    kind TEXT NOT NULL CHECK(kind IN ('touch','drag','vocal','adult_score','timeout')),
    selected_item_id TEXT,
    recording_path TEXT,
    outcome TEXT,
    prompt_code TEXT,
    latency_ms INTEGER,
    note TEXT,
    created_at INTEGER NOT NULL)''',
  '''CREATE TABLE settings(
    scope TEXT NOT NULL,
    key TEXT NOT NULL,
    value TEXT NOT NULL,
    PRIMARY KEY(scope, key))''',
  '''CREATE TABLE sync_outbox(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    entity TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    op TEXT NOT NULL,
    created_at INTEGER NOT NULL)''',
  'CREATE INDEX idx_trials_target ON trials(target_id, session_id)',
  'CREATE INDEX idx_trials_child ON trials(child_id)',
  'CREATE INDEX idx_sessions_child ON sessions(child_id, started_at)',
  'CREATE INDEX idx_responses_trial ON responses(trial_id)',
  'CREATE INDEX idx_items_child ON items(child_id)',
];

/// خطوات الترقية: المفتاح هو رقم النسخة الهدف.
final Map<int, List<String>> _migrations = {
  // 2: ['ALTER TABLE children ADD COLUMN ...'],
};

class AppDatabase {
  static OpenDatabaseOptions options(Map<String, dynamic> curriculum) =>
      OpenDatabaseOptions(
        version: kSchemaVersion,
        onConfigure: (db) async {
          await db.execute('PRAGMA foreign_keys = ON');
        },
        onCreate: (db, version) async {
          final batch = db.batch();
          for (final s in _schemaV1) {
            batch.execute(s);
          }
          await batch.commit(noResult: true);
          await seedCurriculum(db, curriculum);
        },
        onUpgrade: (db, oldV, newV) async {
          for (var v = oldV + 1; v <= newV; v++) {
            for (final s in _migrations[v] ?? const <String>[]) {
              await db.execute(s);
            }
          }
          // تحديث المحتوى المضمّن دون المساس ببيانات المستخدم.
          await seedCurriculum(db, curriculum);
        },
      );

  /// إدراج/تحديث المحتوى المضمّن من `assets/content/curriculum.json`.
  /// يستخدم INSERT OR IGNORE حتى لا يلغي تعديلات الأخصائي.
  static Future<void> seedCurriculum(
      Database db, Map<String, dynamic> c) async {
    final now = DateTime.now().millisecondsSinceEpoch;
    final batch = db.batch();
    for (final l in c['levels'] as List) {
      batch.rawInsert(
          'INSERT OR IGNORE INTO levels(id,name_ar,enabled) VALUES(?,?,?)',
          [l['id'], l['name_ar'], l['enabled'] == true ? 1 : 0]);
    }
    for (final s in c['skills'] as List) {
      batch.rawInsert(
          'INSERT OR IGNORE INTO skills(id,name_ar,name_en,description_ar,engine,phase,enabled,sort) VALUES(?,?,?,?,?,?,?,?)',
          [
            s['id'],
            s['name_ar'],
            s['name_en'],
            s['description_ar'],
            s['engine'],
            s['phase'],
            1,
            s['sort'],
          ]);
    }
    for (final p in c['prompt_levels'] as List) {
      batch.rawInsert(
          'INSERT OR IGNORE INTO prompt_levels(code,name_ar,description_ar,rank,enabled) VALUES(?,?,?,?,1)',
          [p['code'], p['name_ar'], p['description_ar'], p['rank']]);
    }
    final familiar = (c['familiar_set'] as List).cast<String>().toSet();
    for (final it in c['items'] as List) {
      final key = it['key'] as String;
      final id = 'b_$key';
      final cat = it['category'] as String;
      batch.rawInsert(
          'INSERT OR IGNORE INTO items(id,label_ar,category,child_id,is_builtin,created_at) VALUES(?,?,?,NULL,1,?)',
          [id, it['label_ar'], cat, now]);
      batch.rawInsert(
          "INSERT OR IGNORE INTO images(id,item_id,path,source,kind,child_id,created_at) VALUES(?,?,?,'asset','illustration',NULL,?)",
          ['img_$key', id, 'assets/images/items/$key.png', now]);
      final skills =
          cat == 'reinforcer' ? ['mand'] : ['listener', 'tact', 'matching'];
      for (final s in skills) {
        batch.rawInsert(
            'INSERT OR IGNORE INTO item_skills(item_id,skill_id) VALUES(?,?)',
            [id, s]);
      }
    }
    for (final t in c['target_templates'] as List) {
      batch.rawInsert(
          'INSERT OR REPLACE INTO target_templates(code,skill_id,json) VALUES(?,?,?)',
          [t['code'], t['skill'], jsonEncode(t)]);
    }
    batch.rawInsert(
        "INSERT OR IGNORE INTO settings(scope,key,value) VALUES('global','familiar_set',?)",
        [familiar.map((k) => 'b_$k').join(',')]);
    await batch.commit(noResult: true);
  }
}
