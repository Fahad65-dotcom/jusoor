/// طبقة الوصول إلى البيانات. كل الاستعلامات تمر من هنا حتى يسهل استبدال
/// التخزين أو إضافة المزامنة السحابية لاحقًا (المرحلة الثانية).
library;

import 'dart:convert';

import 'package:sqflite_common/sqlite_api.dart';
import 'package:sqflite_common/utils/utils.dart' show firstIntValue;
import 'package:uuid/uuid.dart';

import 'models.dart';

const _uuid = Uuid();
String newId() => _uuid.v4();

/// مفاتيح التعليمات الصوتية العامة التي يسجلها البالغ.
class GenericAudioKeys {
  static const mandQuestion = 'q_mand'; // ماذا تريد؟
  static const tactQuestion = 'q_tact'; // ما هذا؟
  static const listenerPrefix = 'q_where'; // أين ...؟
  static const matchInstruction = 'q_match'; // طابق
  static const all = {
    mandQuestion: 'ماذا تريد؟',
    tactQuestion: 'ما هذا؟',
    listenerPrefix: 'أين...؟ (تُشغَّل قبل اسم الصورة)',
    matchInstruction: 'طابِق',
  };
}

/// إعدادات الطفل التي يتحكم بها ولي الأمر.
class ChildSettings {
  final int sessionMinutes;
  final int bonusEvery;
  final double volume;
  final bool animations;
  final bool stars;
  final bool successChime;
  final bool praiseVoice;

  const ChildSettings({
    this.sessionMinutes = 7,
    this.bonusEvery = 5,
    this.volume = 0.8,
    this.animations = true,
    this.stars = true,
    this.successChime = true,
    this.praiseVoice = true,
  });

  static ChildSettings fromMap(Map<String, String> m) => ChildSettings(
        sessionMinutes: int.tryParse(m['session_minutes'] ?? '') ?? 7,
        bonusEvery: int.tryParse(m['bonus_every'] ?? '') ?? 5,
        volume: double.tryParse(m['volume'] ?? '') ?? 0.8,
        animations: (m['animations'] ?? '1') == '1',
        stars: (m['stars'] ?? '1') == '1',
        successChime: (m['success_chime'] ?? '1') == '1',
        praiseVoice: (m['praise_voice'] ?? '1') == '1',
      );

  Map<String, String> toMap() => {
        'session_minutes': '$sessionMinutes',
        'bonus_every': '$bonusEvery',
        'volume': '$volume',
        'animations': animations ? '1' : '0',
        'stars': stars ? '1' : '0',
        'success_chime': successChime ? '1' : '0',
        'praise_voice': praiseVoice ? '1' : '0',
      };

  ChildSettings copyWith({
    int? sessionMinutes,
    int? bonusEvery,
    double? volume,
    bool? animations,
    bool? stars,
    bool? successChime,
    bool? praiseVoice,
  }) =>
      ChildSettings(
        sessionMinutes: sessionMinutes ?? this.sessionMinutes,
        bonusEvery: bonusEvery ?? this.bonusEvery,
        volume: volume ?? this.volume,
        animations: animations ?? this.animations,
        stars: stars ?? this.stars,
        successChime: successChime ?? this.successChime,
        praiseVoice: praiseVoice ?? this.praiseVoice,
      );
}

/// استجابة مفردة داخل تجربة (لمس، سحب، صوت، تقييم بالغ، انتهاء المهلة).
class ResponseEvent {
  final String kind;
  final String? selectedItemId;
  final String? recordingPath;
  final TrialOutcome? outcome;
  final String? promptCode;
  final int? latencyMs;
  final String? note;

  const ResponseEvent({
    required this.kind,
    this.selectedItemId,
    this.recordingPath,
    this.outcome,
    this.promptCode,
    this.latencyMs,
    this.note,
  });
}

class Repository {
  final Database db;
  Repository(this.db);

  // ---------------------------------------------------------------- users ---

  Future<bool> hasParent() async =>
      (await db.query('users', where: "role='parent'", limit: 1)).isNotEmpty;

  Future<AppUser?> userByRole(UserRole role) async {
    final r =
        await db.query('users', where: 'role=?', whereArgs: [role.name], limit: 1);
    return r.isEmpty ? null : AppUser.fromMap(r.first);
  }

  Future<void> upsertUser(AppUser u) => db.insert('users', u.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace);

  Future<void> deleteUser(UserRole role) =>
      db.delete('users', where: 'role=?', whereArgs: [role.name]);

  // ------------------------------------------------------------- settings ---

  Future<Map<String, String>> settings(String scope) async {
    final r = await db.query('settings', where: 'scope=?', whereArgs: [scope]);
    return {for (final m in r) m['key'] as String: m['value'] as String};
  }

  Future<void> setSetting(String scope, String key, String value) => db.insert(
      'settings', {'scope': scope, 'key': key, 'value': value},
      conflictAlgorithm: ConflictAlgorithm.replace);

  Future<ChildSettings> childSettings(String childId) async =>
      ChildSettings.fromMap(await settings('child:$childId'));

  Future<void> saveChildSettings(String childId, ChildSettings s) async {
    final b = db.batch();
    s.toMap().forEach((k, v) => b.insert(
        'settings', {'scope': 'child:$childId', 'key': k, 'value': v},
        conflictAlgorithm: ConflictAlgorithm.replace));
    await b.commit(noResult: true);
  }

  // ------------------------------------------------------------- children ---

  Future<List<Child>> children() async =>
      (await db.query('children', orderBy: 'created_at'))
          .map(Child.fromMap)
          .toList();

  Future<Child?> child(String id) async {
    final r = await db.query('children', where: 'id=?', whereArgs: [id]);
    return r.isEmpty ? null : Child.fromMap(r.first);
  }

  /// ينشئ ملف الطفل ويهيئ أهداف النسخة الأولى الافتراضية والمعززات.
  Future<Child> createChild({
    required String name,
    DateTime? birthDate,
    String? photoPath,
  }) async {
    final c = Child(
      id: newId(),
      name: name.trim(),
      birthDate: birthDate,
      photoPath: photoPath,
      createdAt: nowMs(),
    );
    await db.transaction((txn) async {
      await txn.insert('children', c.toMap());
      // المعززات الافتراضية: كل بنود فئة المعززات المضمنة.
      final rein = await txn.query('items',
          where: "category='reinforcer' AND is_builtin=1", orderBy: 'rowid');
      var i = 0;
      for (final r in rein) {
        await txn.insert('reinforcers', {
          'id': newId(),
          'child_id': c.id,
          'item_id': r['id'],
          'enabled': 1,
          'sort': i++,
        });
      }
      final templates = await txn.query('target_templates', orderBy: 'rowid');
      var sort = 0;
      for (final t in templates) {
        await _insertTargetFromTemplate(
            txn, c.id, jsonDecode(t['json'] as String) as Map<String, dynamic>,
            sort: sort++);
      }
      await txn.insert('settings', {
        'scope': 'child:${c.id}',
        'key': 'session_minutes',
        'value': '7',
      });
    });
    return c;
  }

  Future<void> updateChild(Child c) =>
      db.update('children', c.toMap(), where: 'id=?', whereArgs: [c.id]);

  /// يحذف كل بيانات الطفل ويعيد مسارات الملفات (الصور والتسجيلات) التي يجب
  /// حذفها من التخزين.
  Future<List<String>> deleteChildCompletely(String childId) async {
    final paths = <String>[];
    final c = await child(childId);
    if (c?.photoPath != null) paths.add(c!.photoPath!);
    final imgs = await db.rawQuery(
        "SELECT path FROM images WHERE source='file' AND (child_id=? OR item_id IN (SELECT id FROM items WHERE child_id=?))",
        [childId, childId]);
    final auds = await db.rawQuery(
        "SELECT path FROM audio_clips WHERE source='file' AND (child_id=? OR item_id IN (SELECT id FROM items WHERE child_id=?))",
        [childId, childId]);
    final recs = await db.rawQuery(
        'SELECT r.recording_path AS path FROM responses r JOIN trials t ON t.id=r.trial_id WHERE t.child_id=? AND r.recording_path IS NOT NULL',
        [childId]);
    for (final r in [...imgs, ...auds, ...recs]) {
      paths.add(r['path'] as String);
    }
    await db.transaction((txn) async {
      await txn.delete('settings',
          where: 'scope=?', whereArgs: ['child:$childId']);
      // ON DELETE CASCADE يحذف الأهداف والجلسات والتجارب والاستجابات والبنود.
      await txn.delete('children', where: 'id=?', whereArgs: [childId]);
    });
    return paths;
  }

  // --------------------------------------------------- skills & prompts ----

  Future<List<Skill>> skills() async =>
      (await db.query('skills', orderBy: 'sort')).map(Skill.fromMap).toList();

  Future<void> updateSkill(String id, {String? nameAr, bool? enabled}) =>
      db.update(
          'skills',
          {
            'name_ar': ?nameAr,
            if (enabled != null) 'enabled': enabled ? 1 : 0,
          },
          where: 'id=?',
          whereArgs: [id]);

  Future<List<PromptLevelDef>> promptLevels() async =>
      (await db.query('prompt_levels', orderBy: 'rank DESC'))
          .map(PromptLevelDef.fromMap)
          .toList();

  Future<void> updatePromptLevel(String code,
          {String? nameAr, String? description}) =>
      db.update(
          'prompt_levels',
          {
            'name_ar': ?nameAr,
            'description_ar': ?description,
          },
          where: 'code=?',
          whereArgs: [code]);

  Future<List<Map<String, dynamic>>> targetTemplates() async =>
      (await db.query('target_templates', orderBy: 'rowid'))
          .map((r) => jsonDecode(r['json'] as String) as Map<String, dynamic>)
          .toList();

  // ---------------------------------------------------------------- items ---

  /// البنود المتاحة للطفل: المضمنة + الخاصة به.
  Future<List<Item>> items(String? childId) async {
    final rows = await db.query('items',
        where: childId == null ? 'child_id IS NULL' : '(child_id IS NULL OR child_id=?)',
        whereArgs: childId == null ? null : [childId],
        orderBy: 'is_builtin DESC, rowid');
    return _hydrate(rows, childId);
  }

  Future<Item?> item(String id, {String? childId}) async {
    final r = await db.query('items', where: 'id=?', whereArgs: [id]);
    if (r.isEmpty) return null;
    return (await _hydrate(r, childId)).first;
  }

  Future<List<Item>> _hydrate(
      List<Map<String, Object?>> rows, String? childId) async {
    if (rows.isEmpty) return [];
    final ids = rows.map((r) => r['id'] as String).toList();
    final ph = List.filled(ids.length, '?').join(',');
    final imgRows = await db.query('images',
        where: 'item_id IN ($ph) AND (child_id IS NULL OR child_id=?)',
        whereArgs: [...ids, childId ?? ''],
        orderBy: 'created_at');
    final audRows = await db.query('audio_clips',
        where:
            "item_id IN ($ph) AND purpose IN ('label','question') AND (child_id IS NULL OR child_id=?)",
        whereArgs: [...ids, childId ?? ''],
        orderBy: 'created_at');
    final skRows = await db.query('item_skills',
        where: 'item_id IN ($ph)', whereArgs: ids);
    final imgs = <String, List<ItemImage>>{};
    for (final m in imgRows) {
      final i = ItemImage.fromMap(m);
      imgs.putIfAbsent(i.itemId, () => []).add(i);
    }
    final label = <String, AudioClip>{};
    final question = <String, AudioClip>{};
    for (final m in audRows) {
      final a = AudioClip.fromMap(m);
      // الأحدث يغلب (التسجيل الخاص بالطفل بعد المضمن).
      (a.purpose == 'label' ? label : question)[a.itemId!] = a;
    }
    final sk = <String, Set<String>>{};
    for (final m in skRows) {
      sk.putIfAbsent(m['item_id'] as String, () => {}).add(m['skill_id'] as String);
    }
    return [
      for (final r in rows)
        Item(
          id: r['id'] as String,
          labelAr: r['label_ar'] as String,
          category: r['category'] as String,
          childId: r['child_id'] as String?,
          isBuiltin: (r['is_builtin'] as int) == 1,
          images: imgs[r['id']] ?? const [],
          labelAudio: label[r['id']],
          questionAudio: question[r['id']],
          skillIds: sk[r['id']] ?? const {},
        ),
    ];
  }

  Future<String> createItem({
    required String childId,
    required String label,
    required String category,
    required Set<String> skillIds,
  }) async {
    final id = newId();
    await db.transaction((txn) async {
      await txn.insert('items', {
        'id': id,
        'label_ar': label.trim(),
        'category': category,
        'child_id': childId,
        'is_builtin': 0,
        'created_at': nowMs(),
      });
      for (final s in skillIds) {
        await txn.insert('item_skills', {'item_id': id, 'skill_id': s});
      }
    });
    return id;
  }

  Future<void> updateItem(String id,
      {String? label, String? category, Set<String>? skillIds}) async {
    await db.transaction((txn) async {
      final values = {
        if (label != null) 'label_ar': label.trim(),
        'category': ?category,
      };
      if (values.isNotEmpty) {
        await txn.update('items', values, where: 'id=?', whereArgs: [id]);
      }
      if (skillIds != null) {
        await txn.delete('item_skills', where: 'item_id=?', whereArgs: [id]);
        for (final s in skillIds) {
          await txn.insert('item_skills', {'item_id': id, 'skill_id': s});
        }
      }
    });
  }

  /// حذف بند خاص بالطفل. يعيد مسارات الملفات لحذفها.
  Future<List<String>> deleteItem(String id) async {
    final files = [
      ...(await db.query('images',
              columns: ['path'], where: "item_id=? AND source='file'", whereArgs: [id]))
          .map((r) => r['path'] as String),
      ...(await db.query('audio_clips',
              columns: ['path'], where: "item_id=? AND source='file'", whereArgs: [id]))
          .map((r) => r['path'] as String),
    ];
    await db.delete('items', where: 'id=? AND is_builtin=0', whereArgs: [id]);
    return files;
  }

  Future<void> addImage({
    required String itemId,
    required String childId,
    required String path,
    required ImageKind kind,
  }) =>
      db.insert('images', {
        'id': newId(),
        'item_id': itemId,
        'path': path,
        'source': 'file',
        'kind': kind.name,
        'child_id': childId,
        'created_at': nowMs(),
      });

  Future<String?> deleteImage(String imageId) async {
    final r = await db.query('images',
        where: "id=? AND source='file'", whereArgs: [imageId]);
    if (r.isEmpty) return null;
    await db.delete('images', where: 'id=?', whereArgs: [imageId]);
    return r.first['path'] as String;
  }

  /// يحفظ تسجيلًا لبند (اسم أو سؤال) ويعيد مسار التسجيل السابق لحذفه.
  Future<String?> setItemAudio({
    required String itemId,
    required String childId,
    required String purpose,
    required String path,
  }) async {
    final old = await db.query('audio_clips',
        where: "item_id=? AND child_id=? AND purpose=? AND source='file'",
        whereArgs: [itemId, childId, purpose]);
    await db.delete('audio_clips',
        where: 'item_id=? AND child_id=? AND purpose=?',
        whereArgs: [itemId, childId, purpose]);
    await db.insert('audio_clips', {
      'id': newId(),
      'item_id': itemId,
      'child_id': childId,
      'purpose': purpose,
      'path': path,
      'source': 'file',
      'created_at': nowMs(),
    });
    return old.isEmpty ? null : old.first['path'] as String;
  }

  Future<String?> deleteItemAudio(
      String itemId, String childId, String purpose) async {
    final old = await db.query('audio_clips',
        where: 'item_id=? AND child_id=? AND purpose=?',
        whereArgs: [itemId, childId, purpose]);
    await db.delete('audio_clips',
        where: 'item_id=? AND child_id=? AND purpose=?',
        whereArgs: [itemId, childId, purpose]);
    return old.isEmpty ? null : old.first['path'] as String;
  }

  Future<AudioClip?> genericAudio(String childId, String key) async {
    final r = await db.query('audio_clips',
        where: "purpose='generic' AND key=? AND (child_id=? OR child_id IS NULL)",
        whereArgs: [key, childId],
        orderBy: 'child_id IS NULL, created_at DESC',
        limit: 1);
    return r.isEmpty ? null : AudioClip.fromMap(r.first);
  }

  Future<String?> setGenericAudio(String childId, String key, String path) async {
    final old = await genericAudio(childId, key);
    await db.delete('audio_clips',
        where: "purpose='generic' AND key=? AND child_id=?",
        whereArgs: [key, childId]);
    await db.insert('audio_clips', {
      'id': newId(),
      'child_id': childId,
      'purpose': 'generic',
      'key': key,
      'path': path,
      'source': 'file',
      'created_at': nowMs(),
    });
    return (old != null && !old.isAsset && old.childId == childId) ? old.path : null;
  }

  Future<List<AudioClip>> praiseClips(String childId) async =>
      (await db.query('audio_clips',
              where: "purpose='praise' AND (child_id=? OR child_id IS NULL)",
              whereArgs: [childId],
              orderBy: 'created_at'))
          .map(AudioClip.fromMap)
          .toList();

  Future<void> addPraiseClip(String childId, String path) =>
      db.insert('audio_clips', {
        'id': newId(),
        'child_id': childId,
        'purpose': 'praise',
        'path': path,
        'source': 'file',
        'created_at': nowMs(),
      });

  Future<String?> deleteAudioClip(String id) async {
    final r = await db.query('audio_clips', where: 'id=?', whereArgs: [id]);
    if (r.isEmpty) return null;
    await db.delete('audio_clips', where: 'id=?', whereArgs: [id]);
    return r.first['source'] == 'file' ? r.first['path'] as String : null;
  }

  // ---------------------------------------------------------- reinforcers ---

  Future<List<Reinforcer>> reinforcers(String childId) async =>
      (await db.query('reinforcers',
              where: 'child_id=?', whereArgs: [childId], orderBy: 'sort'))
          .map(Reinforcer.fromMap)
          .toList();

  Future<void> addReinforcer(String childId, String itemId) async {
    final count = firstIntValue(await db.rawQuery(
            'SELECT COUNT(*) FROM reinforcers WHERE child_id=?', [childId])) ??
        0;
    await db.insert(
        'reinforcers',
        {
          'id': newId(),
          'child_id': childId,
          'item_id': itemId,
          'enabled': 1,
          'sort': count,
        },
        conflictAlgorithm: ConflictAlgorithm.ignore);
  }

  Future<void> setReinforcerEnabled(String id, bool enabled) => db.update(
      'reinforcers', {'enabled': enabled ? 1 : 0},
      where: 'id=?', whereArgs: [id]);

  Future<void> removeReinforcer(String id) =>
      db.delete('reinforcers', where: 'id=?', whereArgs: [id]);

  // -------------------------------------------------------------- targets ---

  Future<void> _insertTargetFromTemplate(
      DatabaseExecutor txn, String childId, Map<String, dynamic> t,
      {required int sort}) async {
    final id = newId();
    final now = nowMs();
    final m = t['mastery'] as Map<String, dynamic>;
    final extra = (t['extra'] as Map<String, dynamic>?) ?? const {};
    final source = t['items'] as String;
    await txn.insert('targets', {
      'id': id,
      'child_id': childId,
      'skill_id': t['skill'],
      'level_id': t['level'] ?? 1,
      'title_ar': t['title_ar'],
      'description_ar': t['description_ar'],
      'status': 'active',
      'enabled_for_parent': 1,
      'trials_per_session': t['trials_per_session'],
      'wait_seconds': t['wait_seconds'],
      'field_sizes': (t['field_sizes'] as List).join(','),
      'advance_after_correct': 2,
      'step_back_after_errors': 2,
      'prompt_order': 'mostToLeast',
      'start_prompt': t['start_prompt'],
      'carry_over_prompt': 1,
      'break_after_errors': 3,
      'break_after_no_response': 3,
      'item_source': source == 'familiar' ? 'custom' : source,
      'sample_kind': extra['sample_kind'] ?? 'same',
      'template_code': t['code'],
      'sort': sort,
      'created_at': now,
      'updated_at': now,
    });
    var pos = 0;
    for (final p in (t['prompt_ladder'] as List)) {
      await txn.insert('target_prompt_levels',
          {'target_id': id, 'prompt_code': p, 'position': pos++});
    }
    await txn.insert('mastery_criteria', {
      'target_id': id,
      'percent_threshold': (m['percent'] as num).toDouble(),
      'consecutive_sessions': m['sessions'],
      'min_trainers': m['min_trainers'] ?? 1,
      'min_trials': 5,
      'min_distinct_independent': m['min_distinct_independent'] ?? 0,
    });
    if (source == 'familiar') {
      final fam = await txn.query('settings',
          where: "scope='global' AND key='familiar_set'");
      final ids = (fam.first['value'] as String).split(',');
      for (final i in ids) {
        await txn.insert('target_items', {'target_id': id, 'item_id': i});
      }
    }
  }

  Future<String> addTargetFromTemplate(
      String childId, Map<String, dynamic> template) async {
    late String id;
    await db.transaction((txn) async {
      final sort = firstIntValue(await txn.rawQuery(
              'SELECT COALESCE(MAX(sort),0)+1 FROM targets WHERE child_id=?',
              [childId])) ??
          0;
      await _insertTargetFromTemplate(txn, childId, template, sort: sort);
      id = (await txn.query('targets',
              columns: ['id'],
              where: 'child_id=?',
              whereArgs: [childId],
              orderBy: 'created_at DESC, rowid DESC',
              limit: 1))
          .first['id'] as String;
    });
    return id;
  }

  Future<List<Target>> targets(String childId) async {
    final rows = await db.query('targets',
        where: 'child_id=?', whereArgs: [childId], orderBy: 'sort');
    return [for (final r in rows) await _hydrateTarget(r)];
  }

  Future<Target?> target(String id) async {
    final r = await db.query('targets', where: 'id=?', whereArgs: [id]);
    return r.isEmpty ? null : _hydrateTarget(r.first);
  }

  Future<Target> _hydrateTarget(Map<String, Object?> r) async {
    final id = r['id'] as String;
    final mc =
        await db.query('mastery_criteria', where: 'target_id=?', whereArgs: [id]);
    final ladder = (await db.query('target_prompt_levels',
            where: 'target_id=?', whereArgs: [id], orderBy: 'position'))
        .map((m) => m['prompt_code'] as String)
        .toList();
    return Target.fromMap(
      r,
      mc.isEmpty
          ? const MasteryCriteria(percent: 80, consecutiveSessions: 3)
          : MasteryCriteria.fromMap(mc.first),
      ladder,
    );
  }

  Future<void> updateTarget(Target t) async {
    await db.transaction((txn) async {
      await txn.update('targets', {...t.toMap(), 'updated_at': nowMs()},
          where: 'id=?', whereArgs: [t.id]);
      await txn.insert('mastery_criteria', t.mastery.toMap(t.id),
          conflictAlgorithm: ConflictAlgorithm.replace);
      await txn.delete('target_prompt_levels',
          where: 'target_id=?', whereArgs: [t.id]);
      var pos = 0;
      for (final p in t.promptLadder) {
        await txn.insert('target_prompt_levels',
            {'target_id': t.id, 'prompt_code': p, 'position': pos++});
      }
    });
  }

  Future<void> deleteTarget(String id) =>
      db.delete('targets', where: 'id=?', whereArgs: [id]);

  /// معرفات البنود المختارة يدويًا لهدف (المصدر custom).
  Future<List<String>> targetItemIds(String targetId) async =>
      (await db.query('target_items',
              where: 'target_id=?', whereArgs: [targetId], orderBy: 'rowid'))
          .map((r) => r['item_id'] as String)
          .toList();

  Future<void> setTargetItems(String targetId, List<String> itemIds) async {
    await db.transaction((txn) async {
      await txn.delete('target_items', where: 'target_id=?', whereArgs: [targetId]);
      for (final i in itemIds) {
        await txn.insert('target_items', {'target_id': targetId, 'item_id': i});
      }
    });
  }

  /// البنود الفعلية التي يتدرب عليها الطفل في هذا الهدف.
  Future<List<Item>> resolveTargetItems(Target t) async {
    final all = await items(t.childId);
    switch (t.itemSource) {
      case 'reinforcers':
        final r = (await reinforcers(t.childId)).where((r) => r.enabled);
        final byId = {for (final i in all) i.id: i};
        return [for (final x in r) if (byId[x.itemId] != null) byId[x.itemId]!];
      case 'with_photo':
        return all.where((i) => i.photo != null && i.category != 'reinforcer').toList();
      default:
        final ids = await targetItemIds(t.id);
        final byId = {for (final i in all) i.id: i};
        return [for (final id in ids) if (byId[id] != null) byId[id]!];
    }
  }

  // ------------------------------------------------------------- sessions ---

  Future<SessionRecord> startSession({
    required String childId,
    required String targetId,
    required String trainerName,
    required int plannedMinutes,
  }) async {
    final s = SessionRecord(
      id: newId(),
      childId: childId,
      targetId: targetId,
      trainerName: trainerName.trim(),
      startedAt: nowMs(),
      plannedMinutes: plannedMinutes,
    );
    await db.insert('sessions', {
      'id': s.id,
      'child_id': childId,
      'target_id': targetId,
      'trainer_name': s.trainerName,
      'started_at': s.startedAt,
      'planned_minutes': plannedMinutes,
    });
    return s;
  }

  /// end_reason: completed | time_limit | stopped_by_adult | break
  Future<void> endSession(String sessionId, String reason) => db.update(
      'sessions', {'ended_at': nowMs(), 'end_reason': reason},
      where: 'id=?', whereArgs: [sessionId]);

  Future<void> deleteSession(String sessionId) =>
      db.delete('sessions', where: 'id=?', whereArgs: [sessionId]);

  Future<List<SessionRecord>> sessions(String childId, {String? targetId}) async =>
      (await db.query('sessions',
              where: targetId == null ? 'child_id=?' : 'child_id=? AND target_id=?',
              whereArgs: targetId == null ? [childId] : [childId, targetId],
              orderBy: 'started_at'))
          .map(SessionRecord.fromMap)
          .toList();

  /// المستوى الذي انتهت عنده آخر تجربة غير تصحيحية (لاستمرار التلاشي بين
  /// الجلسات). مشتق من السجلات وليس مخزنًا.
  Future<String?> lastPromptForTarget(String targetId) async {
    final r = await db.rawQuery(
        'SELECT prompt_code FROM trials WHERE target_id=? AND is_correction=0 ORDER BY presented_at DESC LIMIT 1',
        [targetId]);
    return r.isEmpty ? null : r.first['prompt_code'] as String;
  }

  // --------------------------------------------------------------- trials ---

  Future<void> insertTrial(TrialRecord t, List<ResponseEvent> events) async {
    await db.transaction((txn) async {
      await txn.insert('trials', {
        'id': t.id,
        'session_id': t.sessionId,
        'child_id': t.childId,
        'target_id': t.targetId,
        'skill_id': t.skillId,
        'trial_number': t.trialNumber,
        'stimulus_item_id': t.stimulusItemId,
        'stimulus_label': t.stimulusLabel,
        'choice_item_ids': t.choiceItemIds.join(','),
        'field_size': t.fieldSize,
        'prompt_code': t.promptCode,
        'is_correction': t.isCorrection ? 1 : 0,
        'outcome': TrialRecord.outcomeToDb(t.outcome),
        'independent': t.independent ? 1 : 0,
        'latency_ms': t.latencyMs,
        'presented_at': t.presentedAt,
        'scored_by': t.scoredBy,
      });
      final now = nowMs();
      for (final e in events) {
        await txn.insert('responses', {
          'id': newId(),
          'trial_id': t.id,
          'kind': e.kind,
          'selected_item_id': e.selectedItemId,
          'recording_path': e.recordingPath,
          'outcome': e.outcome == null ? null : TrialRecord.outcomeToDb(e.outcome!),
          'prompt_code': e.promptCode,
          'latency_ms': e.latencyMs,
          'note': e.note,
          'created_at': now,
        });
      }
    });
  }

  static const _trialSelect = '''
    SELECT t.*,
      (SELECT r.selected_item_id FROM responses r WHERE r.trial_id=t.id AND r.selected_item_id IS NOT NULL ORDER BY r.created_at DESC, r.rowid DESC LIMIT 1) AS selected_item_id,
      (SELECT r.recording_path FROM responses r WHERE r.trial_id=t.id AND r.recording_path IS NOT NULL ORDER BY r.rowid DESC LIMIT 1) AS recording_path
    FROM trials t''';

  Future<List<TrialRecord>> trials({
    String? childId,
    String? targetId,
    String? sessionId,
  }) async {
    final where = <String>[];
    final args = <Object>[];
    if (childId != null) {
      where.add('t.child_id=?');
      args.add(childId);
    }
    if (targetId != null) {
      where.add('t.target_id=?');
      args.add(targetId);
    }
    if (sessionId != null) {
      where.add('t.session_id=?');
      args.add(sessionId);
    }
    final sql =
        '$_trialSelect ${where.isEmpty ? '' : 'WHERE ${where.join(' AND ')}'} ORDER BY t.presented_at, t.trial_number';
    return (await db.rawQuery(sql, args)).map(TrialRecord.fromMap).toList();
  }

  /// إعادة تقييم تجربة من الأخصائي (مثل مراجعة تسجيل التسمية). يُحفظ التقييم
  /// الجديد كاستجابة من نوع adult_score لتبقى آثار المراجعة محفوظة.
  Future<void> rescoreTrial(String trialId,
      {required TrialOutcome outcome, required String promptCode, String? note}) async {
    await db.transaction((txn) async {
      await txn.update(
          'trials',
          {
            'outcome': TrialRecord.outcomeToDb(outcome),
            'prompt_code': promptCode,
            'independent':
                outcome == TrialOutcome.correct && promptCode == 'independent' ? 1 : 0,
            'scored_by': 'specialist_review',
          },
          where: 'id=?',
          whereArgs: [trialId]);
      await txn.insert('responses', {
        'id': newId(),
        'trial_id': trialId,
        'kind': 'adult_score',
        'outcome': TrialRecord.outcomeToDb(outcome),
        'prompt_code': promptCode,
        'note': note ?? 'مراجعة الأخصائي',
        'created_at': nowMs(),
      });
    });
  }
}
