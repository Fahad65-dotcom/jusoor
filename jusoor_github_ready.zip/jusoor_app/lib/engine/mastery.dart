/// تقييم معايير الإتقان من ملخصات الجلسات (المحسوبة من التجارب الأصلية).
///
/// المعيار: نسبة الاستجابات الصحيحة المستقلة ≥ [MasteryCriteria.percent] في
/// [MasteryCriteria.consecutiveSessions] جلسات متتالية (أحدث الجلسات)،
/// مع شرطين إضافيين اختياريين:
/// * عدد مدربين مختلفين ≥ [MasteryCriteria.minTrainers] ضمن تلك الجلسات
///   (التسمية: أكثر من مدرب).
/// * عدد بنود مختلفة استُجيب لها باستقلال ≥
///   [MasteryCriteria.minDistinctIndependent] (الطلب: 10 معززات مختلفة).
///
/// في الأهداف ذات التدرج في عدد الخيارات (المطابقة 2→3→5) تُحتسب للإتقان
/// الجلسات المنفذة على أكبر عدد خيارات فقط.
library;

import '../data/models.dart';
import 'metrics.dart';

enum MasteryState { notStarted, inProgress, mastered }

class MasteryResult {
  final MasteryState state;

  /// عدد الجلسات المتتالية الأخيرة التي حققت النسبة المطلوبة.
  final int streak;
  final int requiredSessions;
  final int trainersInStreak;
  final int distinctItems;
  final double? lastSessionPct;
  final int currentFieldSize;

  const MasteryResult({
    required this.state,
    required this.streak,
    required this.requiredSessions,
    required this.trainersInStreak,
    required this.distinctItems,
    required this.lastSessionPct,
    required this.currentFieldSize,
  });

  String get labelAr => switch (state) {
        MasteryState.mastered => 'متقن',
        MasteryState.inProgress => 'قيد التدريب',
        MasteryState.notStarted => 'لم يبدأ',
      };

  bool get needsMoreTraining => state == MasteryState.inProgress;
}

class MasteryEvaluator {
  /// عدد الخيارات الحالي وفق التدرج: ينتقل الطفل للمرحلة التالية بعد
  /// جلسة تحقق النسبة المطلوبة على المرحلة الحالية.
  static int currentFieldSize(
      List<SessionSummary> sessions, List<int> fieldSizes, double percent) {
    if (fieldSizes.isEmpty) return 1;
    var idx = 0;
    for (final s in sessions) {
      if (idx >= fieldSizes.length - 1) break;
      if (s.fieldSize >= fieldSizes[idx] &&
          s.stats.independentPct >= percent) {
        idx++;
      }
    }
    return fieldSizes[idx];
  }

  static MasteryResult evaluate(
    List<SessionSummary> sessions,
    MasteryCriteria c, {
    List<int> fieldSizes = const [],
  }) {
    final finalSize = fieldSizes.isEmpty ? 0 : fieldSizes.last;
    final fieldNow = currentFieldSize(sessions, fieldSizes, c.percent);
    final eligible = sessions
        .where((s) => s.stats.trials >= c.minTrialsPerSession)
        .where((s) => finalSize <= 1 || s.fieldSize >= finalSize)
        .toList();

    if (sessions.isEmpty) {
      return MasteryResult(
        state: MasteryState.notStarted,
        streak: 0,
        requiredSessions: c.consecutiveSessions,
        trainersInStreak: 0,
        distinctItems: 0,
        lastSessionPct: null,
        currentFieldSize: fieldNow,
      );
    }

    // أطول سلسلة متتالية في نهاية السجل تحقق النسبة.
    var streak = 0;
    for (var i = eligible.length - 1; i >= 0; i--) {
      if (eligible[i].stats.independentPct >= c.percent) {
        streak++;
      } else {
        break;
      }
    }
    final window = eligible.sublist(eligible.length - streak);
    final trainers = window
        .map((s) => s.session.trainerName.trim())
        .where((n) => n.isNotEmpty)
        .toSet()
        .length;
    // البنود المختلفة: عبر كل الجلسات (هدف تراكمي مثل «10 معززات مختلفة»).
    final distinct = <String>{
      for (final s in sessions) ...s.distinctIndependentItems,
    }.length;

    final mastered = streak >= c.consecutiveSessions &&
        trainers >= c.minTrainers &&
        distinct >= c.minDistinctIndependent;

    return MasteryResult(
      state: mastered ? MasteryState.mastered : MasteryState.inProgress,
      streak: streak,
      requiredSessions: c.consecutiveSessions,
      trainersInStreak: trainers,
      distinctItems: distinct,
      lastSessionPct: sessions.last.stats.independentPct,
      currentFieldSize: fieldNow,
    );
  }
}
