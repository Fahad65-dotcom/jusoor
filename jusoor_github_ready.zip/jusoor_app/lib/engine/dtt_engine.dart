/// محرك التجارب المنفصلة (Discrete Trial Training).
///
/// المحرك مستقل تمامًا عن الواجهة وقاعدة البيانات حتى يكون قابلًا
/// للاختبار. تتكون كل تجربة من:
/// 1. عرض المثير/التعليمة ([TrialPlan]).
/// 2. الانتظار مدة [EngineConfig.waitSeconds] (تتولاها الواجهة).
/// 3. استقبال الاستجابة وتحديد نوعها ([DttSession.submit]).
/// 4. تسجيل مستوى المساعدة.
/// 5. تقديم النتيجة والتعزيز ([TrialFeedback]).
/// 6. الانتقال إلى التجربة التالية ([DttSession.next]).
///
/// تصحيح الخطأ: لا عقاب ولا أصوات سلبية؛ تُعرض الإجابة الصحيحة ثم تُعاد
/// التجربة نفسها بتلقين أعلى بخطوة (تجربة تصحيحية لا تدخل في حساب النسب).
library;

import 'dart:math';

import '../data/models.dart';
import 'prompt_fading.dart';

/// نوع واجهة التجربة. أي مهارة جديدة تستخدم أحد هذه الأنواع يمكن إضافتها
/// كمحتوى دون تعديل المحرك.
enum EngineKind { mand, listener, tact, matching }

EngineKind? engineKindFrom(String s) =>
    EngineKind.values.where((e) => e.name == s).firstOrNull;

class EngineConfig {
  final EngineKind kind;
  final int trialsPerSession;
  final int fieldSize;
  final int waitSeconds;
  final List<String> ladder;
  final String startPrompt;
  final int advanceAfterCorrect;
  final int stepBackAfterErrors;
  final PromptOrder order;
  final int breakAfterErrors;
  final int breakAfterNoResponse;

  /// عدد الاستجابات الصحيحة اللازمة لمكافأة إضافية (0 = معطلة).
  final int bonusEvery;

  const EngineConfig({
    required this.kind,
    required this.trialsPerSession,
    required this.fieldSize,
    required this.waitSeconds,
    required this.ladder,
    required this.startPrompt,
    this.advanceAfterCorrect = 2,
    this.stepBackAfterErrors = 2,
    this.order = PromptOrder.mostToLeast,
    this.breakAfterErrors = 3,
    this.breakAfterNoResponse = 3,
    this.bonusEvery = 5,
  });
}

class TrialPlan {
  /// رقم تسلسلي لكل تجربة في الجلسة (يشمل التجارب التصحيحية).
  final int number;
  final String stimulusId;

  /// معرفات الخيارات بترتيب ظهورها على الشاشة.
  final List<String> choices;

  /// مستوى التلقين المخطط لهذه التجربة.
  final String prompt;
  final bool isCorrection;
  final int fieldSize;

  const TrialPlan({
    required this.number,
    required this.stimulusId,
    required this.choices,
    required this.prompt,
    required this.isCorrection,
    required this.fieldSize,
  });

  int get correctIndex => choices.indexOf(stimulusId);
}

class TrialFeedback {
  final bool correct;
  final bool independent;

  /// عرض الإجابة الصحيحة وإعادة التجربة (تصحيح الخطأ).
  final bool showCorrection;
  final FadeChange fadeChange;
  final bool bonusDue;
  final bool breakSuggested;
  final bool finished;

  const TrialFeedback({
    required this.correct,
    required this.independent,
    required this.showCorrection,
    required this.fadeChange,
    required this.bonusDue,
    required this.breakSuggested,
    required this.finished,
  });
}

class DttSession {
  final EngineConfig config;
  final List<String> itemIds;
  final Random _rng;
  late final PromptFader fader;

  final List<String> _queue = [];
  String? _lastStimulus;
  final List<int> _recentCorrectPositions = [];
  TrialPlan? _pendingCorrection;

  int _sequence = 0;
  int _completed = 0;
  int _correctCount = 0;
  int _independentCount = 0;
  int _consecutiveErrors = 0;
  int _consecutiveNoResponse = 0;

  DttSession({
    required this.config,
    required List<String> items,
    Random? random,
    String? carriedPrompt,
  })  : itemIds = List.unmodifiable(items),
        _rng = random ?? Random() {
    if (items.isEmpty) {
      throw ArgumentError('لا توجد بنود تدريبية لهذا الهدف');
    }
    final start = config.order == PromptOrder.leastToMost
        ? kIndependent
        : (carriedPrompt ?? config.startPrompt);
    fader = PromptFader(
      ladder: config.ladder,
      start: start,
      advanceAfterCorrect: config.advanceAfterCorrect,
      stepBackAfterErrors: config.stepBackAfterErrors,
    );
  }

  int get completedTrials => _completed;
  int get correctCount => _correctCount;
  int get independentCount => _independentCount;
  bool get isFinished => _completed >= config.trialsPerSession;
  String get currentPrompt => fader.current;

  /// عدد الخيارات الفعلي (لا يتجاوز عدد البنود المتاحة).
  int get effectiveFieldSize => switch (config.kind) {
        EngineKind.tact => 1,
        _ => min(config.fieldSize, itemIds.length).clamp(1, 99),
      };

  /// التجربة التالية، أو null عند اكتمال الجلسة.
  TrialPlan? next() {
    if (_pendingCorrection != null) {
      final c = _pendingCorrection!;
      _pendingCorrection = null;
      return c;
    }
    if (isFinished) return null;
    final stimulus = _nextStimulus();
    return TrialPlan(
      number: ++_sequence,
      stimulusId: stimulus,
      choices: _buildChoices(stimulus),
      prompt: fader.current,
      isCorrection: false,
      fieldSize: effectiveFieldSize,
    );
  }

  /// في نمط «من الأقل إلى الأكثر»: المستوى التالي عند الخطأ داخل التجربة
  /// نفسها، أو null إذا وصلنا إلى أعلى مساعدة.
  String? escalate(String currentPrompt) {
    if (config.order != PromptOrder.leastToMost) return null;
    final i = fader.ladder.indexOf(currentPrompt);
    if (i <= 0) return null;
    return fader.ladder[i - 1];
  }

  /// تقييم اختيار باللمس/السحب. في الطلب (Mand) أي اختيار طلب صحيح لأنه
  /// يعبر عن دافع الطفل.
  TrialOutcome evaluateSelection(TrialPlan plan, String? selectedId) {
    if (selectedId == null) return TrialOutcome.noResponse;
    if (config.kind == EngineKind.mand) return TrialOutcome.correct;
    return selectedId == plan.stimulusId
        ? TrialOutcome.correct
        : TrialOutcome.incorrect;
  }

  /// تسجيل نتيجة التجربة وإرجاع التغذية الراجعة.
  /// [promptUsed] هو المستوى الفعلي الذي استجاب عنده الطفل.
  TrialFeedback submit(
    TrialPlan plan, {
    required TrialOutcome outcome,
    required String promptUsed,
  }) {
    final correct = outcome == TrialOutcome.correct;
    final independent = correct && promptUsed == kIndependent;

    if (plan.isCorrection) {
      // التجارب التصحيحية لا تؤثر على العدادات أو التلاشي.
      return TrialFeedback(
        correct: correct,
        independent: false,
        showCorrection: false,
        fadeChange: FadeChange.none,
        bonusDue: false,
        breakSuggested: false,
        finished: isFinished,
      );
    }

    _completed++;
    var fade = FadeChange.none;
    if (config.order == PromptOrder.mostToLeast) {
      fade = fader.record(correct: correct);
    }

    var bonus = false;
    if (correct) {
      _correctCount++;
      if (independent) _independentCount++;
      _consecutiveErrors = 0;
      _consecutiveNoResponse = 0;
      bonus = config.bonusEvery > 0 && _correctCount % config.bonusEvery == 0;
    } else if (outcome == TrialOutcome.noResponse) {
      _consecutiveNoResponse++;
      _consecutiveErrors++;
    } else {
      _consecutiveErrors++;
      _consecutiveNoResponse = 0;
    }

    final needBreak =
        (config.breakAfterErrors > 0 &&
                _consecutiveErrors >= config.breakAfterErrors) ||
            (config.breakAfterNoResponse > 0 &&
                _consecutiveNoResponse >= config.breakAfterNoResponse);

    var showCorrection = false;
    if (!correct && config.kind != EngineKind.mand) {
      showCorrection = true;
      final help = fader.moreHelpThan(promptUsed);
      _pendingCorrection = TrialPlan(
        number: ++_sequence,
        stimulusId: plan.stimulusId,
        choices: _shuffleKeeping(plan.choices, plan.stimulusId),
        prompt: help,
        isCorrection: true,
        fieldSize: plan.fieldSize,
      );
    }

    return TrialFeedback(
      correct: correct,
      independent: independent,
      showCorrection: showCorrection,
      fadeChange: fade,
      bonusDue: bonus,
      breakSuggested: needBreak,
      finished: isFinished && _pendingCorrection == null,
    );
  }

  /// يُستدعى بعد الاستراحة لإعادة ضبط عدادات الأخطاء.
  void acknowledgeBreak() {
    _consecutiveErrors = 0;
    _consecutiveNoResponse = 0;
  }

  // ---------------------------------------------------------------------------

  String _nextStimulus() {
    if (_queue.isEmpty) {
      _queue.addAll(itemIds);
      _queue.shuffle(_rng);
      if (_queue.length > 1 && _queue.first == _lastStimulus) {
        final first = _queue.removeAt(0);
        _queue.add(first);
      }
    }
    final s = _queue.removeAt(0);
    _lastStimulus = s;
    return s;
  }

  List<String> _buildChoices(String stimulus) {
    final n = effectiveFieldSize;
    if (n <= 1) return [stimulus];
    final others = itemIds.where((i) => i != stimulus).toList()..shuffle(_rng);
    final choices = [stimulus, ...others.take(n - 1)];
    return _shuffleKeeping(choices, stimulus);
  }

  /// ترتيب عشوائي مع منع ظهور الإجابة الصحيحة في الموضع نفسه أكثر من
  /// مرتين متتاليتين (لتجنب حفظ المكان).
  List<String> _shuffleKeeping(List<String> choices, String correct) {
    final list = List<String>.from(choices);
    if (list.length < 2) return list;
    for (var attempt = 0; attempt < 10; attempt++) {
      list.shuffle(_rng);
      final pos = list.indexOf(correct);
      final r = _recentCorrectPositions;
      final repeats =
          r.length >= 2 && r[r.length - 1] == pos && r[r.length - 2] == pos;
      if (!repeats) break;
    }
    _recentCorrectPositions.add(list.indexOf(correct));
    if (_recentCorrectPositions.length > 4) _recentCorrectPositions.removeAt(0);
    return list;
  }
}
