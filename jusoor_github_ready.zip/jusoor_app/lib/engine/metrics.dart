/// حساب مؤشرات الأداء من سجلات التجارب الأصلية فقط.
///
/// لا تُخزَّن أي قيمة مشتقة في قاعدة البيانات؛ كل نسبة تُحسب هنا عند الطلب
/// حتى تبقى متطابقة دائمًا مع البيانات الخام.
///
/// تعريفات:
/// * التجارب المحسوبة: كل التجارب غير التصحيحية.
/// * نسبة الصحيحة = الصحيحة (بأي مستوى تلقين) ÷ المحسوبة.
/// * نسبة المستقلة = الصحيحة دون تلقين ÷ المحسوبة.
/// * نسبة بمساعدة = الصحيحة بتلقين ÷ المحسوبة.
library;

import '../data/models.dart';

class PerformanceStats {
  final int sessions;
  final int trials;
  final int correct;
  final int independent;
  final int prompted;
  final int incorrect;
  final int noResponse;
  final int correctionTrials;
  final double? meanLatencyMs;

  const PerformanceStats({
    required this.sessions,
    required this.trials,
    required this.correct,
    required this.independent,
    required this.prompted,
    required this.incorrect,
    required this.noResponse,
    required this.correctionTrials,
    required this.meanLatencyMs,
  });

  double _pct(int n) => trials == 0 ? 0 : n * 100.0 / trials;
  double get correctPct => _pct(correct);
  double get independentPct => _pct(independent);
  double get promptedPct => _pct(prompted);
  double get errorPct => _pct(incorrect + noResponse);

  static PerformanceStats fromTrials(Iterable<TrialRecord> all) {
    final scored = all.where((t) => !t.isCorrection).toList();
    final sessions = all.map((t) => t.sessionId).toSet().length;
    final correct = scored.where((t) => t.isCorrect).length;
    final independent = scored.where((t) => t.isCorrect && t.independent).length;
    final latencies = scored
        .where((t) => t.latencyMs != null && t.outcome != TrialOutcome.noResponse)
        .map((t) => t.latencyMs!)
        .toList();
    return PerformanceStats(
      sessions: sessions,
      trials: scored.length,
      correct: correct,
      independent: independent,
      prompted: correct - independent,
      incorrect: scored.where((t) => t.outcome == TrialOutcome.incorrect).length,
      noResponse:
          scored.where((t) => t.outcome == TrialOutcome.noResponse).length,
      correctionTrials: all.length - scored.length,
      meanLatencyMs: latencies.isEmpty
          ? null
          : latencies.reduce((a, b) => a + b) / latencies.length,
    );
  }
}

/// ملخص جلسة واحدة لهدف واحد، محسوب من تجاربها.
class SessionSummary {
  final SessionRecord session;
  final PerformanceStats stats;

  /// أكبر عدد خيارات استُخدم في الجلسة (للتدرج 2→3→5 في المطابقة).
  final int fieldSize;

  /// البنود المختلفة التي استجاب لها الطفل استجابة صحيحة مستقلة
  /// (في الطلب: المعززات المختلفة التي طلبها دون تلقين).
  final Set<String> distinctIndependentItems;

  SessionSummary({
    required this.session,
    required this.stats,
    required this.fieldSize,
    required this.distinctIndependentItems,
  });

  static List<SessionSummary> build(
    List<SessionRecord> sessions,
    List<TrialRecord> trials, {
    bool selectionBased = false,
  }) {
    final byS = <String, List<TrialRecord>>{};
    for (final t in trials) {
      byS.putIfAbsent(t.sessionId, () => []).add(t);
    }
    final sorted = [...sessions]..sort((a, b) => a.startedAt.compareTo(b.startedAt));
    return [
      for (final s in sorted)
        if ((byS[s.id] ?? const []).any((t) => !t.isCorrection))
          SessionSummary(
            session: s,
            stats: PerformanceStats.fromTrials(byS[s.id]!),
            fieldSize: byS[s.id]!
                .where((t) => !t.isCorrection)
                .map((t) => t.fieldSize)
                .fold(0, (a, b) => a > b ? a : b),
            distinctIndependentItems: byS[s.id]!
                .where((t) => !t.isCorrection && t.isCorrect && t.independent)
                .map((t) =>
                    (selectionBased ? t.selectedItemId : t.stimulusItemId) ??
                    '')
                .where((id) => id.isNotEmpty)
                .toSet(),
          ),
    ];
  }
}
