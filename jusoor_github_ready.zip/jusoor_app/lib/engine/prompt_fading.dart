/// نظام التلقين والتلاشي التدريجي.
///
/// السلم [ladder] مرتب من الأكثر مساعدة إلى الأقل، وآخر عنصر فيه هو دائمًا
/// `independent` (استجابة مستقلة). مثال افتراضي:
/// `full → partial → verbal → visual → independent`.
///
/// القواعد (قابلة للضبط لكل هدف من الأخصائي):
/// * بعد [advanceAfterCorrect] استجابات صحيحة متتالية على المستوى الحالي
///   تقل المساعدة خطوة واحدة (نحو الاستقلال).
/// * بعد [stepBackAfterErrors] أخطاء متتالية (الافتراضي 2) يرجع النظام
///   خطوة واحدة نحو مساعدة أكبر.
library;

const String kIndependent = 'independent';

/// المستويات المعروفة للمحرك والواجهة. يمكن للأخصائي إعادة ترتيبها
/// أو استبعاد بعضها من سلم هدف معين.
const List<String> kAllPromptCodes = [
  'full',
  'partial',
  'verbal',
  'visual',
  kIndependent,
];

class PromptFader {
  final List<String> ladder;
  final int advanceAfterCorrect;
  final int stepBackAfterErrors;

  int _index;
  int _correctStreak = 0;
  int _errorStreak = 0;

  PromptFader({
    required List<String> ladder,
    required String start,
    this.advanceAfterCorrect = 2,
    this.stepBackAfterErrors = 2,
  })  : ladder = normalizeLadder(ladder),
        _index = 0 {
    final i = this.ladder.indexOf(start);
    _index = i < 0 ? 0 : i;
  }

  /// يضمن أن السلم غير فارغ وينتهي بالاستجابة المستقلة ودون تكرار.
  static List<String> normalizeLadder(List<String> raw) {
    final out = <String>[];
    for (final c in raw) {
      if (c != kIndependent && !out.contains(c)) out.add(c);
    }
    out.add(kIndependent);
    return out;
  }

  String get current => ladder[_index];
  bool get isIndependent => current == kIndependent;
  int get correctStreak => _correctStreak;
  int get errorStreak => _errorStreak;

  /// مستوى أكثر مساعدة بخطوة واحدة من المستوى الحالي (للتصحيح أو التصعيد).
  String get oneStepMoreHelp => ladder[(_index - 1).clamp(0, ladder.length - 1)];

  /// المستوى الأكثر مساعدة بعد [code] (للتصعيد داخل التجربة في نمط
  /// من الأقل إلى الأكثر).
  String moreHelpThan(String code) {
    final i = ladder.indexOf(code);
    if (i <= 0) return ladder.first;
    return ladder[i - 1];
  }

  /// تسجيل نتيجة تجربة (غير تصحيحية). يعيد وصفًا للتغيير إن حدث.
  FadeChange record({required bool correct}) {
    if (correct) {
      _errorStreak = 0;
      _correctStreak++;
      if (_correctStreak >= advanceAfterCorrect && _index < ladder.length - 1) {
        _index++;
        _correctStreak = 0;
        return FadeChange.lessHelp;
      }
      return FadeChange.none;
    } else {
      _correctStreak = 0;
      _errorStreak++;
      if (_errorStreak >= stepBackAfterErrors) {
        _errorStreak = 0;
        if (_index > 0) {
          _index--;
          return FadeChange.moreHelp;
        }
      }
      return FadeChange.none;
    }
  }
}

enum FadeChange { none, lessHelp, moreHelp }
