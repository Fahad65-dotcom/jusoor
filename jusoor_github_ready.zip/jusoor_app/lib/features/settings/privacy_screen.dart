import 'package:flutter/material.dart';

import '../../core/brand.dart';
import '../../core/privacy_text.dart';
import '../shared/widgets.dart';

class PrivacyPolicyScreen extends StatelessWidget {
  const PrivacyPolicyScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('سياسة الخصوصية')),
        body: ListView(padding: readablePadding(context, const EdgeInsets.all(20)), children: [
          for (final (t, b) in privacyPolicySections) ...[
            Text(t, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700, color: Brand.tealDark)),
            const SizedBox(height: 6),
            Text(b, style: const TextStyle(height: 1.7)),
            const SizedBox(height: 18),
          ],
        ]),
      );
}
