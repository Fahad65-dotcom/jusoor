/// البيانات والخصوصية: النسخ الاحتياطي، الاستعادة، الحذف، رموز الدخول.
library;


import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/app_state.dart';
import '../../core/brand.dart';
import '../../data/models.dart';
import '../../services/backup_service.dart';
import '../shared/pin_pad.dart';
import '../shared/widgets.dart';
import 'privacy_screen.dart';

class DataScreen extends StatefulWidget {
  const DataScreen({super.key});
  @override
  State<DataScreen> createState() => _DataScreenState();
}

class _DataScreenState extends State<DataScreen> {
  bool _busy = false;
  AppUser? _specialist;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final s = await context.read<AppState>().repo.userByRole(UserRole.specialist);
    if (mounted) setState(() => _specialist = s);
  }

  Future<String?> _askPassword({required bool confirm}) async {
    final a = TextEditingController(), b = TextEditingController();
    String? err;
    return showDialog<String>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, set) => AlertDialog(
          title: Text(confirm ? 'كلمة مرور النسخة الاحتياطية' : 'كلمة مرور النسخة'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            if (confirm)
              const Text('ستحتاجها لاستعادة النسخة. لا يمكن استرجاعها إن نسيتها.',
                  style: TextStyle(color: Brand.muted, fontSize: 13)),
            const SizedBox(height: 10),
            TextField(controller: a, obscureText: true, decoration: const InputDecoration(labelText: 'كلمة المرور')),
            if (confirm) ...[
              const SizedBox(height: 10),
              TextField(controller: b, obscureText: true, decoration: const InputDecoration(labelText: 'تأكيدها')),
            ],
            if (err != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(err!, style: const TextStyle(color: Color(0xFFB4554B)))),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c), child: const Text('إلغاء')),
            FilledButton(
              onPressed: () {
                if (a.text.length < 6) return set(() => err = '6 أحرف على الأقل');
                if (confirm && a.text != b.text) return set(() => err = 'غير متطابقتين');
                Navigator.pop(c, a.text);
              },
              child: const Text('متابعة'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _backup() async {
    final pw = await _askPassword(confirm: true);
    if (pw == null || !mounted) return;
    setState(() => _busy = true);
    try {
      final bytes = await context.read<AppState>().exportBackup(pw);
      final d = DateTime.now();
      final name = 'jusoor-backup-${d.year}${d.month.toString().padLeft(2, '0')}${d.day.toString().padLeft(2, '0')}.jusoor';
      final uri = await FilePicker.saveFile(fileName: name, bytes: bytes, dialogTitle: 'حفظ النسخة الاحتياطية');
      if (mounted) toast(context, uri == null ? 'أُلغي الحفظ' : 'حُفظت النسخة الاحتياطية');
    } catch (e) {
      if (mounted) toast(context, 'تعذر إنشاء النسخة: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _restore() async {
    final ok = await confirmDialog(context,
        title: 'استعادة نسخة احتياطية',
        body: 'ستحل بيانات النسخة محل كل البيانات الحالية على هذا الجهاز. هل تريد المتابعة؟',
        confirm: 'اختيار الملف');
    if (!ok) return;
    final f = await FilePicker.pickFile(dialogTitle: 'اختر ملف النسخة (.jusoor)');
    if (f == null || !mounted) return;
    final pw = await _askPassword(confirm: false);
    if (pw == null || !mounted) return;
    setState(() => _busy = true);
    try {
      final bytes = await f.readAsBytes();
      if (!mounted) return;
      await context.read<AppState>().restoreBackup(bytes, pw);
      if (mounted) {
        toast(context, 'تمت الاستعادة. أعد الدخول برمز النسخة المستعادة.');
        Navigator.of(context).popUntil((r) => r.isFirst);
      }
    } on BackupException catch (e) {
      if (mounted) toast(context, e.message);
    } catch (e) {
      if (mounted) toast(context, 'تعذرت الاستعادة: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _deleteChild() async {
    final s = context.read<AppState>();
    final kids = await s.repo.children();
    if (!mounted) return;
    if (kids.isEmpty) return toast(context, 'لا توجد ملفات أطفال');
    final c = await showDialog<Child>(
      context: context,
      builder: (c) => SimpleDialog(
        title: const Text('اختر الطفل'),
        children: [for (final k in kids) SimpleDialogOption(onPressed: () => Navigator.pop(c, k), child: Text(k.name))],
      ),
    );
    if (c == null || !mounted) return;
    final ok = await confirmDialog(context,
        title: 'حذف بيانات ${c.name} نهائيًا',
        body: 'سيُحذف ملف الطفل وكل صوره وتسجيلاته وجلساته وتقاريره من هذا الجهاز ولا يمكن التراجع.',
        confirm: 'حذف نهائي',
        danger: true);
    if (!ok || !mounted) return;
    final pin = await askPin(context, title: 'أكد برمز ولي الأمر', verify: (p) => s.verifyPin(UserRole.parent, p));
    if (!pin) return;
    await s.deleteChild(c.id);
    if (mounted) toast(context, 'حُذفت بيانات ${c.name}');
  }

  Future<void> _wipe() async {
    final s = context.read<AppState>();
    final ok = await confirmDialog(context,
        title: 'حذف كل بيانات التطبيق',
        body: 'سيُحذف كل شيء: الأطفال، الجلسات، الصور، التسجيلات، والرموز. سيعود التطبيق إلى الإعداد الأول.',
        confirm: 'حذف الكل',
        danger: true);
    if (!ok || !mounted) return;
    final pin = await askPin(context, title: 'أكد برمز ولي الأمر', verify: (p) => s.verifyPin(UserRole.parent, p));
    if (!pin || !mounted) return;
    Navigator.of(context).popUntil((r) => r.isFirst);
    await s.wipeEverything();
  }

  Future<void> _changePin(UserRole role) async {
    final s = context.read<AppState>();
    final name = TextEditingController(
        text: role == UserRole.parent ? (await s.repo.userByRole(role))?.name : _specialist?.name);
    final pin = TextEditingController();
    if (!mounted) return;
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(role == UserRole.parent ? 'رمز ولي الأمر' : 'رمز الأخصائي'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: name, decoration: const InputDecoration(labelText: 'الاسم')),
          const SizedBox(height: 10),
          TextField(controller: pin, keyboardType: TextInputType.number, obscureText: true, maxLength: 4,
              decoration: const InputDecoration(labelText: 'الرمز الجديد (4 أرقام)')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('حفظ')),
        ],
      ),
    );
    if (ok != true) return;
    if (!RegExp(r'^\d{4}$').hasMatch(pin.text) || name.text.trim().isEmpty) {
      if (mounted) toast(context, 'أدخل اسمًا ورمزًا من 4 أرقام');
      return;
    }
    await s.createUser(role, name.text.trim(), pin.text);
    await _load();
    if (mounted) toast(context, 'حُفظ الرمز');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('البيانات والخصوصية')),
      body: AbsorbPointer(
        absorbing: _busy,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          if (_busy) const LinearProgressIndicator(),
          const InfoBanner('كل البيانات محفوظة على هذا الجهاز ومشفرة. لا توجد مزامنة سحابية في هذا الإصدار.',
              color: Brand.teal, icon: Icons.lock_outline),
          const SectionTitle('النسخ الاحتياطي'),
          Card(
            child: Column(children: [
              ListTile(
                leading: const Icon(Icons.backup_outlined),
                title: const Text('إنشاء نسخة احتياطية مشفرة'),
                subtitle: const Text('تختار أنت مكان حفظ الملف'),
                onTap: _backup,
              ),
              const Divider(height: 1),
              ListTile(
                leading: const Icon(Icons.settings_backup_restore),
                title: const Text('استعادة من نسخة احتياطية'),
                onTap: _restore,
              ),
            ]),
          ),
          const SectionTitle('رموز الدخول'),
          Card(
            child: Column(children: [
              ListTile(
                leading: const Icon(Icons.pin_outlined),
                title: const Text('تغيير رمز ولي الأمر'),
                onTap: () => _changePin(UserRole.parent),
              ),
              const Divider(height: 1),
              ListTile(
                leading: const Icon(Icons.psychology_alt_outlined),
                title: Text(_specialist == null ? 'إضافة رمز للأخصائي' : 'تغيير رمز الأخصائي (${_specialist!.name})'),
                onTap: () => _changePin(UserRole.specialist),
              ),
              if (_specialist != null) ...[
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.person_remove_outlined),
                  title: const Text('إزالة رمز الأخصائي'),
                  onTap: () async {
                    await context.read<AppState>().repo.deleteUser(UserRole.specialist);
                    await _load();
                  },
                ),
              ],
            ]),
          ),
          const SectionTitle('الحذف'),
          Card(
            child: Column(children: [
              ListTile(
                leading: const Icon(Icons.person_off_outlined, color: Color(0xFFB4554B)),
                title: const Text('حذف بيانات طفل بالكامل'),
                onTap: _deleteChild,
              ),
              const Divider(height: 1),
              ListTile(
                leading: const Icon(Icons.delete_forever_outlined, color: Color(0xFFB4554B)),
                title: const Text('حذف كل بيانات التطبيق'),
                onTap: _wipe,
              ),
            ]),
          ),
          const SectionTitle('الخصوصية'),
          Card(
            child: Column(children: [
              ListTile(
                leading: const Icon(Icons.policy_outlined),
                title: const Text('سياسة الخصوصية'),
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PrivacyPolicyScreen())),
              ),
              ListTile(
                leading: const Icon(Icons.description_outlined),
                title: const Text('التراخيص'),
                subtitle: const Text('الخطوط والصور والمكتبات مفتوحة المصدر'),
                onTap: () => showLicensePage(context: context, applicationName: Brand.nameAr, applicationVersion: '1.0.0'),
              ),
            ]),
          ),
        ]),
      ),
    );
  }
}
