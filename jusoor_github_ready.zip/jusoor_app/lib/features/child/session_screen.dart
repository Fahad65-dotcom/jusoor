/// مساحة الطفل: جلسة تجارب منفصلة مغلقة لا يمكن الخروج منها إلا برمز بالغ.
///
/// تشغّل المهارات الأربع للنسخة الأولى:
/// * الطلب (Mand): «ماذا تريد؟» + صور المعززات، أي اختيار يُعزَّز فورًا.
/// * المستمع (Listener): «أين ...؟» + ثلاث صور بمواقع عشوائية.
/// * التسمية (Tact): «ما هذا؟» + صورة، تسجيل صوت الطفل وتقييم البالغ.
/// * المطابقة (Matching): صورة نموذجية + 2/3/5 خيارات باللمس أو السحب.
library;

import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/app_state.dart';
import '../../core/brand.dart';
import '../../data/models.dart';
import '../../data/repository.dart';
import '../../engine/dtt_engine.dart';
import '../../engine/mastery.dart';
import '../../engine/metrics.dart';
import '../../engine/prompt_fading.dart';
import '../../services/kiosk_service.dart';
import '../../services/media_service.dart';
import '../shared/mascot.dart';
import '../shared/pin_pad.dart';
import '../shared/widgets.dart';

enum _Phase { loading, ready, trial, feedback, bonus, rest, done, error }

class ChildSessionScreen extends StatefulWidget {
  final Child child;
  final Target target;
  final Skill skill;
  final String trainerName;
  final int minutes;
  final Random? random;

  const ChildSessionScreen({
    super.key,
    required this.child,
    required this.target,
    required this.skill,
    required this.trainerName,
    required this.minutes,
    this.random,
  });

  @override
  State<ChildSessionScreen> createState() => _ChildSessionScreenState();
}

class _ChildSessionScreenState extends State<ChildSessionScreen> {
  late final Repository _repo = context.read<AppState>().repo;
  late final EngineKind _kind = engineKindFrom(widget.skill.engine)!;
  final _rng = Random();

  _Phase _phase = _Phase.loading;
  String? _error;
  late DttSession _engine;
  late SessionRecord _session;
  late ChildSettings _settings;
  Map<String, Item> _items = {};
  List<Item> _bonusItems = [];
  final Map<String, AudioClip?> _generic = {};
  List<AudioClip> _praise = [];

  TrialPlan? _plan;
  String _prompt = kIndependent;
  int _presentedAt = 0;
  int? _windowStart;
  Timer? _waitTimer;
  List<ResponseEvent> _events = [];
  String? _showCorrect;
  String? _chosen;
  Item? _showcase;
  int _stars = 0;
  MascotMood _mood = MascotMood.calm;
  int _playToken = 0;
  bool _vocalMand = false;
  bool _waitingForAdult = false;
  final List<Future<void>> _writes = [];

  final Recorder _recorder = Recorder();
  bool _recording = false;

  bool get _anim => _settings.animations;

  @override
  void initState() {
    super.initState();
    _init();
  }

  @override
  void dispose() {
    _waitTimer?.cancel();
    Sound.instance.stop();
    _recorder.dispose();
    KioskService.exit();
    super.dispose();
  }

  // ------------------------------------------------------------ setup ---

  Future<void> _init() async {
    try {
      _settings = await _repo.childSettings(widget.child.id);
      Sound.instance.volume = _settings.volume;
      final items = await _repo.resolveTargetItems(widget.target);
      _items = {for (final i in items) i.id: i};
      final all = await _repo.items(widget.child.id);
      final rein = (await _repo.reinforcers(widget.child.id)).where((r) => r.enabled).map((r) => r.itemId).toSet();
      _bonusItems = all.where((i) => rein.contains(i.id)).toList();
      for (final k in GenericAudioKeys.all.keys) {
        _generic[k] = await _repo.genericAudio(widget.child.id, k);
      }
      _praise = await _repo.praiseClips(widget.child.id);

      // عدد الخيارات وفق التدرج (مشتق من الجلسات السابقة).
      var field = widget.target.fieldSizes.isEmpty ? 1 : widget.target.fieldSizes.first;
      if (widget.target.fieldSizes.length > 1) {
        final sum = SessionSummary.build(
            await _repo.sessions(widget.child.id, targetId: widget.target.id), await _repo.trials(targetId: widget.target.id));
        field = MasteryEvaluator.currentFieldSize(sum, widget.target.fieldSizes, widget.target.mastery.percent);
      }
      final carried = widget.target.carryOverPrompt ? await _repo.lastPromptForTarget(widget.target.id) : null;
      final t = widget.target;
      _engine = DttSession(
        config: EngineConfig(
          kind: _kind,
          trialsPerSession: t.trialsPerSession,
          fieldSize: field,
          waitSeconds: t.waitSeconds,
          ladder: t.promptLadder.isEmpty ? kAllPromptCodes : t.promptLadder,
          startPrompt: t.startPrompt,
          advanceAfterCorrect: t.advanceAfterCorrect,
          stepBackAfterErrors: t.stepBackAfterErrors,
          order: t.promptOrder,
          breakAfterErrors: t.breakAfterErrors,
          breakAfterNoResponse: t.breakAfterNoResponse,
          bonusEvery: _settings.bonusEvery,
        ),
        items: items.map((i) => i.id).toList(),
        random: widget.random,
        carriedPrompt: carried != null && t.promptLadder.contains(carried) ? carried : null,
      );
      _session = await _repo.startSession(
        childId: widget.child.id,
        targetId: widget.target.id,
        trainerName: widget.trainerName,
        plannedMinutes: widget.minutes,
      );
      await KioskService.enter();
      if (mounted) setState(() => _phase = _Phase.ready);
    } catch (e) {
      if (mounted) {
        setState(() {
          _phase = _Phase.error;
          _error = '$e';
        });
      }
    }
  }

  // ------------------------------------------------------------ audio ---

  (String, bool)? _clip(AudioClip? c) => c == null ? null : (c.path, c.isAsset);

  /// التعليمة الصوتية لكل نوع. تعيد النص المكتوب البديل للبالغ.
  String _instructionText() {
    final s = _items[_plan?.stimulusId];
    return switch (_kind) {
      EngineKind.mand => 'ماذا تريد؟',
      EngineKind.listener => 'أين ${s?.labelAr ?? ''}؟',
      EngineKind.tact => 'ما هذا؟',
      EngineKind.matching => 'طابِق',
    };
  }

  Future<void> _playInstruction() async {
    final token = ++_playToken;
    final s = _items[_plan!.stimulusId];
    final clips = <(String, bool)>[];
    switch (_kind) {
      case EngineKind.mand:
        final c = _clip(_generic[GenericAudioKeys.mandQuestion]);
        if (c != null) clips.add(c);
      case EngineKind.listener:
        final q = _clip(s?.questionAudio);
        if (q != null) {
          clips.add(q);
        } else {
          final w = _clip(_generic[GenericAudioKeys.listenerPrefix]);
          final l = _clip(s?.labelAudio);
          if (w != null && l != null) clips.addAll([w, l]);
        }
      case EngineKind.tact:
        final c = _clip(_generic[GenericAudioKeys.tactQuestion]);
        if (c != null) clips.add(c);
      case EngineKind.matching:
        final c = _clip(_generic[GenericAudioKeys.matchInstruction]);
        if (c != null) clips.add(c);
    }
    for (final c in clips) {
      if (token != _playToken || !mounted) return;
      await Sound.instance.playPath(c.$1, asset: c.$2);
    }
    if (token != _playToken || !mounted) return;
    await _playPromptAudio(token);
  }

  /// التلقين اللفظي/الكامل: تشغيل النموذج الصوتي لاسم الإجابة الصحيحة.
  Future<void> _playPromptAudio([int? token]) async {
    if (_prompt != 'verbal' && _prompt != 'full') return;
    final t = token ?? ++_playToken;
    final model = _clip(_items[_plan!.stimulusId]?.labelAudio);
    if (model != null && t == _playToken && mounted) {
      await Sound.instance.playPath(model.$1, asset: model.$2);
    }
  }

  // ------------------------------------------------------------ trials ---

  bool get _timeUp =>
      DateTime.now().millisecondsSinceEpoch - _session.startedAt >= widget.minutes * 60000;

  Future<void> _beginTrial() async {
    if (_timeUp) return _finish('time_limit');
    final plan = _engine.next();
    if (plan == null) return _finish('completed');
    setState(() {
      _plan = plan;
      _prompt = plan.prompt;
      _events = [];
      _showCorrect = null;
      _chosen = null;
      _showcase = null;
      _mood = MascotMood.calm;
      _windowStart = null;
      _waitingForAdult = false;
      _presentedAt = DateTime.now().millisecondsSinceEpoch;
      _phase = _Phase.trial;
    });
    await _playInstruction();
    if (!mounted || _plan != plan || _phase != _Phase.trial) return;
    _openResponseWindow();
  }

  void _openResponseWindow() {
    _windowStart = DateTime.now().millisecondsSinceEpoch;
    _waitTimer?.cancel();
    if (_kind == EngineKind.tact) {
      _startTactRecording();
      _waitTimer = Timer(Duration(seconds: widget.target.waitSeconds), () {
        if (mounted && _phase == _Phase.trial) setState(() => _waitingForAdult = true);
      });
    } else {
      _waitTimer = Timer(Duration(seconds: widget.target.waitSeconds), _onTimeout);
    }
  }

  int get _latency => DateTime.now().millisecondsSinceEpoch - (_windowStart ?? _presentedAt);

  /// تصعيد التلقين داخل التجربة (نمط من الأقل إلى الأكثر).
  bool _tryEscalate() {
    final next = _engine.escalate(_prompt);
    if (next == null) return false;
    setState(() => _prompt = next);
    final token = ++_playToken;
    _playPromptAudio(token).then((_) {
      if (mounted && _phase == _Phase.trial && token == _playToken) _openResponseWindow();
    });
    return true;
  }

  void _onSelect(String id, {bool drag = false}) {
    if (_phase != _Phase.trial || _plan == null) return;
    if (_prompt == 'full' && _kind != EngineKind.mand && id != _plan!.stimulusId) return;
    _waitTimer?.cancel();
    _playToken++;
    Sound.instance.stop();
    final latency = _latency;
    final outcome = _engine.evaluateSelection(_plan!, id);
    _events.add(ResponseEvent(
      kind: _vocalMand && _kind == EngineKind.mand ? 'vocal' : (drag ? 'drag' : 'touch'),
      selectedItemId: id,
      outcome: outcome,
      promptCode: _prompt,
      latencyMs: latency,
    ));
    if (outcome != TrialOutcome.correct && _tryEscalate()) return;
    _finalize(outcome, selected: id, latency: latency);
  }

  void _onTimeout() {
    if (_phase != _Phase.trial || _plan == null) return;
    _events.add(ResponseEvent(kind: 'timeout', outcome: TrialOutcome.noResponse, promptCode: _prompt));
    if (_tryEscalate()) return;
    _finalize(TrialOutcome.noResponse, latency: null);
  }

  Future<void> _startTactRecording() async {
    if (_recording) return;
    try {
      _recording = await _recorder.start();
    } catch (_) {
      _recording = false;
    }
  }

  Future<void> _onAdultScore(TrialOutcome outcome) async {
    if (_phase != _Phase.trial || _plan == null) return;
    _waitTimer?.cancel();
    final latency = _latency;
    String? rec;
    if (_recording) {
      rec = await _recorder.stop();
      _recording = false;
    }
    _events.add(ResponseEvent(kind: 'vocal', recordingPath: rec, latencyMs: latency));
    _events.add(ResponseEvent(kind: 'adult_score', outcome: outcome, promptCode: _prompt, latencyMs: latency));
    if (outcome != TrialOutcome.correct && _tryEscalate()) {
      setState(() => _waitingForAdult = false);
      return;
    }
    _finalize(outcome, latency: outcome == TrialOutcome.noResponse ? null : latency, adult: true);
  }

  Future<void> _finalize(TrialOutcome outcome, {String? selected, int? latency, bool adult = false}) async {
    final plan = _plan!;
    final fb = _engine.submit(plan, outcome: outcome, promptUsed: _prompt);
    final stim = _items[plan.stimulusId];
    final record = TrialRecord(
      id: newId(),
      sessionId: _session.id,
      childId: widget.child.id,
      targetId: widget.target.id,
      skillId: widget.skill.id,
      trialNumber: plan.number,
      stimulusItemId: plan.stimulusId,
      stimulusLabel: stim?.labelAr ?? '',
      choiceItemIds: plan.choices,
      fieldSize: plan.fieldSize,
      promptCode: _prompt,
      isCorrection: plan.isCorrection,
      outcome: outcome,
      independent: fb.independent,
      selectedItemId: selected,
      latencyMs: latency,
      presentedAt: _presentedAt,
      scoredBy: adult ? 'adult' : 'auto',
    );
    _writes.add(_repo.insertTrial(record, List.of(_events)));

    final correct = outcome == TrialOutcome.correct;
    setState(() {
      _phase = _Phase.feedback;
      _chosen = selected;
      if (correct) {
        if (_settings.stars) _stars++;
        _mood = MascotMood.happy;
        if (_kind == EngineKind.mand && selected != null) _showcase = _items[selected];
      } else if (_kind != EngineKind.mand) {
        // تصحيح الخطأ: عرض الإجابة الصحيحة دون أي صوت سلبي.
        _showCorrect = plan.stimulusId;
        _mood = MascotMood.thinking;
      }
    });

    final token = ++_playToken;
    if (correct) {
      if (_settings.successChime) Sound.instance.chime();
      if (_kind == EngineKind.mand && _showcase?.labelAudio != null) {
        await Sound.instance.playPath(_showcase!.labelAudio!.path, asset: _showcase!.labelAudio!.isAsset);
        await Future.delayed(const Duration(milliseconds: 1600));
      } else if (_settings.praiseVoice && _praise.isNotEmpty) {
        final p = _praise[_rng.nextInt(_praise.length)];
        await Sound.instance.playPath(p.path, asset: p.isAsset);
      } else {
        await Future.delayed(Duration(milliseconds: _kind == EngineKind.mand ? 2200 : 900));
      }
    } else if (_kind != EngineKind.mand) {
      final model = stim?.labelAudio;
      if (model != null) await Sound.instance.playPath(model.path, asset: model.isAsset);
      await Future.delayed(const Duration(milliseconds: 1400));
    } else {
      await Future.delayed(const Duration(milliseconds: 500));
    }
    if (!mounted || token != _playToken) return;

    if (fb.bonusDue && _bonusItems.isNotEmpty) {
      final b = _bonusItems[_rng.nextInt(_bonusItems.length)];
      setState(() {
        _phase = _Phase.bonus;
        _showcase = b;
      });
      if (b.labelAudio != null) await Sound.instance.playPath(b.labelAudio!.path, asset: b.labelAudio!.isAsset);
      await Future.delayed(const Duration(milliseconds: 2600));
      if (!mounted) return;
    }
    if (fb.breakSuggested) {
      setState(() => _phase = _Phase.rest);
      return;
    }
    if (fb.finished) return _finish('completed');
    await Future.delayed(const Duration(milliseconds: 350));
    if (mounted) _beginTrial();
  }

  Future<void> _finish(String reason) async {
    _waitTimer?.cancel();
    _playToken++;
    await Sound.instance.stop();
    if (_recording) {
      await _recorder.cancel();
      _recording = false;
    }
    await Future.wait(_writes);
    await _repo.endSession(_session.id, reason);
    if (mounted) {
      setState(() {
        _phase = _Phase.done;
        _mood = MascotMood.happy;
      });
    }
  }

  /// قائمة البالغ (بعد الرمز): متابعة أو إنهاء الجلسة.
  Future<void> _adultMenu() async {
    final s = context.read<AppState>();
    final ok = await askPin(context, title: 'رمز البالغ', subtitle: 'للخروج من وضع الطفل', verify: s.verifyAnyAdult);
    if (!ok || !mounted) return;
    if (_phase == _Phase.done || _phase == _Phase.error) return _exit();
    final choice = await showDialog<String>(
      context: context,
      builder: (c) => SimpleDialog(
        title: const Text('الجلسة'),
        children: [
          SimpleDialogOption(onPressed: () => Navigator.pop(c, 'continue'), child: const Text('متابعة الجلسة')),
          SimpleDialogOption(onPressed: () => Navigator.pop(c, 'end'), child: const Text('إنهاء الجلسة وحفظ ما تم')),
        ],
      ),
    );
    if (choice == 'end') {
      if (_phase == _Phase.ready) {
        await _repo.deleteSession(_session.id);
        return _exit();
      }
      await _finish('stopped_by_adult');
      _exit();
    }
  }

  Future<void> _exit() async {
    await KioskService.exit();
    if (mounted) Navigator.of(context).pop();
  }

  // ------------------------------------------------------------- build ---

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: Brand.sand,
        body: SafeArea(
          child: Column(children: [
            _topBar(),
            Expanded(child: _body()),
            if (_phase == _Phase.trial || _phase == _Phase.feedback) _adultBar(),
          ]),
        ),
      ),
    );
  }

  Widget _topBar() => Padding(
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
        child: Row(children: [
          _HoldToUnlock(onUnlocked: _adultMenu),
          const Spacer(),
          if (_settingsReady && _settings.stars && _phase != _Phase.loading)
            Row(children: [
              Image.asset('assets/images/items/star.png', width: 28, height: 28),
              const SizedBox(width: 6),
              Text('$_stars', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: Brand.ink)),
            ]),
          const Spacer(),
          Mascot(size: 56, mood: _mood),
        ]),
      );

  bool get _settingsReady => _phase != _Phase.loading && _phase != _Phase.error;

  Widget _body() {
    switch (_phase) {
      case _Phase.loading:
        return const Center(child: CircularProgressIndicator());
      case _Phase.error:
        return Center(
          child: EmptyState(
            icon: Icons.error_outline,
            title: 'تعذر بدء الجلسة',
            body: _error,
            action: OutlinedButton(onPressed: () => Navigator.pop(context), child: const Text('رجوع')),
          ),
        );
      case _Phase.ready:
        return Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Mascot(size: 150, mood: MascotMood.happy),
            const SizedBox(height: 16),
            Text('هيا يا ${widget.child.name}', style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w700)),
            const SizedBox(height: 28),
            SizedBox(
              width: 140, height: 140,
              child: FilledButton(
                style: FilledButton.styleFrom(shape: const CircleBorder()),
                onPressed: _beginTrial,
                child: const Icon(Icons.play_arrow_rounded, size: 80),
              ),
            ),
          ]),
        );
      case _Phase.bonus:
        return _Showcase(item: _showcase, animate: _anim, big: true);
      case _Phase.rest:
        return Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Mascot(size: 150),
            const SizedBox(height: 16),
            const Text('وقت الاستراحة', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            const Text('للبالغ: لاحظنا أخطاء أو عدم استجابة متكررة. خذا استراحة قصيرة،\nأو أنهِ الجلسة من القفل أعلى الشاشة.',
                textAlign: TextAlign.center, style: TextStyle(color: Brand.muted)),
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: () {
                _engine.acknowledgeBreak();
                _beginTrial();
              },
              icon: const Icon(Icons.play_arrow_rounded),
              label: const Text('متابعة'),
            ),
          ]),
        );
      case _Phase.done:
        return Center(
          child: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Mascot(size: 160, mood: MascotMood.happy),
              const SizedBox(height: 12),
              Text('أحسنت يا ${widget.child.name}', style: const TextStyle(fontSize: 32, fontWeight: FontWeight.w700)),
              const SizedBox(height: 16),
              if (_settings.stars)
                Wrap(
                  alignment: WrapAlignment.center,
                  children: List.generate(_stars.clamp(0, 20),
                      (_) => Padding(padding: const EdgeInsets.all(3), child: Image.asset('assets/images/items/star.png', width: 40))),
                ),
              const SizedBox(height: 28),
              OutlinedButton.icon(
                onPressed: _adultMenu,
                icon: const Icon(Icons.lock_outline),
                label: const Text('للبالغ: إنهاء والعودة'),
              ),
            ]),
          ),
        );
      case _Phase.trial:
      case _Phase.feedback:
        if (_kind == EngineKind.mand && _phase == _Phase.feedback && _showcase != null) {
          return _Showcase(item: _showcase, animate: _anim);
        }
        return LayoutBuilder(builder: (c, box) => switch (_kind) {
              EngineKind.tact => _tactView(box),
              EngineKind.matching => _matchingView(box),
              _ => _choicesView(_plan!.choices),
            });
    }
  }

  // ---- عرض الخيارات (الطلب، المستمع، والمطابقة)

  _ChoiceStyle _styleFor(String id) {
    final isCorrect = id == _plan!.stimulusId;
    if (_phase == _Phase.feedback) {
      if (_showCorrect != null) {
        return isCorrect ? _ChoiceStyle.highlight : _ChoiceStyle.dim;
      }
      return id == _chosen ? _ChoiceStyle.success : _ChoiceStyle.dim;
    }
    switch (_prompt) {
      case 'full':
        return isCorrect ? _ChoiceStyle.full : _ChoiceStyle.disabled;
      case 'partial':
        return isCorrect ? _ChoiceStyle.partial : _ChoiceStyle.dim;
      case 'visual':
        return isCorrect ? _ChoiceStyle.visual : _ChoiceStyle.normal;
      default:
        return _ChoiceStyle.normal;
    }
  }

  double _cardSize(BoxConstraints box, int n) {
    final w = box.maxWidth - 32, h = box.maxHeight - 32;
    final perRow = n <= 3 ? n : (w > h ? n : 3);
    final rows = (n / perRow).ceil();
    final s = min((w - (perRow - 1) * 16) / perRow, (h - (rows - 1) * 16) / rows);
    return s.clamp(90.0, 280.0);
  }

  Widget _choicesView(List<String> ids) => Column(children: [
        const SizedBox(height: 8),
        _InstructionText(_instructionText()),
        Expanded(child: LayoutBuilder(builder: (c, b) => _choiceGrid(b, ids))),
      ]);

  Widget _choiceGrid(BoxConstraints box, List<String> ids, {bool dragTargets = false}) {
    final size = _cardSize(box, ids.length);
    return Center(
      child: Wrap(
        alignment: WrapAlignment.center,
        spacing: 16,
        runSpacing: 16,
        children: [
          for (final id in ids)
            _ChoiceCard(
              key: ValueKey('${_plan!.number}-$id'),
              item: _items[id],
              size: size,
              style: _styleFor(id),
              animate: _anim,
              showHand: _phase == _Phase.trial && _prompt == 'full' && id == _plan!.stimulusId,
              onTap: () => _onSelect(id),
              onDrop: dragTargets ? () => _onSelect(id, drag: true) : null,
            ),
        ],
      ),
    );
  }

  Widget _matchingView(BoxConstraints box) {
    final s = _items[_plan!.stimulusId];
    final photoSample = widget.target.sampleKind == 'photo_to_illustration';
    final sampleImg = photoSample ? (s?.photo ?? s?.primaryImage) : s?.primaryImage;
    final sampleSize = min(box.maxHeight * .3, 220.0);
    final sample = Container(
      width: sampleSize,
      height: sampleSize,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: Brand.teal, width: 3),
      ),
      child: ItemImageView(sampleImg, fit: photoSample ? BoxFit.cover : BoxFit.contain),
    );
    return Column(children: [
      const SizedBox(height: 4),
      _InstructionText(_instructionText()),
      const SizedBox(height: 8),
      _phase == _Phase.trial
          ? Draggable<String>(
              data: _plan!.stimulusId,
              feedback: Material(color: Colors.transparent, child: Opacity(opacity: .85, child: sample)),
              childWhenDragging: Opacity(opacity: .3, child: sample),
              child: sample,
            )
          : sample,
      const SizedBox(height: 12),
      const Icon(Icons.keyboard_double_arrow_down_rounded, color: Brand.muted),
      Expanded(
        child: LayoutBuilder(builder: (c, b) => _choiceGrid(b, _plan!.choices, dragTargets: true)),
      ),
    ]);
  }

  Widget _tactView(BoxConstraints box) {
    final s = _items[_plan!.stimulusId];
    final size = min(box.maxWidth - 48, box.maxHeight - 120).clamp(140.0, 420.0);
    final label = s?.labelAr ?? '';
    String? hint;
    if (_phase == _Phase.trial) {
      hint = switch (_prompt) {
        'full' => label,
        'partial' => label,
        'visual' => '${label.characters.first}…',
        _ => null,
      };
    } else if (_showCorrect != null) {
      hint = label;
    }
    return Column(children: [
      const SizedBox(height: 8),
      _InstructionText(_instructionText()),
      Expanded(
        child: Center(
          child: AnimatedContainer(
            duration: Duration(milliseconds: _anim ? 250 : 0),
            width: size,
            height: size,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(32),
              border: Border.all(
                  color: _phase == _Phase.feedback && _mood == MascotMood.happy ? Brand.sage : Brand.line,
                  width: _phase == _Phase.feedback ? 5 : 2),
            ),
            child: ItemImageView(s?.primaryImage, fit: BoxFit.contain),
          ),
        ),
      ),
      SizedBox(
        height: 56,
        child: hint == null
            ? (_recording ? const Icon(Icons.mic, color: Brand.apricot, size: 30) : null)
            : Text(hint, style: const TextStyle(fontSize: 36, fontWeight: FontWeight.w700, color: Brand.tealDark)),
      ),
    ]);
  }

  // ---- شريط البالغ: التعليمة ومستوى التلقين، وتقييم التسمية.

  Widget _adultBar() {
    final s = _items[_plan?.stimulusId];
    final noModel = (_prompt == 'verbal' || _prompt == 'full') && s?.labelAudio == null;
    final noInstruction = switch (_kind) {
      EngineKind.mand => _generic[GenericAudioKeys.mandQuestion] == null,
      EngineKind.tact => _generic[GenericAudioKeys.tactQuestion] == null,
      EngineKind.matching => _generic[GenericAudioKeys.matchInstruction] == null,
      EngineKind.listener => s?.questionAudio == null &&
          (_generic[GenericAudioKeys.listenerPrefix] == null || s?.labelAudio == null),
    };
    final parts = <String>[
      'للبالغ · ${_promptAr(_prompt)}${_plan?.isCorrection == true ? ' · تجربة تصحيحية' : ''}',
      if (noInstruction) 'قل: «${_instructionText()}»',
      if (noModel) 'نموذج لفظي: «${s?.labelAr ?? ''}»',
    ];
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 10),
      decoration: const BoxDecoration(color: Colors.white, border: Border(top: BorderSide(color: Brand.line))),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Text(parts.join('   ·   '), textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, color: Brand.muted)),
        if (_kind == EngineKind.tact && _phase == _Phase.trial) ...[
          const SizedBox(height: 8),
          Row(children: [
            Expanded(child: FilledButton(onPressed: () => _onAdultScore(TrialOutcome.correct), child: const Text('صحيحة'))),
            const SizedBox(width: 8),
            Expanded(
                child: OutlinedButton(onPressed: () => _onAdultScore(TrialOutcome.incorrect), child: const Text('خاطئة'))),
            const SizedBox(width: 8),
            Expanded(
                child: OutlinedButton(
              style: _waitingForAdult ? OutlinedButton.styleFrom(side: const BorderSide(color: Brand.apricot, width: 2)) : null,
              onPressed: () => _onAdultScore(TrialOutcome.noResponse),
              child: const Text('لا استجابة'),
            )),
          ]),
        ],
        if (_kind == EngineKind.mand && _phase == _Phase.trial)
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Text('طلب الطفل بالكلمة؟', style: TextStyle(fontSize: 12, color: Brand.muted)),
            Switch(value: _vocalMand, onChanged: (v) => setState(() => _vocalMand = v)),
            const Text('ثم المس ما طلبه', style: TextStyle(fontSize: 12, color: Brand.muted)),
          ]),
      ]),
    );
  }

  String _promptAr(String c) => switch (c) {
        'full' => 'تلقين كامل',
        'partial' => 'تلقين جزئي',
        'verbal' => 'تلقين لفظي',
        'visual' => 'تلقين بصري',
        _ => 'استجابة مستقلة',
      };
}

class _InstructionText extends StatelessWidget {
  final String text;
  const _InstructionText(this.text);
  @override
  Widget build(BuildContext context) =>
      Text(text, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w700, color: Brand.ink));
}

enum _ChoiceStyle { normal, full, partial, visual, dim, disabled, highlight, success }

class _ChoiceCard extends StatelessWidget {
  final Item? item;
  final double size;
  final _ChoiceStyle style;
  final bool animate;
  final bool showHand;
  final VoidCallback onTap;
  final VoidCallback? onDrop;

  const _ChoiceCard({
    super.key,
    required this.item,
    required this.size,
    required this.style,
    required this.animate,
    required this.showHand,
    required this.onTap,
    this.onDrop,
  });

  @override
  Widget build(BuildContext context) {
    final scale = switch (style) {
      _ChoiceStyle.partial || _ChoiceStyle.full || _ChoiceStyle.highlight => 1.1,
      _ => 1.0,
    };
    final opacity = switch (style) {
      _ChoiceStyle.dim => .4,
      _ChoiceStyle.disabled => .25,
      _ => 1.0,
    };
    final border = switch (style) {
      _ChoiceStyle.visual => const BorderSide(color: Brand.sky, width: 5),
      _ChoiceStyle.full || _ChoiceStyle.partial => const BorderSide(color: Brand.teal, width: 5),
      _ChoiceStyle.highlight => const BorderSide(color: Brand.apricot, width: 6),
      _ChoiceStyle.success => const BorderSide(color: Brand.sage, width: 6),
      _ => const BorderSide(color: Brand.line, width: 2),
    };
    final d = Duration(milliseconds: animate ? 220 : 0);
    Widget card = AnimatedScale(
      scale: scale,
      duration: d,
      child: AnimatedOpacity(
        opacity: opacity,
        duration: d,
        child: Material(
          color: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28), side: border),
          child: InkWell(
            borderRadius: BorderRadius.circular(28),
            onTap: style == _ChoiceStyle.disabled ? null : onTap,
            child: Semantics(
              button: true,
              label: item?.labelAr,
              child: SizedBox(
                width: size,
                height: size,
                child: Padding(padding: EdgeInsets.all(size * .1), child: ItemImageView(item?.primaryImage)),
              ),
            ),
          ),
        ),
      ),
    );
    if (showHand) {
      card = Stack(clipBehavior: Clip.none, children: [
        card,
        PositionedDirectional(
          bottom: -10,
          start: size * .55,
          child: Icon(Icons.touch_app_rounded, size: size * .32, color: Brand.tealDark),
        ),
      ]);
    }
    if (onDrop != null) {
      final inner = card; // نسخة ثابتة حتى لا يشير الباني إلى نفسه.
      return DragTarget<String>(
        onAcceptWithDetails: (_) => onDrop!(),
        builder: (c, cand, rej) => cand.isNotEmpty
            ? DecoratedBox(
                decoration: BoxDecoration(borderRadius: BorderRadius.circular(30), boxShadow: const [BoxShadow(color: Brand.tealSoft, blurRadius: 18, spreadRadius: 6)]),
                child: inner)
            : inner,
      );
    }
    return card;
  }
}

/// عرض المعزز المختار أو المكافأة الإضافية بشكل كبير وهادئ.
class _Showcase extends StatelessWidget {
  final Item? item;
  final bool animate;
  final bool big;
  const _Showcase({required this.item, required this.animate, this.big = false});

  @override
  Widget build(BuildContext context) {
    final img = Container(
      width: 300,
      height: 300,
      padding: const EdgeInsets.all(28),
      decoration: BoxDecoration(
        color: Colors.white,
        shape: BoxShape.circle,
        border: Border.all(color: Brand.apricot, width: 6),
      ),
      child: ItemImageView(item?.primaryImage),
    );
    return Center(
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        if (big) const Text('مكافأة', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w700, color: Brand.tealDark)),
        const SizedBox(height: 12),
        animate
            ? TweenAnimationBuilder<double>(
                tween: Tween(begin: .7, end: 1),
                duration: const Duration(milliseconds: 450),
                curve: Curves.easeOutBack,
                builder: (_, v, c) => Transform.scale(scale: v, child: c),
                child: img,
              )
            : img,
        const SizedBox(height: 16),
        Text(item?.labelAr ?? '', style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w700)),
      ]),
    );
  }
}

/// زر قفل يتطلب ضغطًا مطولًا (ثانيتان) قبل طلب الرمز، حتى لا يفتحه الطفل
/// بالخطأ.
class _HoldToUnlock extends StatefulWidget {
  final VoidCallback onUnlocked;
  const _HoldToUnlock({required this.onUnlocked});
  @override
  State<_HoldToUnlock> createState() => _HoldToUnlockState();
}

class _HoldToUnlockState extends State<_HoldToUnlock> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(seconds: 2))
    ..addStatusListener((s) {
      if (s == AnimationStatus.completed) {
        _c.reset();
        widget.onUnlocked();
      }
    });

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Semantics(
        label: 'قفل البالغ: اضغط مطولًا',
        child: GestureDetector(
          onTapDown: (_) => _c.forward(),
          onTapUp: (_) => _c.reverse(),
          onTapCancel: () => _c.reverse(),
          child: SizedBox(
            width: 48,
            height: 48,
            child: AnimatedBuilder(
              animation: _c,
              builder: (_, _) => Stack(alignment: Alignment.center, children: [
                CircularProgressIndicator(value: _c.value, strokeWidth: 3, color: Brand.muted, backgroundColor: Colors.transparent),
                const Icon(Icons.lock_outline, color: Brand.muted, size: 22),
              ]),
            ),
          ),
        ),
      );
}
