/// الشاشة الرئيسية: لا تعرض أي بيانات؛ الدخول إلى المساحات برمز فقط.
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/app_state.dart';
import '../../core/brand.dart';
import '../../data/models.dart';
import '../parent/parent_home.dart';
import '../shared/mascot.dart';
import '../shared/pin_pad.dart';
import '../specialist/specialist_home.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  Future<void> _open(BuildContext context, UserRole role) async {
    final s = context.read<AppState>();
    final hasSpecialist = await s.repo.userByRole(UserRole.specialist) != null;
    if (!context.mounted) return;
    final ok = await askPin(
      context,
      title: role == UserRole.parent ? 'رمز ولي الأمر' : 'رمز الأخصائي',
      subtitle: role == UserRole.specialist && !hasSpecialist ? 'لم يُضف رمز للأخصائي بعد؛ استخدم رمز ولي الأمر' : null,
      verify: (pin) => role == UserRole.specialist && hasSpecialist
          ? s.verifyPin(UserRole.specialist, pin)
          : s.verifyPin(UserRole.parent, pin),
    );
    if (!ok || !context.mounted) return;
    s.unlockedRole = role;
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => role == UserRole.parent ? const ParentHome() : const SpecialistHome()),
    );
    s.unlockedRole = null;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 480),
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(28),
              child: Column(children: [
                const Mascot(size: 140),
                const SizedBox(height: 12),
                const Text(Brand.nameAr, style: TextStyle(fontSize: 34, fontWeight: FontWeight.w700, color: Brand.tealDark)),
                const Text(Brand.taglineAr, style: TextStyle(color: Brand.muted, fontSize: 16)),
                const SizedBox(height: 36),
                _RoleCard(
                  icon: Icons.family_restroom,
                  title: 'مساحة ولي الأمر',
                  body: 'ملفات الأطفال، الجلسات، المعززات، المكتبة والتقارير',
                  color: Brand.teal,
                  onTap: () => _open(context, UserRole.parent),
                ),
                const SizedBox(height: 14),
                _RoleCard(
                  icon: Icons.psychology_alt_outlined,
                  title: 'مساحة الأخصائي',
                  body: 'الخطة التدريبية، معايير الإتقان، التلقين ومراجعة البيانات',
                  color: Brand.sky,
                  onTap: () => _open(context, UserRole.specialist),
                ),
                const SizedBox(height: 28),
                const Text('لبدء جلسة للطفل: افتح مساحة ولي الأمر ثم اختر «ابدأ جلسة».',
                    textAlign: TextAlign.center, style: TextStyle(color: Brand.muted, fontSize: 13)),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}

class _RoleCard extends StatelessWidget {
  final IconData icon;
  final String title, body;
  final Color color;
  final VoidCallback onTap;
  const _RoleCard({required this.icon, required this.title, required this.body, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) => Material(
        color: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22), side: const BorderSide(color: Brand.line)),
        child: InkWell(
          borderRadius: BorderRadius.circular(22),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Row(children: [
              Container(
                width: 56, height: 56,
                decoration: BoxDecoration(color: color.withValues(alpha: .15), borderRadius: BorderRadius.circular(16)),
                child: Icon(icon, color: color, size: 30),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 2),
                  Text(body, style: const TextStyle(color: Brand.muted, fontSize: 13)),
                ]),
              ),
              const Icon(Icons.lock_outline, color: Brand.muted),
            ]),
          ),
        ),
      );
}
