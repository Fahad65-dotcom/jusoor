/// إضافة/تعديل بند في مكتبة المحتوى: الاسم، التصنيف، المهارات، الصور
/// (رسم أو صورة حقيقية من بيئة الطفل)، وتسجيل الاسم والسؤال بصوت بشري.
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/app_state.dart';
import '../../core/brand.dart';
import '../../data/models.dart';
import '../../services/media_service.dart';
import '../shared/audio_widgets.dart';
import '../shared/widgets.dart';

class ItemEditorScreen extends StatefulWidget {
  final String childId;
  final String? itemId;
  final String initialCategory;
  const ItemEditorScreen({super.key, required this.childId, this.itemId, this.initialCategory = 'object'});
  @override
  State<ItemEditorScreen> createState() => _ItemEditorScreenState();
}

class _ItemEditorScreenState extends State<ItemEditorScreen> {
  String? _id;
  Item? _item;
  final _label = TextEditingController();
  late String _category = widget.initialCategory;
  Set<String> _skills = {};

  @override
  void initState() {
    super.initState();
    _id = widget.itemId;
    if (_id == null) {
      _skills = _category == 'reinforcer' ? {'mand'} : {'listener', 'tact', 'matching'};
    }
    _load();
  }

  Future<void> _load() async {
    if (_id == null) return;
    final it = await context.read<AppState>().repo.item(_id!, childId: widget.childId);
    if (!mounted || it == null) return;
    setState(() {
      _item = it;
      _label.text = it.labelAr;
      _category = it.category;
      _skills = {...it.skillIds};
    });
  }

  /// يحفظ البيانات النصية وينشئ البند إذا كان جديدًا. يعيد المعرف.
  Future<String?> _ensureSaved() async {
    final repo = context.read<AppState>().repo;
    if (_label.text.trim().isEmpty) {
      toast(context, 'أدخل اسم العنصر أولًا');
      return null;
    }
    if (_id == null) {
      _id = await repo.createItem(childId: widget.childId, label: _label.text, category: _category, skillIds: _skills);
    } else if (!(_item?.isBuiltin ?? false)) {
      await repo.updateItem(_id!, label: _label.text, category: _category, skillIds: _skills);
    } else {
      await repo.updateItem(_id!, skillIds: _skills);
    }
    await _load();
    return _id;
  }

  Future<void> _addImage(bool camera, ImageKind kind) async {
    final id = await _ensureSaved();
    if (id == null) return;
    final p = await MediaService.instance.pickImage(camera: camera);
    if (p == null || !mounted) return;
    await context.read<AppState>().repo.addImage(itemId: id, childId: widget.childId, path: p, kind: kind);
    _load();
  }

  Future<void> _imageMenu(ImageKind kind) async {
    final camera = await showModalBottomSheet<bool>(
      context: context,
      builder: (c) => SafeArea(
        child: Wrap(children: [
          ListTile(leading: const Icon(Icons.photo_camera_outlined), title: const Text('التقاط بالكاميرا'), onTap: () => Navigator.pop(c, true)),
          ListTile(leading: const Icon(Icons.photo_library_outlined), title: const Text('اختيار من المعرض'), onTap: () => Navigator.pop(c, false)),
        ]),
      ),
    );
    if (camera != null) _addImage(camera, kind);
  }

  Future<void> _setAudio(String purpose, String path) async {
    final id = await _ensureSaved();
    if (id == null) {
      await MediaService.instance.deleteFiles([path]);
      return;
    }
    if (!mounted) return;
    final old = await context.read<AppState>().repo.setItemAudio(itemId: id, childId: widget.childId, purpose: purpose, path: path);
    if (old != null) await MediaService.instance.deleteFiles([old]);
    _load();
  }

  Future<void> _deleteAudio(String purpose) async {
    final old = await context.read<AppState>().repo.deleteItemAudio(_id!, widget.childId, purpose);
    if (old != null) await MediaService.instance.deleteFiles([old]);
    _load();
  }

  @override
  Widget build(BuildContext context) {
    final it = _item;
    final builtin = it?.isBuiltin ?? false;
    final ownImages = it?.images.where((i) => !i.isAsset).toList() ?? const <ItemImage>[];
    return Scaffold(
      appBar: AppBar(
        title: Text(_id == null ? 'عنصر جديد' : 'تعديل العنصر'),
        actions: [
          if (_id != null && !builtin)
            IconButton(
              tooltip: 'حذف العنصر',
              icon: const Icon(Icons.delete_outline),
              onPressed: () async {
                final ok = await confirmDialog(context, title: 'حذف العنصر', body: 'ستُحذف صوره وتسجيلاته.', confirm: 'حذف', danger: true);
                if (!ok || !context.mounted) return;
                final files = await context.read<AppState>().repo.deleteItem(_id!);
                await MediaService.instance.deleteFiles(files);
                if (context.mounted) Navigator.pop(context, true);
              },
            ),
        ],
      ),
      body: ListView(padding: readablePadding(context, const EdgeInsets.all(16)), children: [
        if (it != null)
          Center(
            child: Container(
              width: 160, height: 160,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24), border: Border.all(color: Brand.line)),
              child: ItemImageView(it.primaryImage, fit: BoxFit.contain),
            ),
          ),
        const SizedBox(height: 16),
        TextField(
          controller: _label,
          enabled: !builtin,
          decoration: InputDecoration(labelText: 'اسم العنصر', helperText: builtin ? 'عنصر مضمّن؛ يمكنك إضافة صورك وتسجيلاتك له' : null),
        ),
        const SizedBox(height: 14),
        if (!builtin)
          DropdownButtonFormField<String>(
            initialValue: _category,
            decoration: const InputDecoration(labelText: 'التصنيف'),
            items: [for (final e in Item.categoryNames.entries) DropdownMenuItem(value: e.key, child: Text(e.value))],
            onChanged: (v) => setState(() => _category = v ?? 'object'),
          ),
        const SectionTitle('المهارات التي يُستخدم فيها'),
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (final e in const {'mand': 'الطلب', 'listener': 'الاستجابة كمستمع', 'tact': 'التسمية', 'matching': 'المطابقة'}.entries)
            FilterChip(
              label: Text(e.value),
              selected: _skills.contains(e.key),
              onSelected: (v) => setState(() => v ? _skills.add(e.key) : _skills.remove(e.key)),
            ),
        ]),
        const SectionTitle('الصور'),
        const InfoBanner('الصور الحقيقية من بيئة الطفل (كوبه، حذاؤه، لعبته) تساعد على ربط التعلم بالواقع. تُستخدم أيضًا في «مطابقة الصورة بالشيء الحقيقي».',
            color: Brand.sage, icon: Icons.photo_outlined),
        const SizedBox(height: 10),
        Wrap(spacing: 10, runSpacing: 10, children: [
          for (final img in ownImages)
            Stack(children: [
              Container(
                width: 96, height: 96,
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: Brand.line)),
                clipBehavior: Clip.antiAlias,
                child: ItemImageView(img, fit: BoxFit.cover, size: 96),
              ),
              PositionedDirectional(
                start: 4, top: 4,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(color: Colors.white.withValues(alpha: .9), borderRadius: BorderRadius.circular(8)),
                  child: Text(img.kind == ImageKind.photo ? 'حقيقية' : 'رسم', style: const TextStyle(fontSize: 11)),
                ),
              ),
              PositionedDirectional(
                end: 0, top: 0,
                child: IconButton(
                  icon: const Icon(Icons.cancel, color: Brand.muted),
                  onPressed: () async {
                    final p = await context.read<AppState>().repo.deleteImage(img.id);
                    if (p != null) await MediaService.instance.deleteFiles([p]);
                    _load();
                  },
                ),
              ),
            ]),
        ]),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(child: OutlinedButton.icon(onPressed: () => _imageMenu(ImageKind.photo), icon: const Icon(Icons.add_a_photo_outlined), label: const Text('صورة حقيقية'))),
          const SizedBox(width: 10),
          Expanded(child: OutlinedButton.icon(onPressed: () => _imageMenu(ImageKind.illustration), icon: const Icon(Icons.add_photo_alternate_outlined), label: const Text('رسم/صورة توضيحية'))),
        ]),
        const SectionTitle('التسجيلات الصوتية (صوت بشري)'),
        AudioClipRow(
          label: 'اسم العنصر',
          hint: 'مثال: «كرة» — يُستخدم نموذجًا في التلقين اللفظي',
          path: it?.labelAudio?.path,
          isAsset: it?.labelAudio?.isAsset ?? false,
          onRecorded: (p) => _setAudio('label', p),
          onDelete: it?.labelAudio == null ? null : () => _deleteAudio('label'),
        ),
        const SizedBox(height: 10),
        AudioClipRow(
          label: 'سؤال المستمع',
          hint: 'مثال: «أين الكرة؟» — اختياري، وإلا يُشغَّل «أين» ثم الاسم',
          path: it?.questionAudio?.path,
          isAsset: it?.questionAudio?.isAsset ?? false,
          onRecorded: (p) => _setAudio('question', p),
          onDelete: it?.questionAudio == null ? null : () => _deleteAudio('question'),
        ),
        const SizedBox(height: 24),
        FilledButton(
          onPressed: () async {
            final id = await _ensureSaved();
            if (id != null && context.mounted) Navigator.pop(context, true);
          },
          child: const Text('حفظ'),
        ),
      ]),
    );
  }
}
