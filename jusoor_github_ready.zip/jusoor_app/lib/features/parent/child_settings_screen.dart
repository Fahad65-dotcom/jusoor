/// الإعدادات المسموح بها لولي الأمر: الملف الشخصي، مدة الجلسة، التعزيز،
/// الصوت والحركة، والتسجيلات العامة.
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/app_state.dart';
import '../../core/brand.dart';
import '../../data/models.dart';
import '../../data/repository.dart';
import '../../services/media_service.dart';
import '../shared/audio_widgets.dart';
import '../shared/widgets.dart';
import 'child_form.dart';

class ChildSettingsScreen extends StatefulWidget {
  final Child child;
  final VoidCallback onChanged;
  const ChildSettingsScreen({super.key, required this.child, required this.onChanged});
  @override
  State<ChildSettingsScreen> createState() => _ChildSettingsScreenState();
}

class _ChildSettingsScreenState extends State<ChildSettingsScreen> {
  ChildSettings? _s;
  final Map<String, AudioClip?> _generic = {};
  List<AudioClip> _praise = [];

  Repository get _repo => context.read<AppState>().repo;
  String get _cid => widget.child.id;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final s = await _repo.childSettings(_cid);
    for (final k in GenericAudioKeys.all.keys) {
      _generic[k] = await _repo.genericAudio(_cid, k);
    }
    final p = await _repo.praiseClips(_cid);
    if (mounted) {
      setState(() {
        _s = s;
        _praise = p;
      });
    }
  }

  Future<void> _save(ChildSettings s) async {
    setState(() => _s = s);
    await _repo.saveChildSettings(_cid, s);
  }

  @override
  Widget build(BuildContext context) {
    final s = _s;
    if (s == null) return const Center(child: CircularProgressIndicator());
    return ListView(padding: readablePadding(context, const EdgeInsets.all(16)), children: [
      Card(
        child: ListTile(
          leading: ChildAvatar(widget.child),
          title: Text(widget.child.name, style: const TextStyle(fontWeight: FontWeight.w700)),
          subtitle: Text(widget.child.ageLabel.isEmpty ? 'تعديل الملف' : widget.child.ageLabel),
          trailing: const Icon(Icons.edit_outlined),
          onTap: () async {
            final r = await Navigator.push<Child>(context, MaterialPageRoute(builder: (_) => ChildFormScreen(child: widget.child)));
            if (r != null) widget.onChanged();
          },
        ),
      ),
      const SectionTitle('الجلسة'),
      Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('مدة الجلسة الافتراضية: ${s.sessionMinutes} دقائق'),
            Slider(value: s.sessionMinutes.toDouble(), min: 3, max: 20, divisions: 17, label: '${s.sessionMinutes}',
                onChanged: (v) => _save(s.copyWith(sessionMinutes: v.round()))),
            const Text('المدة الموصى بها 5–10 دقائق.', style: TextStyle(color: Brand.muted, fontSize: 12)),
            const Divider(height: 28),
            Text(s.bonusEvery == 0 ? 'المكافأة الإضافية: معطلة' : 'مكافأة إضافية كل ${s.bonusEvery} إجابات صحيحة'),
            Slider(value: s.bonusEvery.toDouble(), min: 0, max: 10, divisions: 10, label: '${s.bonusEvery}',
                onChanged: (v) => _save(s.copyWith(bonusEvery: v.round()))),
          ]),
        ),
      ),
      const SectionTitle('التعزيز والصوت والحركة'),
      Card(
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
            child: Row(children: [
              const Icon(Icons.volume_up_outlined, color: Brand.muted),
              Expanded(
                child: Slider(value: s.volume, onChanged: (v) => _save(s.copyWith(volume: v))),
              ),
              Text(pct(s.volume * 100)),
            ]),
          ),
          SwitchListTile(title: const Text('النجوم'), subtitle: const Text('نجمة لكل إجابة صحيحة'), value: s.stars, onChanged: (v) => _save(s.copyWith(stars: v))),
          SwitchListTile(title: const Text('نغمة نجاح هادئة'), value: s.successChime, onChanged: (v) => _save(s.copyWith(successChime: v))),
          SwitchListTile(title: const Text('عبارات التشجيع المسجلة'), value: s.praiseVoice, onChanged: (v) => _save(s.copyWith(praiseVoice: v))),
          SwitchListTile(
            title: const Text('الرسوم المتحركة'),
            subtitle: const Text('أوقفها إذا كانت مشتتة للطفل'),
            value: s.animations,
            onChanged: (v) => _save(s.copyWith(animations: v)),
          ),
        ]),
      ),
      const SectionTitle('التعليمات المسجلة'),
      const InfoBanner('سجّل التعليمات بصوتك بلهجة طفلك. إن لم تُسجَّل تُعرض مكتوبة ليقرأها البالغ بصوته.'),
      const SizedBox(height: 10),
      for (final e in GenericAudioKeys.all.entries) ...[
        AudioClipRow(
          label: e.value,
          path: _generic[e.key]?.path,
          isAsset: _generic[e.key]?.isAsset ?? false,
          onRecorded: (p) async {
            final old = await _repo.setGenericAudio(_cid, e.key, p);
            if (old != null) await MediaService.instance.deleteFiles([old]);
            _load();
          },
          onDelete: _generic[e.key] == null
              ? null
              : () async {
                  final old = await _repo.deleteAudioClip(_generic[e.key]!.id);
                  if (old != null) await MediaService.instance.deleteFiles([old]);
                  _load();
                },
        ),
        const SizedBox(height: 8),
      ],
      SectionTitle('عبارات التشجيع (${_praise.length})'),
      for (final p in _praise) ...[
        AudioClipRow(
          label: 'عبارة تشجيع',
          path: p.path,
          isAsset: p.isAsset,
          onRecorded: (np) async {
            final old = await _repo.deleteAudioClip(p.id);
            if (old != null) await MediaService.instance.deleteFiles([old]);
            await _repo.addPraiseClip(_cid, np);
            _load();
          },
          onDelete: () async {
            final old = await _repo.deleteAudioClip(p.id);
            if (old != null) await MediaService.instance.deleteFiles([old]);
            _load();
          },
        ),
        const SizedBox(height: 8),
      ],
      AudioClipRow(
        label: 'إضافة عبارة جديدة',
        hint: 'مثال: «أحسنت!»، «رائع!»، «شاطر!»',
        path: null,
        onRecorded: (p) async {
          await _repo.addPraiseClip(_cid, p);
          _load();
        },
      ),
      const SizedBox(height: 32),
    ]);
  }
}
