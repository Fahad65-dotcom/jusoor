/// مكتبة الصور والأصوات القابلة للتعديل.
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/app_state.dart';
import '../../core/brand.dart';
import '../../data/models.dart';
import '../shared/widgets.dart';
import 'item_editor.dart';

class LibraryScreen extends StatefulWidget {
  final String childId;
  const LibraryScreen({super.key, required this.childId});
  @override
  State<LibraryScreen> createState() => _LibraryScreenState();
}

class _LibraryScreenState extends State<LibraryScreen> {
  List<Item>? _items;
  String _filter = 'all';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final i = await context.read<AppState>().repo.items(widget.childId);
    if (mounted) setState(() => _items = i);
  }

  Future<void> _open({String? id}) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => ItemEditorScreen(childId: widget.childId, itemId: id)));
    _load();
  }

  @override
  Widget build(BuildContext context) {
    final items = _items;
    if (items == null) return const Center(child: CircularProgressIndicator());
    final shown = items.where((i) => switch (_filter) {
          'all' => true,
          'mine' => !i.isBuiltin || i.images.any((x) => !x.isAsset),
          'no_audio' => i.labelAudio == null,
          _ => i.category == _filter,
        }).toList();
    final noAudio = items.where((i) => i.labelAudio == null).length;
    return Scaffold(
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _open(),
        icon: const Icon(Icons.add),
        label: const Text('إضافة عنصر'),
      ),
      body: CustomScrollView(slivers: [
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
          sliver: SliverToBoxAdapter(
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              if (noAudio > 0)
                InfoBanner('$noAudio عنصرًا بلا تسجيل صوتي. سجّل الأسماء بصوتك أو صوت الأخصائي (صوت بشري واضح) لاستخدامها في التلقين اللفظي.',
                    color: Brand.apricot, icon: Icons.mic_none),
              const SizedBox(height: 10),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(children: [
                  for (final e in {
                    'all': 'الكل',
                    'mine': 'صوري',
                    'object': 'أشياء',
                    'animal': 'حيوانات',
                    'food': 'أطعمة',
                    'reinforcer': 'معززات',
                    'custom': 'أخرى',
                    'no_audio': 'بلا تسجيل',
                  }.entries)
                    Padding(
                      padding: const EdgeInsetsDirectional.only(end: 8),
                      child: ChoiceChip(label: Text(e.value), selected: _filter == e.key, onSelected: (_) => setState(() => _filter = e.key)),
                    ),
                ]),
              ),
              const SizedBox(height: 12),
            ]),
          ),
        ),
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 96),
          sliver: SliverGrid(
            gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(maxCrossAxisExtent: 150, mainAxisSpacing: 10, crossAxisSpacing: 10, childAspectRatio: .82),
            delegate: SliverChildBuilderDelegate(
              (c, i) {
                final it = shown[i];
                return Material(
                  color: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: const BorderSide(color: Brand.line)),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(18),
                    onTap: () => _open(id: it.id),
                    child: Padding(
                      padding: const EdgeInsets.all(10),
                      child: Column(children: [
                        Expanded(child: ItemImageView(it.primaryImage)),
                        const SizedBox(height: 6),
                        Row(children: [
                          Expanded(child: Text(it.labelAr, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600))),
                          Icon(it.labelAudio != null ? Icons.graphic_eq : Icons.mic_off_outlined, size: 16,
                              color: it.labelAudio != null ? Brand.teal : Brand.line),
                          if (it.photo != null) const Icon(Icons.photo_camera, size: 16, color: Brand.sage),
                        ]),
                      ]),
                    ),
                  ),
                );
              },
              childCount: shown.length,
            ),
          ),
        ),
      ]),
    );
  }
}
