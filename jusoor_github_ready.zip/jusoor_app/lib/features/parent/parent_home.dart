/// مساحة ولي الأمر. النسخة الأولى تدعم ملف طفل واحد على الجهاز
/// (دعم أكثر من طفل وأكثر من جهاز مؤجل للمرحلة الثانية).
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/app_state.dart';
import '../../core/brand.dart';
import '../../data/models.dart';
import '../shared/mascot.dart';
import '../shared/widgets.dart';
import 'child_form.dart';
import 'child_hub.dart';

const int kMaxChildrenV1 = 1;

class ParentHome extends StatefulWidget {
  const ParentHome({super.key});
  @override
  State<ParentHome> createState() => _ParentHomeState();
}

class _ParentHomeState extends State<ParentHome> {
  List<Child>? _children;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final c = await context.read<AppState>().repo.children();
    if (mounted) setState(() => _children = c);
  }

  @override
  Widget build(BuildContext context) {
    final kids = _children;
    if (kids == null) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (kids.isNotEmpty) {
      return ChildHub(child: kids.first, onChanged: _load);
    }
    return Scaffold(
      appBar: AppBar(title: const Text('مساحة ولي الأمر')),
      body: Center(
        child: EmptyState(
          icon: Icons.child_care,
          title: 'أنشئ ملف طفلك للبدء',
          body: 'سنجهز تلقائيًا أهداف المستوى المبتدئ الأربعة: الطلب، والاستجابة كمستمع، والتسمية، والمطابقة البصرية.',
          action: FilledButton.icon(
            icon: const Icon(Icons.add),
            label: const Text('إنشاء ملف الطفل'),
            onPressed: () async {
              final c = await Navigator.push<Child>(context, MaterialPageRoute(builder: (_) => const ChildFormScreen()));
              if (c != null) _load();
            },
          ),
        ),
      ),
      bottomNavigationBar: const Padding(
        padding: EdgeInsets.all(16),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Mascot(size: 44),
          SizedBox(width: 8),
          Flexible(child: Text(Brand.disclaimerAr, style: TextStyle(fontSize: 12, color: Brand.muted))),
        ]),
      ),
    );
  }
}
