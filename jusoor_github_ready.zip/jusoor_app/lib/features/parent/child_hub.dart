/// لوحة تحكم ولي الأمر لطفل واحد: المتابعة، الجلسات، المعززات، المكتبة،
/// الإعدادات.
library;

import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/app_state.dart';
import '../../core/brand.dart';
import '../../data/models.dart';
import '../../services/kiosk_service.dart';
import '../../data/repository.dart';
import '../../engine/dtt_engine.dart';
import '../../engine/mastery.dart';
import '../../engine/metrics.dart';
import '../child/session_screen.dart';
import '../settings/data_screen.dart';
import '../shared/dashboard.dart';
import '../shared/widgets.dart';
import 'child_settings_screen.dart';
import 'library_screen.dart';
import 'reinforcers_screen.dart';

class ChildHub extends StatefulWidget {
  final Child child;
  final VoidCallback onChanged;
  const ChildHub({super.key, required this.child, required this.onChanged});
  @override
  State<ChildHub> createState() => _ChildHubState();
}

class _ChildHubState extends State<ChildHub> {
  int _tab = 0;
  int _refresh = 0;

  @override
  Widget build(BuildContext context) {
    final c = widget.child;
    final pages = [
      ProgressDashboard(key: ValueKey('d$_refresh'), childId: c.id),
      SessionsTab(key: ValueKey('s$_refresh'), child: c, onSessionDone: () => setState(() => _refresh++)),
      ReinforcersScreen(childId: c.id),
      LibraryScreen(childId: c.id),
      ChildSettingsScreen(child: c, onChanged: widget.onChanged),
    ];
    const titles = ['المتابعة', 'الجلسات', 'المعززات', 'المكتبة', 'الإعدادات'];
    return Scaffold(
      appBar: AppBar(
        title: Row(children: [
          ChildAvatar(c, radius: 18),
          const SizedBox(width: 10),
          Flexible(child: Text('${c.name} · ${titles[_tab]}', overflow: TextOverflow.ellipsis)),
        ]),
        actions: [
          IconButton(
            tooltip: 'البيانات والخصوصية',
            icon: const Icon(Icons.shield_outlined),
            onPressed: () async {
              await Navigator.push(context, MaterialPageRoute(builder: (_) => const DataScreen()));
              widget.onChanged();
            },
          ),
        ],
      ),
      body: pages[_tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.insights_outlined), selectedIcon: Icon(Icons.insights), label: 'المتابعة'),
          NavigationDestination(icon: Icon(Icons.play_circle_outline), selectedIcon: Icon(Icons.play_circle), label: 'الجلسات'),
          NavigationDestination(icon: Icon(Icons.star_outline), selectedIcon: Icon(Icons.star), label: 'المعززات'),
          NavigationDestination(icon: Icon(Icons.photo_library_outlined), selectedIcon: Icon(Icons.photo_library), label: 'المكتبة'),
          NavigationDestination(icon: Icon(Icons.tune_outlined), selectedIcon: Icon(Icons.tune), label: 'الإعدادات'),
        ],
      ),
    );
  }
}

/// الحد الأدنى من البنود لتشغيل كل نوع.
int minItemsFor(EngineKind k) => switch (k) {
      EngineKind.mand => 1,
      EngineKind.tact => 1,
      EngineKind.matching => 2,
      EngineKind.listener => 3,
    };

class SessionsTab extends StatefulWidget {
  final Child child;
  final VoidCallback onSessionDone;
  const SessionsTab({super.key, required this.child, required this.onSessionDone});
  @override
  State<SessionsTab> createState() => _SessionsTabState();
}

class _TargetRow {
  final Target target;
  final Skill skill;
  final MasteryResult mastery;
  final int itemCount;
  final bool selected;
  _TargetRow(this.target, this.skill, this.mastery, this.itemCount, this.selected);
}

class _SessionsTabState extends State<SessionsTab> {
  List<_TargetRow>? _rows;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final repo = context.read<AppState>().repo;
    final skills = {for (final s in await repo.skills()) s.id: s};
    final settings = await repo.settings('child:${widget.child.id}');
    final rows = <_TargetRow>[];
    for (final t in await repo.targets(widget.child.id)) {
      final sk = skills[t.skillId];
      if (sk == null || !sk.isAvailable || !t.enabledForParent || t.status != TargetStatus.active) continue;
      final m = await computeMastery(repo, t);
      final n = (await repo.resolveTargetItems(t)).length;
      rows.add(_TargetRow(t, sk, m, n, (settings['parent_selected:${t.id}'] ?? '1') == '1'));
    }
    if (mounted) setState(() => _rows = rows);
  }

  Future<void> _start(_TargetRow r) async {
    final kind = engineKindFrom(r.skill.engine)!;
    if (r.itemCount < minItemsFor(kind)) {
      return toast(context, r.target.itemSource == 'with_photo'
          ? 'أضف صورًا حقيقية لبندين على الأقل من «المكتبة» أولًا'
          : 'يلزم ${minItemsFor(kind)} بنود على الأقل لهذا الهدف');
    }
    if (await KioskService.shouldSuggestGuidedAccess()) {
      if (!mounted) return;
      final cont = await showDialog<bool>(
        context: context,
        builder: (c) => AlertDialog(
          title: const Text('فعّل الوصول الموجّه'),
          content: const Text(
              'لا يسمح iOS للتطبيق بقفل نفسه. لمنع الطفل من الخروج: الإعدادات ← تسهيلات الاستخدام ← الوصول الموجّه، ثم انقر الزر الجانبي 3 مرات بعد بدء الجلسة.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('رجوع')),
            FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('متابعة')),
          ],
        ),
      );
      if (cont != true) return;
    }
    if (!mounted) return;
    final s = context.read<AppState>();
    final settings = await s.repo.childSettings(widget.child.id);
    final parent = await s.repo.userByRole(UserRole.parent);
    final last = (await s.repo.settings('child:${widget.child.id}'))['last_trainer'];
    if (!mounted) return;
    final trainer = TextEditingController(text: last ?? parent?.name ?? '');
    var minutes = settings.sessionMinutes;
    final go = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Brand.sand,
      builder: (c) => StatefulBuilder(
        builder: (c, set) => Padding(
          padding: EdgeInsets.fromLTRB(20, 20, 20, 20 + MediaQuery.of(c).viewInsets.bottom),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Text(r.target.titleAr, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            const SizedBox(height: 4),
            Text('${r.skill.nameAr} · ${r.target.trialsPerSession} تجارب', style: const TextStyle(color: Brand.muted)),
            const SizedBox(height: 16),
            TextField(controller: trainer, decoration: const InputDecoration(labelText: 'اسم المدرب في هذه الجلسة')),
            const SizedBox(height: 14),
            Text('مدة الجلسة: $minutes دقائق'),
            Slider(value: minutes.toDouble(), min: 3, max: 20, divisions: 17, label: '$minutes',
                onChanged: (v) => set(() => minutes = v.round())),
            if (Platform.isIOS)
              const InfoBanner('لقفل الجهاز على التطبيق: فعّل «الوصول الموجّه» من الإعدادات ← تسهيلات الاستخدام، ثم اضغط زر الجانب ثلاث مرات بعد بدء الجلسة.'),
            if (Platform.isAndroid)
              const InfoBanner('سيُطلب تثبيت الشاشة لمنع الطفل من الخروج. للخروج من الجلسة: اضغط مطولًا على القفل أعلى الشاشة ثم أدخل الرمز.'),
            const SizedBox(height: 16),
            FilledButton.icon(
              icon: const Icon(Icons.play_arrow_rounded),
              label: const Text('ابدأ الجلسة'),
              onPressed: () => Navigator.pop(c, true),
            ),
          ]),
        ),
      ),
    );
    if (go != true || !mounted) return;
    if (trainer.text.trim().isNotEmpty) {
      await s.repo.setSetting('child:${widget.child.id}', 'last_trainer', trainer.text.trim());
    }
    if (!mounted) return;
    await Navigator.of(context).push(MaterialPageRoute(
      fullscreenDialog: true,
      builder: (_) => ChildSessionScreen(
        child: widget.child,
        target: r.target,
        skill: r.skill,
        trainerName: trainer.text.trim(),
        minutes: minutes,
      ),
    ));
    widget.onSessionDone();
  }

  @override
  Widget build(BuildContext context) {
    final rows = _rows;
    if (rows == null) return const Center(child: CircularProgressIndicator());
    if (rows.isEmpty) {
      return const EmptyState(title: 'لا توجد أهداف متاحة', body: 'يتيح الأخصائي الأهداف من مساحته.');
    }
    final selected = rows.where((r) => r.selected).toList();
    return ListView(padding: readablePadding(context, const EdgeInsets.all(16)), children: [
      const InfoBanner('الجلسة القصيرة أفضل: 5 إلى 10 دقائق. اختر هدفًا ثم سلّم الجهاز للطفل.'),
      const SectionTitle('ابدأ جلسة'),
      if (selected.isEmpty) const Text('لم تختر أي هدف بعد. اختر من القائمة أدناه.', style: TextStyle(color: Brand.muted)),
      for (final r in selected) ...[
        _TargetCard(row: r, onStart: () => _start(r)),
        const SizedBox(height: 10),
      ],
      SectionTitle('الأهداف التي يتيحها الأخصائي (${rows.length})'),
      Card(
        child: Column(children: [
          for (final r in rows)
            CheckboxListTile(
              value: r.selected,
              title: Text(r.target.titleAr),
              subtitle: Text(r.skill.nameAr),
              onChanged: (v) async {
                await context.read<AppState>().repo.setSetting(
                    'child:${widget.child.id}', 'parent_selected:${r.target.id}', v == true ? '1' : '0');
                _load();
              },
            ),
        ]),
      ),
    ]);
  }
}

class _TargetCard extends StatelessWidget {
  final _TargetRow row;
  final VoidCallback onStart;
  const _TargetCard({required this.row, required this.onStart});

  @override
  Widget build(BuildContext context) {
    final m = row.mastery;
    final color = skillColor(row.skill.id);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(children: [
          Container(
            width: 52, height: 52,
            decoration: BoxDecoration(color: color.withValues(alpha: .15), borderRadius: BorderRadius.circular(16)),
            child: Icon(skillIcon(row.skill.id), color: color),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(row.skill.nameAr, style: TextStyle(color: color, fontWeight: FontWeight.w700, fontSize: 13)),
              Text(row.target.titleAr, style: const TextStyle(fontWeight: FontWeight.w600)),
              const SizedBox(height: 4),
              Text('${m.labelAr} · ${m.streak}/${m.requiredSessions} جلسات محققة · ${row.itemCount} بنود',
                  style: const TextStyle(color: Brand.muted, fontSize: 12)),
            ]),
          ),
          FilledButton(onPressed: onStart, child: const Text('ابدأ')),
        ]),
      ),
    );
  }
}

/// حساب الإتقان لهدف من السجلات الأصلية.
Future<MasteryResult> computeMastery(Repository repo, Target t) async {
  final sessions = await repo.sessions(t.childId, targetId: t.id);
  final trials = await repo.trials(targetId: t.id);
  final sum = SessionSummary.build(sessions, trials, selectionBased: t.skillId == 'mand');
  return MasteryEvaluator.evaluate(sum, t.mastery, fieldSizes: t.fieldSizes);
}

Color skillColor(String id) => switch (id) {
      'mand' => Brand.apricot,
      'listener' => Brand.sky,
      'tact' => Brand.teal,
      'matching' => Brand.sage,
      _ => Brand.muted,
    };

IconData skillIcon(String id) => switch (id) {
      'mand' => Icons.front_hand_outlined,
      'listener' => Icons.hearing_outlined,
      'tact' => Icons.record_voice_over_outlined,
      'matching' => Icons.join_inner,
      _ => Icons.extension_outlined,
    };
