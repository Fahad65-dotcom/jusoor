/// إنشاء ملف الطفل أو تعديله (الحد الأدنى من البيانات).
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/app_state.dart';
import '../../core/brand.dart';
import '../../data/models.dart';
import '../../services/media_service.dart';
import '../shared/widgets.dart';

class ChildFormScreen extends StatefulWidget {
  final Child? child;
  const ChildFormScreen({super.key, this.child});
  @override
  State<ChildFormScreen> createState() => _ChildFormScreenState();
}

class _ChildFormScreenState extends State<ChildFormScreen> {
  late final _name = TextEditingController(text: widget.child?.name);
  DateTime? _birth;
  String? _photo;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _birth = widget.child?.birthDate;
    _photo = widget.child?.photoPath;
  }

  Future<void> _pickPhoto(bool camera) async {
    final p = await MediaService.instance.pickImage(camera: camera);
    if (p != null) setState(() => _photo = p);
  }

  Future<void> _save() async {
    if (_name.text.trim().isEmpty) return toast(context, 'أدخل اسم الطفل');
    setState(() => _busy = true);
    final repo = context.read<AppState>().repo;
    if (widget.child == null) {
      final c = await repo.createChild(name: _name.text, birthDate: _birth, photoPath: _photo);
      if (mounted) Navigator.pop(context, c);
    } else {
      final old = widget.child!.photoPath;
      final c = Child(id: widget.child!.id, name: _name.text.trim(), birthDate: _birth, photoPath: _photo, createdAt: widget.child!.createdAt);
      await repo.updateChild(c);
      if (old != null && old != _photo) await MediaService.instance.deleteFiles([old]);
      if (mounted) Navigator.pop(context, c);
    }
  }

  @override
  Widget build(BuildContext context) {
    final preview = Child(id: '', name: _name.text.isEmpty ? '؟' : _name.text, photoPath: _photo, createdAt: 0);
    return Scaffold(
      appBar: AppBar(title: Text(widget.child == null ? 'ملف الطفل' : 'تعديل ملف الطفل')),
      body: ListView(padding: readablePadding(context, const EdgeInsets.all(20)), children: [
        Center(child: ChildAvatar(preview, radius: 52)),
        const SizedBox(height: 10),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          TextButton.icon(onPressed: () => _pickPhoto(true), icon: const Icon(Icons.photo_camera_outlined), label: const Text('الكاميرا')),
          TextButton.icon(onPressed: () => _pickPhoto(false), icon: const Icon(Icons.photo_library_outlined), label: const Text('المعرض')),
          if (_photo != null)
            TextButton.icon(onPressed: () => setState(() => _photo = null), icon: const Icon(Icons.close), label: const Text('إزالة')),
        ]),
        const Text('الصورة الشخصية اختيارية وتبقى على هذا الجهاز.', textAlign: TextAlign.center, style: TextStyle(color: Brand.muted, fontSize: 12)),
        const SizedBox(height: 20),
        TextField(controller: _name, onChanged: (_) => setState(() {}), decoration: const InputDecoration(labelText: 'اسم الطفل')),
        const SizedBox(height: 14),
        OutlinedButton.icon(
          icon: const Icon(Icons.cake_outlined),
          label: Text(_birth == null
              ? 'تاريخ الميلاد (اختياري)'
              : 'تاريخ الميلاد: ${_birth!.year}/${_birth!.month}/${_birth!.day}'),
          onPressed: () async {
            final now = DateTime.now();
            final d = await showDatePicker(
              context: context,
              initialDate: _birth ?? DateTime(now.year - 4),
              firstDate: DateTime(now.year - 14),
              lastDate: now,
            );
            if (d != null) setState(() => _birth = d);
          },
        ),
        const SizedBox(height: 28),
        FilledButton(onPressed: _busy ? null : _save, child: const Text('حفظ')),
      ]),
    );
  }
}
