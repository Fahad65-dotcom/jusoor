/// المعززات المفضلة للطفل: تُعرض في مهارة الطلب وتُقدَّم كمكافأة إضافية.
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/app_state.dart';
import '../../core/brand.dart';
import '../../data/models.dart';
import '../shared/widgets.dart';
import 'item_editor.dart';

class ReinforcersScreen extends StatefulWidget {
  final String childId;
  const ReinforcersScreen({super.key, required this.childId});
  @override
  State<ReinforcersScreen> createState() => _ReinforcersScreenState();
}

class _ReinforcersScreenState extends State<ReinforcersScreen> {
  List<(Reinforcer, Item)>? _rows;
  List<Item> _all = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final repo = context.read<AppState>().repo;
    final items = await repo.items(widget.childId);
    final byId = {for (final i in items) i.id: i};
    final r = await repo.reinforcers(widget.childId);
    if (mounted) {
      setState(() {
        _all = items;
        _rows = [for (final x in r) if (byId[x.itemId] != null) (x, byId[x.itemId]!)];
      });
    }
  }

  Future<void> _add() async {
    final have = _rows!.map((r) => r.$2.id).toSet();
    final candidates = _all.where((i) => !have.contains(i.id)).toList();
    final choice = await showModalBottomSheet<Object>(
      context: context,
      isScrollControlled: true,
      builder: (c) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: .7,
        builder: (c, sc) => ListView(controller: sc, padding: const EdgeInsets.all(16), children: [
          FilledButton.icon(
            icon: const Icon(Icons.add_a_photo_outlined),
            label: const Text('معزز جديد بصورتي وصوتي'),
            onPressed: () => Navigator.pop(c, 'new'),
          ),
          const SectionTitle('أو اختر من المكتبة'),
          for (final i in candidates)
            ListTile(
              leading: SizedBox(width: 44, child: ItemImageView(i.primaryImage)),
              title: Text(i.labelAr),
              subtitle: Text(Item.categoryNames[i.category] ?? ''),
              onTap: () => Navigator.pop(c, i),
            ),
        ]),
      ),
    );
    if (!mounted || choice == null) return;
    final repo = context.read<AppState>().repo;
    if (choice == 'new') {
      await Navigator.push(context, MaterialPageRoute(
          builder: (_) => ItemEditorScreen(childId: widget.childId, initialCategory: 'reinforcer')));
      // أضف أحدث عنصر من فئة المعززات أنشأه ولي الأمر.
      final items = await repo.items(widget.childId);
      final mine = items.where((i) => !i.isBuiltin && i.category == 'reinforcer' && !have.contains(i.id));
      for (final i in mine) {
        await repo.addReinforcer(widget.childId, i.id);
      }
    } else if (choice is Item) {
      await repo.addReinforcer(widget.childId, choice.id);
    }
    _load();
  }

  @override
  Widget build(BuildContext context) {
    final rows = _rows;
    if (rows == null) return const Center(child: CircularProgressIndicator());
    final enabled = rows.where((r) => r.$1.enabled).length;
    return Scaffold(
      floatingActionButton: FloatingActionButton.extended(onPressed: _add, icon: const Icon(Icons.add), label: const Text('إضافة معزز')),
      body: ListView(padding: readablePadding(context, const EdgeInsets.fromLTRB(16, 12, 16, 96)), children: [
        InfoBanner('المعززات المفعّلة ($enabled) تظهر للطفل في مهارة «الطلب» ($enabled من 10 مطلوبة لهدف الإتقان)، ويُختار منها المكافأة الإضافية. أضف ما يحبه طفلك فعلًا.',
            color: Brand.apricot, icon: Icons.star_outline),
        const SizedBox(height: 12),
        for (final (r, i) in rows)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Card(
              child: ListTile(
                leading: SizedBox(width: 48, height: 48, child: ItemImageView(i.primaryImage)),
                title: Text(i.labelAr),
                subtitle: Text(i.labelAudio == null ? 'بلا تسجيل صوتي' : 'له تسجيل صوتي'),
                onTap: () async {
                  await Navigator.push(context, MaterialPageRoute(builder: (_) => ItemEditorScreen(childId: widget.childId, itemId: i.id)));
                  _load();
                },
                trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                  Switch(
                    value: r.enabled,
                    onChanged: (v) async {
                      await context.read<AppState>().repo.setReinforcerEnabled(r.id, v);
                      _load();
                    },
                  ),
                  IconButton(
                    icon: const Icon(Icons.close),
                    tooltip: 'إزالة',
                    onPressed: () async {
                      await context.read<AppState>().repo.removeReinforcer(r.id);
                      _load();
                    },
                  ),
                ]),
              ),
            ),
          ),
      ]),
    );
  }
}
