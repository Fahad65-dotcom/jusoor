/// لوحة متابعة الأداء وتقارير الأهداف والجلسات. كل الأرقام محسوبة من سجلات
/// التجارب الأصلية لحظة العرض.
library;

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/app_state.dart';
import '../../core/brand.dart';
import '../../data/models.dart';
import '../../engine/mastery.dart';
import '../../engine/metrics.dart';
import '../../services/media_service.dart';
import '../parent/child_hub.dart' show skillColor, skillIcon;
import 'widgets.dart';

class _TargetData {
  final Target target;
  final Skill skill;
  final List<SessionSummary> sessions;
  final MasteryResult mastery;
  final PerformanceStats stats;
  _TargetData(this.target, this.skill, this.sessions, this.mastery, this.stats);
}

class ProgressDashboard extends StatefulWidget {
  final String childId;
  final bool specialist;
  const ProgressDashboard({super.key, required this.childId, this.specialist = false});
  @override
  State<ProgressDashboard> createState() => _ProgressDashboardState();
}

class _ProgressDashboardState extends State<ProgressDashboard> {
  List<_TargetData>? _data;
  PerformanceStats? _overall;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final repo = context.read<AppState>().repo;
    final skills = {for (final s in await repo.skills()) s.id: s};
    final allTrials = await repo.trials(childId: widget.childId);
    final allSessions = await repo.sessions(widget.childId);
    final out = <_TargetData>[];
    for (final t in await repo.targets(widget.childId)) {
      final sk = skills[t.skillId];
      if (sk == null) continue;
      final tt = allTrials.where((x) => x.targetId == t.id).toList();
      final ss = allSessions.where((x) => x.targetId == t.id).toList();
      final sum = SessionSummary.build(ss, tt, selectionBased: t.skillId == 'mand');
      out.add(_TargetData(t, sk, sum, MasteryEvaluator.evaluate(sum, t.mastery, fieldSizes: t.fieldSizes),
          PerformanceStats.fromTrials(tt)));
    }
    if (mounted) {
      setState(() {
        _data = out;
        _overall = PerformanceStats.fromTrials(allTrials);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final data = _data, o = _overall;
    if (data == null || o == null) return const Center(child: CircularProgressIndicator());
    final mastered = data.where((d) => d.mastery.state == MasteryState.mastered).toList();
    final needs = data.where((d) => d.mastery.needsMoreTraining).toList();
    final wide = MediaQuery.of(context).size.width > 700;
    final tiles = [
      StatTile(label: 'جلسات منفذة', value: '${o.sessions}', color: Brand.teal, icon: Icons.event_available_outlined),
      StatTile(label: 'تجارب', value: '${o.trials}', color: Brand.sky, icon: Icons.touch_app_outlined),
      StatTile(label: 'استجابات صحيحة', value: pct(o.correctPct), color: Brand.sage, icon: Icons.check_circle_outline),
      StatTile(label: 'مستقلة', value: pct(o.independentPct), color: Brand.tealDark, icon: Icons.emoji_people_outlined),
      StatTile(label: 'بمساعدة', value: pct(o.promptedPct), color: Brand.apricot, icon: Icons.support_outlined),
      StatTile(label: 'أهداف متقنة', value: '${mastered.length}/${data.length}', color: Brand.sage, icon: Icons.workspace_premium_outlined),
    ];
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(padding: const EdgeInsets.all(16), children: [
        GridView.count(
          crossAxisCount: wide ? 3 : 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
          childAspectRatio: wide ? 3.2 : 2.1,
          children: tiles,
        ),
        if (o.trials == 0) ...[
          const SizedBox(height: 16),
          const InfoBanner('لا توجد بيانات بعد. ستظهر الرسوم البيانية بعد أول جلسة.'),
        ],
        if (o.trials > 0) ...[
          const SectionTitle('تطور الاستجابات المستقلة عبر الجلسات'),
          Card(child: Padding(padding: const EdgeInsets.fromLTRB(8, 20, 16, 8), child: _MultiTargetChart(data))),
        ],
        if (needs.isNotEmpty) ...[
          const SectionTitle('تحتاج إلى استمرار التدريب'),
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (final d in needs) Chip(avatar: Icon(skillIcon(d.skill.id), size: 18, color: skillColor(d.skill.id)), label: Text(d.skill.nameAr)),
          ]),
        ],
        if (mastered.isNotEmpty) ...[
          const SectionTitle('أهداف أتقنها الطفل'),
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (final d in mastered)
              Chip(
                backgroundColor: Brand.sageSoft,
                avatar: const Icon(Icons.workspace_premium, size: 18, color: Brand.sage),
                label: Text(d.target.titleAr),
              ),
          ]),
        ],
        const SectionTitle('حالة كل هدف'),
        for (final d in data) ...[
          _TargetSummaryCard(d: d, onTap: () async {
            await Navigator.push(context, MaterialPageRoute(
                builder: (_) => TargetReportScreen(targetId: d.target.id, specialist: widget.specialist)));
            _load();
          }),
          const SizedBox(height: 10),
        ],
        const SizedBox(height: 12),
        const Text(Brand.disclaimerAr, textAlign: TextAlign.center, style: TextStyle(color: Brand.muted, fontSize: 12)),
      ]),
    );
  }
}

class _TargetSummaryCard extends StatelessWidget {
  final _TargetData d;
  final VoidCallback onTap;
  const _TargetSummaryCard({required this.d, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final m = d.mastery;
    final c = skillColor(d.skill.id);
    final stateColor = switch (m.state) {
      MasteryState.mastered => Brand.sage,
      MasteryState.inProgress => Brand.apricot,
      MasteryState.notStarted => Brand.muted,
    };
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Icon(skillIcon(d.skill.id), color: c, size: 20),
              const SizedBox(width: 8),
              Expanded(child: Text(d.skill.nameAr, style: TextStyle(color: c, fontWeight: FontWeight.w700))),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(color: stateColor.withValues(alpha: .15), borderRadius: BorderRadius.circular(20)),
                child: Text(m.labelAr, style: TextStyle(color: stateColor == Brand.muted ? Brand.muted : Brand.ink, fontSize: 12, fontWeight: FontWeight.w600)),
              ),
            ]),
            const SizedBox(height: 6),
            Text(d.target.titleAr, style: const TextStyle(fontWeight: FontWeight.w600)),
            if (d.target.status == TargetStatus.paused)
              const Text('موقوف مؤقتًا من الأخصائي', style: TextStyle(color: Brand.muted, fontSize: 12)),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: PercentBar(d.stats.independentPct, color: c)),
              const SizedBox(width: 10),
              Text('مستقلة ${pct(d.stats.independentPct)}', style: const TextStyle(fontSize: 12)),
            ]),
            const SizedBox(height: 8),
            Text(
              '${d.stats.sessions} جلسات · ${d.stats.trials} تجربة · سلسلة الإتقان ${m.streak}/${m.requiredSessions}'
              '${d.target.mastery.minTrainers > 1 ? ' · مدربون ${m.trainersInStreak}/${d.target.mastery.minTrainers}' : ''}'
              '${d.target.mastery.minDistinctIndependent > 0 ? ' · عناصر مختلفة ${m.distinctItems}/${d.target.mastery.minDistinctIndependent}' : ''}'
              '${d.target.fieldSizes.length > 1 ? ' · الخيارات الحالية ${m.currentFieldSize}' : ''}',
              style: const TextStyle(color: Brand.muted, fontSize: 12),
            ),
          ]),
        ),
      ),
    );
  }
}

class _MultiTargetChart extends StatelessWidget {
  final List<_TargetData> data;
  const _MultiTargetChart(this.data);

  @override
  Widget build(BuildContext context) {
    final lines = <LineChartBarData>[];
    var maxX = 1;
    for (final d in data) {
      if (d.sessions.isEmpty) continue;
      maxX = d.sessions.length > maxX ? d.sessions.length : maxX;
      lines.add(LineChartBarData(
        spots: [for (var i = 0; i < d.sessions.length; i++) FlSpot(i + 1, d.sessions[i].stats.independentPct)],
        color: skillColor(d.skill.id),
        barWidth: 3,
        isCurved: false,
        dotData: const FlDotData(show: true),
      ));
    }
    return Column(children: [
      SizedBox(height: 200, child: Directionality(textDirection: TextDirection.ltr, child: LineChart(_chartData(lines, maxX)))),
      const SizedBox(height: 8),
      Wrap(spacing: 14, children: [
        for (final d in data.where((d) => d.sessions.isNotEmpty))
          Row(mainAxisSize: MainAxisSize.min, children: [
            Container(width: 12, height: 12, decoration: BoxDecoration(color: skillColor(d.skill.id), shape: BoxShape.circle)),
            const SizedBox(width: 4),
            Text(d.skill.nameAr, style: const TextStyle(fontSize: 12)),
          ]),
      ]),
    ]);
  }
}

LineChartData _chartData(List<LineChartBarData> lines, int maxX, {double? threshold}) => LineChartData(
      minY: 0,
      maxY: 100,
      minX: 1,
      maxX: maxX.toDouble() < 2 ? 2 : maxX.toDouble(),
      lineBarsData: lines,
      gridData: FlGridData(
        drawVerticalLine: false,
        horizontalInterval: 20,
        getDrawingHorizontalLine: (_) => const FlLine(color: Brand.line, strokeWidth: 1),
      ),
      borderData: FlBorderData(show: false),
      extraLinesData: threshold == null
          ? null
          : ExtraLinesData(horizontalLines: [
              HorizontalLine(y: threshold, color: Brand.apricot, strokeWidth: 1.5, dashArray: [6, 4]),
            ]),
      titlesData: FlTitlesData(
        topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
        rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
        leftTitles: AxisTitles(
          sideTitles: SideTitles(
            showTitles: true,
            reservedSize: 36,
            interval: 20,
            getTitlesWidget: (v, _) => Text('${v.round()}%', style: const TextStyle(fontSize: 10, color: Brand.muted)),
          ),
        ),
        bottomTitles: AxisTitles(
          sideTitles: SideTitles(
            showTitles: true,
            interval: 1,
            getTitlesWidget: (v, _) => Text('${v.round()}', style: const TextStyle(fontSize: 10, color: Brand.muted)),
          ),
        ),
      ),
    );

// ---------------------------------------------------------------------------

class TargetReportScreen extends StatefulWidget {
  final String targetId;
  final bool specialist;
  const TargetReportScreen({super.key, required this.targetId, this.specialist = false});
  @override
  State<TargetReportScreen> createState() => _TargetReportScreenState();
}

class _TargetReportScreenState extends State<TargetReportScreen> {
  Target? _t;
  List<SessionSummary> _s = [];
  MasteryResult? _m;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final repo = context.read<AppState>().repo;
    final t = await repo.target(widget.targetId);
    if (t == null) return;
    final sum = SessionSummary.build(await repo.sessions(t.childId, targetId: t.id), await repo.trials(targetId: t.id),
        selectionBased: t.skillId == 'mand');
    if (mounted) {
      setState(() {
        _t = t;
        _s = sum;
        _m = MasteryEvaluator.evaluate(sum, t.mastery, fieldSizes: t.fieldSizes);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = _t, m = _m;
    if (t == null || m == null) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final c = skillColor(t.skillId);
    return Scaffold(
      appBar: AppBar(title: const Text('تقرير الهدف')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Text(t.titleAr, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        Text('معيار الإتقان: ${t.mastery.summaryAr}', style: const TextStyle(color: Brand.muted)),
        const SizedBox(height: 12),
        InfoBanner(
          m.state == MasteryState.mastered
              ? 'تحقق معيار الإتقان. يُنصح بمراجعة الأخصائي لتعميم المهارة والانتقال إلى هدف جديد.'
              : m.state == MasteryState.notStarted
                  ? 'لم تُنفذ جلسات لهذا الهدف بعد.'
                  : 'قيد التدريب: ${m.streak} من ${m.requiredSessions} جلسات متتالية حققت ${t.mastery.percent.round()}%.',
          color: m.state == MasteryState.mastered ? Brand.sage : Brand.sky,
          icon: m.state == MasteryState.mastered ? Icons.workspace_premium_outlined : Icons.timeline,
        ),
        if (_s.isNotEmpty) ...[
          const SectionTitle('نسبة الاستجابات المستقلة لكل جلسة'),
          Card(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(8, 20, 16, 8),
              child: SizedBox(
                height: 200,
                child: Directionality(
                  textDirection: TextDirection.ltr,
                  child: LineChart(_chartData([
                    LineChartBarData(
                      spots: [for (var i = 0; i < _s.length; i++) FlSpot(i + 1, _s[i].stats.independentPct)],
                      color: c, barWidth: 3, dotData: const FlDotData(show: true)),
                    LineChartBarData(
                      spots: [for (var i = 0; i < _s.length; i++) FlSpot(i + 1, _s[i].stats.correctPct)],
                      color: Brand.line, barWidth: 2, dashArray: [4, 4], dotData: const FlDotData(show: false)),
                  ], _s.length, threshold: t.mastery.percent)),
                ),
              ),
            ),
          ),
          const Padding(
            padding: EdgeInsets.only(top: 6),
            child: Text('الخط الملون: مستقلة · المتقطع الرمادي: كل الصحيحة · البرتقالي: معيار الإتقان',
                style: TextStyle(fontSize: 12, color: Brand.muted)),
          ),
        ],
        const SectionTitle('الجلسات'),
        if (_s.isEmpty) const Text('لا توجد جلسات.', style: TextStyle(color: Brand.muted)),
        for (final s in _s.reversed) ...[
          Card(
            child: ListTile(
              title: Text(formatDate(s.session.startedAt)),
              subtitle: Text(
                  '${s.session.trainerName.isEmpty ? 'بدون اسم مدرب' : s.session.trainerName} · ${formatDuration(s.session.duration)} · ${s.stats.trials} تجربة'
                  '${s.fieldSize > 1 ? ' · ${s.fieldSize} خيارات' : ''}'),
              trailing: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [
                Text(pct(s.stats.independentPct), style: TextStyle(fontWeight: FontWeight.w700, color: c)),
                Text('صحيحة ${pct(s.stats.correctPct)}', style: const TextStyle(fontSize: 11, color: Brand.muted)),
              ]),
              onTap: () async {
                await Navigator.push(context, MaterialPageRoute(
                    builder: (_) => SessionDetailScreen(session: s.session, target: t, canRescore: widget.specialist)));
                _load();
              },
            ),
          ),
          const SizedBox(height: 8),
        ],
      ]),
    );
  }
}

// ---------------------------------------------------------------------------

String promptNameAr(String code) => switch (code) {
      'full' => 'تلقين كامل',
      'partial' => 'تلقين جزئي',
      'verbal' => 'تلقين لفظي',
      'visual' => 'تلقين بصري',
      'independent' => 'مستقلة',
      _ => code,
    };

String outcomeAr(TrialOutcome o) => switch (o) {
      TrialOutcome.correct => 'صحيحة',
      TrialOutcome.incorrect => 'خاطئة',
      TrialOutcome.noResponse => 'لا استجابة',
    };

class SessionDetailScreen extends StatefulWidget {
  final SessionRecord session;
  final Target target;
  final bool canRescore;
  const SessionDetailScreen({super.key, required this.session, required this.target, this.canRescore = false});
  @override
  State<SessionDetailScreen> createState() => _SessionDetailScreenState();
}

class _SessionDetailScreenState extends State<SessionDetailScreen> {
  List<TrialRecord>? _trials;
  Map<String, String> _labels = {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final repo = context.read<AppState>().repo;
    final t = await repo.trials(sessionId: widget.session.id);
    final items = await repo.items(widget.session.childId);
    if (mounted) {
      setState(() {
        _trials = t;
        _labels = {for (final i in items) i.id: i.labelAr};
      });
    }
  }

  Future<void> _rescore(TrialRecord t) async {
    var outcome = t.outcome;
    var prompt = t.promptCode;
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, set) => AlertDialog(
          title: Text('مراجعة التجربة ${t.trialNumber}'),
          content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            if (t.recordingPath != null)
              Row(children: [
                OutlinedButton.icon(onPressed: () => Sound.instance.playPath(t.recordingPath!), icon: const Icon(Icons.play_arrow), label: const Text('استجابة الطفل')),
              ]),
            const SizedBox(height: 8),
            Wrap(spacing: 8, children: [
              for (final o in TrialOutcome.values)
                ChoiceChip(label: Text(outcomeAr(o)), selected: outcome == o, onSelected: (_) => set(() => outcome = o)),
            ]),
            const SizedBox(height: 8),
            DropdownButton<String>(
              value: prompt,
              isExpanded: true,
              items: [for (final p in widget.target.promptLadder) DropdownMenuItem(value: p, child: Text(promptNameAr(p)))],
              onChanged: (v) => set(() => prompt = v ?? prompt),
            ),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('إلغاء')),
            FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('حفظ التقييم')),
          ],
        ),
      ),
    );
    if (ok != true || !mounted) return;
    final st = context.read<AppState>();
    final role = st.unlockedRole ?? UserRole.parent;
    final reviewer = await st.repo.userByRole(role) ?? await st.repo.userByRole(UserRole.parent);
    await st.repo.rescoreTrial(t.id,
        outcome: outcome,
        promptCode: prompt,
        note: 'مراجعة: ${reviewer?.name ?? (role == UserRole.specialist ? 'الأخصائي' : 'ولي الأمر')}');
    _load();
  }

  @override
  Widget build(BuildContext context) {
    final trials = _trials;
    final s = widget.session;
    final stats = trials == null ? null : PerformanceStats.fromTrials(trials);
    return Scaffold(
      appBar: AppBar(title: const Text('بيانات الجلسة')),
      body: trials == null
          ? const Center(child: CircularProgressIndicator())
          : ListView(padding: const EdgeInsets.all(16), children: [
              Text(widget.target.titleAr, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 17)),
              const SizedBox(height: 4),
              Text('${formatDate(s.startedAt)} · المدة ${formatDuration(s.duration)} · المدرب: ${s.trainerName.isEmpty ? '—' : s.trainerName}'
                  '${s.endReason == null ? '' : ' · ${_reasonAr(s.endReason!)}'}',
                  style: const TextStyle(color: Brand.muted)),
              const SizedBox(height: 12),
              Wrap(spacing: 8, runSpacing: 8, children: [
                Chip(label: Text('صحيحة ${pct(stats!.correctPct)}')),
                Chip(label: Text('مستقلة ${pct(stats.independentPct)}')),
                Chip(label: Text('بمساعدة ${pct(stats.promptedPct)}')),
                Chip(label: Text('تجارب تصحيحية ${stats.correctionTrials}')),
                if (stats.meanLatencyMs != null) Chip(label: Text('متوسط زمن الاستجابة ${(stats.meanLatencyMs! / 1000).toStringAsFixed(1)} ث')),
              ]),
              if (widget.canRescore && widget.target.skillId == 'tact')
                const Padding(
                  padding: EdgeInsets.only(top: 8),
                  child: InfoBanner('اضغط على أي تجربة للاستماع إلى تسجيل الطفل ومراجعة تقييمها.'),
                ),
              const SizedBox(height: 12),
              Card(
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: DataTable(
                    showCheckboxColumn: false,
                    columnSpacing: 18,
                    columns: const [
                      DataColumn(label: Text('#')),
                      DataColumn(label: Text('المثير')),
                      DataColumn(label: Text('الاستجابة')),
                      DataColumn(label: Text('النتيجة')),
                      DataColumn(label: Text('المساعدة')),
                      DataColumn(label: Text('الزمن')),
                      DataColumn(label: Text('')),
                    ],
                    rows: [
                      for (final t in trials)
                        DataRow(
                          color: t.isCorrection ? const WidgetStatePropertyAll(Brand.sand) : null,
                          onSelectChanged: widget.canRescore && !t.isCorrection ? (_) => _rescore(t) : null,
                          cells: [
                            DataCell(Text('${t.trialNumber}${t.isCorrection ? ' (تصحيح)' : ''}')),
                            DataCell(Text(t.stimulusLabel)),
                            DataCell(Text(t.recordingPath != null
                                ? 'تسجيل صوتي'
                                : (t.selectedItemId == null ? '—' : (_labels[t.selectedItemId] ?? '—')))),
                            DataCell(Text(outcomeAr(t.outcome),
                                style: TextStyle(color: t.isCorrect ? Brand.tealDark : Brand.muted, fontWeight: FontWeight.w600))),
                            DataCell(Text(promptNameAr(t.promptCode))),
                            DataCell(Text(t.latencyMs == null ? '—' : '${(t.latencyMs! / 1000).toStringAsFixed(1)} ث')),
                            DataCell(t.recordingPath == null
                                ? const SizedBox()
                                : IconButton(icon: const Icon(Icons.play_circle_outline), onPressed: () => Sound.instance.playPath(t.recordingPath!))),
                          ],
                        ),
                    ],
                  ),
                ),
              ),
              if (widget.canRescore) ...[
                const SizedBox(height: 20),
                OutlinedButton.icon(
                  icon: const Icon(Icons.delete_outline),
                  label: const Text('حذف هذه الجلسة (بيانات غير صالحة)'),
                  onPressed: () async {
                    final ok = await confirmDialog(context, title: 'حذف الجلسة', body: 'ستُحذف تجارب هذه الجلسة من الحسابات نهائيًا.', confirm: 'حذف', danger: true);
                    if (!ok || !context.mounted) return;
                    await context.read<AppState>().repo.deleteSession(s.id);
                    if (context.mounted) Navigator.pop(context);
                  },
                ),
              ],
            ]),
    );
  }

  String _reasonAr(String r) => switch (r) {
        'completed' => 'اكتملت',
        'time_limit' => 'انتهى الوقت',
        'stopped_by_adult' => 'أوقفها البالغ',
        'break' => 'انتهت باستراحة',
        _ => r,
      };
}
