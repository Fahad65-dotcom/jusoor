/// أدوات تسجيل وتشغيل الأصوات البشرية داخل مساحات البالغين.
library;

import 'package:flutter/material.dart';

import '../../core/brand.dart';
import '../../services/media_service.dart';

/// صف لتسجيل مقطع صوتي وتشغيله وحذفه.
class AudioClipRow extends StatefulWidget {
  final String label;
  final String? hint;
  final String? path;
  final bool isAsset;
  final Future<void> Function(String relativePath) onRecorded;
  final Future<void> Function()? onDelete;
  const AudioClipRow({
    super.key,
    required this.label,
    this.hint,
    required this.path,
    this.isAsset = false,
    required this.onRecorded,
    this.onDelete,
  });

  @override
  State<AudioClipRow> createState() => _AudioClipRowState();
}

class _AudioClipRowState extends State<AudioClipRow> {
  final _rec = Recorder();
  bool _recording = false;

  @override
  void dispose() {
    _rec.dispose();
    super.dispose();
  }

  Future<void> _toggle() async {
    if (_recording) {
      final p = await _rec.stop();
      setState(() => _recording = false);
      if (p != null) await widget.onRecorded(p);
    } else {
      final ok = await _rec.start();
      if (!ok) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
              content: Text('يلزم السماح باستخدام الميكروفون من إعدادات الجهاز')));
        }
        return;
      }
      setState(() => _recording = true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final has = widget.path != null;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: _recording ? Brand.apricotSoft : Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Brand.line),
      ),
      child: Row(children: [
        Icon(has ? Icons.graphic_eq : Icons.mic_none, color: has ? Brand.teal : Brand.muted),
        const SizedBox(width: 10),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(widget.label, style: const TextStyle(fontWeight: FontWeight.w600)),
            Text(
              _recording ? 'جارٍ التسجيل… اضغط للإيقاف' : (has ? 'تسجيل محفوظ' : (widget.hint ?? 'لا يوجد تسجيل')),
              style: const TextStyle(fontSize: 12, color: Brand.muted),
            ),
          ]),
        ),
        if (has && !_recording)
          IconButton(
            tooltip: 'تشغيل',
            icon: const Icon(Icons.play_circle_outline),
            onPressed: () => Sound.instance.playPath(widget.path!, asset: widget.isAsset),
          ),
        IconButton(
          tooltip: _recording ? 'إيقاف' : 'تسجيل',
          icon: Icon(_recording ? Icons.stop_circle : Icons.mic, color: _recording ? const Color(0xFFB4554B) : Brand.tealDark),
          onPressed: _toggle,
        ),
        if (has && !_recording && widget.onDelete != null)
          IconButton(tooltip: 'حذف', icon: const Icon(Icons.delete_outline), onPressed: widget.onDelete),
      ]),
    );
  }
}
