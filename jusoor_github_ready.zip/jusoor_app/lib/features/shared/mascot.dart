/// الشخصية المساعدة «سَنا» — بومة هادئة ترسم بالكود (دون ملفات خارجية)
/// حتى تبقى خفيفة وقابلة للتحكم في الحركة.
library;

import 'package:flutter/material.dart';

import '../../core/brand.dart';

enum MascotMood { calm, happy, thinking }

class Mascot extends StatelessWidget {
  final double size;
  final MascotMood mood;
  const Mascot({super.key, this.size = 96, this.mood = MascotMood.calm});

  @override
  Widget build(BuildContext context) => Semantics(
        label: 'الشخصية المساعدة ${Brand.mascotName}',
        child: CustomPaint(size: Size.square(size), painter: _OwlPainter(mood)),
      );
}

class _OwlPainter extends CustomPainter {
  final MascotMood mood;
  _OwlPainter(this.mood);

  @override
  void paint(Canvas c, Size s) {
    final w = s.width, h = s.height;
    final body = Paint()..color = Brand.teal;
    final belly = Paint()..color = Brand.tealSoft;
    final white = Paint()..color = Colors.white;
    final ink = Paint()..color = Brand.ink;
    final beak = Paint()..color = Brand.apricot;

    // الأذنان
    final ear = Path()
      ..moveTo(w * .22, h * .30)
      ..lineTo(w * .26, h * .08)
      ..lineTo(w * .42, h * .22)
      ..close()
      ..moveTo(w * .78, h * .30)
      ..lineTo(w * .74, h * .08)
      ..lineTo(w * .58, h * .22)
      ..close();
    c.drawPath(ear, body);
    // الجسم
    c.drawRRect(
        RRect.fromRectAndRadius(Rect.fromLTWH(w * .16, h * .16, w * .68, h * .80),
            Radius.circular(w * .34)),
        body);
    c.drawOval(Rect.fromLTWH(w * .30, h * .52, w * .40, h * .38), belly);
    // الجناحان
    c.drawOval(Rect.fromLTWH(w * .08, h * .48, w * .18, h * .32), Paint()..color = Brand.tealDark);
    c.drawOval(Rect.fromLTWH(w * .74, h * .48, w * .18, h * .32), Paint()..color = Brand.tealDark);
    // العينان
    for (final x in [.36, .64]) {
      c.drawCircle(Offset(w * x, h * .38), w * .13, white);
      if (mood == MascotMood.happy) {
        final p = Paint()
          ..color = Brand.ink
          ..style = PaintingStyle.stroke
          ..strokeWidth = w * .035
          ..strokeCap = StrokeCap.round;
        c.drawArc(Rect.fromCircle(center: Offset(w * x, h * .40), radius: w * .06), 3.4, 2.6, false, p);
      } else {
        final dy = mood == MascotMood.thinking ? -.02 : 0.0;
        c.drawCircle(Offset(w * x, h * (.39 + dy)), w * .055, ink);
        c.drawCircle(Offset(w * (x + .02), h * (.37 + dy)), w * .018, white);
      }
    }
    // المنقار
    final b = Path()
      ..moveTo(w * .45, h * .50)
      ..lineTo(w * .55, h * .50)
      ..lineTo(w * .50, h * .58)
      ..close();
    c.drawPath(b, beak);
    // القدمان
    c.drawOval(Rect.fromLTWH(w * .36, h * .92, w * .1, h * .06), beak);
    c.drawOval(Rect.fromLTWH(w * .54, h * .92, w * .1, h * .06), beak);
  }

  @override
  bool shouldRepaint(_OwlPainter old) => old.mood != mood;
}
