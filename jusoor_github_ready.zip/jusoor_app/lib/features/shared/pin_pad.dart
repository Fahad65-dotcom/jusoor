/// لوحة إدخال رمز الدخول لمساحات البالغين.
library;

import 'package:flutter/material.dart';

import '../../core/brand.dart';

class PinPad extends StatefulWidget {
  final String title;
  final String? subtitle;
  final int length;
  final Future<bool> Function(String pin) onSubmit;
  final VoidCallback? onCancel;
  const PinPad({super.key, required this.title, this.subtitle, this.length = 4, required this.onSubmit, this.onCancel});

  @override
  State<PinPad> createState() => _PinPadState();
}

class _PinPadState extends State<PinPad> {
  String _pin = '';
  String? _error;
  bool _busy = false;
  int _fails = 0;
  DateTime? _lockedUntil;

  Future<void> _tap(String d) async {
    if (_busy) return;
    if (_lockedUntil != null && DateTime.now().isBefore(_lockedUntil!)) {
      setState(() => _error = 'محاولات كثيرة. انتظر ٣٠ ثانية');
      return;
    }
    setState(() {
      _error = null;
      if (d == '<') {
        if (_pin.isNotEmpty) _pin = _pin.substring(0, _pin.length - 1);
      } else if (_pin.length < widget.length) {
        _pin += d;
      }
    });
    if (_pin.length == widget.length) {
      setState(() => _busy = true);
      final ok = await widget.onSubmit(_pin);
      if (!mounted) return;
      setState(() {
        _busy = false;
        if (!ok) {
          _fails++;
          _error = 'الرمز غير صحيح';
          if (_fails >= 5) {
            _lockedUntil = DateTime.now().add(const Duration(seconds: 30));
            _fails = 0;
          }
          _pin = '';
        }
      });
    }
  }

  Widget _key(String d) => Padding(
        padding: const EdgeInsets.all(6),
        child: SizedBox(
          width: 72,
          height: 64,
          child: Material(
            color: Colors.white,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18), side: const BorderSide(color: Brand.line)),
            child: InkWell(
              borderRadius: BorderRadius.circular(18),
              onTap: () => _tap(d),
              child: Center(
                child: d == '<'
                    ? const Icon(Icons.backspace_outlined, color: Brand.muted)
                    : Text(d, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w600)),
              ),
            ),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    return Column(mainAxisSize: MainAxisSize.min, children: [
      Text(widget.title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
      if (widget.subtitle != null) ...[
        const SizedBox(height: 6),
        Text(widget.subtitle!, textAlign: TextAlign.center, style: const TextStyle(color: Brand.muted)),
      ],
      const SizedBox(height: 18),
      Directionality(
        textDirection: TextDirection.ltr,
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: List.generate(
            widget.length,
            (i) => Container(
              margin: const EdgeInsets.symmetric(horizontal: 7),
              width: 16,
              height: 16,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: i < _pin.length ? Brand.teal : Colors.transparent,
                border: Border.all(color: Brand.teal, width: 2),
              ),
            ),
          ),
        ),
      ),
      SizedBox(
        height: 30,
        child: Center(
          child: _busy
              ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
              : Text(_error ?? '', style: const TextStyle(color: Color(0xFFB4554B))),
        ),
      ),
      Directionality(
        textDirection: TextDirection.ltr,
        child: Column(children: [
          for (final row in const [['1', '2', '3'], ['4', '5', '6'], ['7', '8', '9']])
            Row(mainAxisSize: MainAxisSize.min, children: row.map(_key).toList()),
          Row(mainAxisSize: MainAxisSize.min, children: [
            const SizedBox(width: 84),
            _key('0'),
            _key('<'),
          ]),
        ]),
      ),
      if (widget.onCancel != null)
        TextButton(onPressed: widget.onCancel, child: const Text('إلغاء')),
    ]);
  }
}

/// يعرض لوحة الرمز في نافذة ويعيد true عند النجاح.
Future<bool> askPin(BuildContext context,
    {required String title, String? subtitle, int length = 4, required Future<bool> Function(String) verify}) async {
  final r = await showDialog<bool>(
    context: context,
    barrierDismissible: false,
    builder: (c) => Dialog(
      backgroundColor: Brand.sand,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 24, 16, 8),
        child: SingleChildScrollView(
          child: PinPad(
            title: title,
            subtitle: subtitle,
            length: length,
            onSubmit: (pin) async {
              final ok = await verify(pin);
              if (ok && c.mounted) Navigator.pop(c, true);
              return ok;
            },
            onCancel: () => Navigator.pop(c, false),
          ),
        ),
      ),
    ),
  );
  return r ?? false;
}
