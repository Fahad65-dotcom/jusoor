/// عناصر واجهة مشتركة وموحدة لكل الشاشات.
library;

import 'dart:io';

import 'package:flutter/material.dart';

import '../../core/brand.dart';
import '../../data/models.dart';
import '../../services/media_service.dart';

/// صورة بند (مضمّنة أو من ملفات ولي الأمر).
class ItemImageView extends StatelessWidget {
  final ItemImage? image;
  final double? size;
  final BoxFit fit;
  const ItemImageView(this.image, {super.key, this.size, this.fit = BoxFit.contain});

  @override
  Widget build(BuildContext context) {
    final img = image;
    Widget child;
    if (img == null) {
      child = const Icon(Icons.image_outlined, color: Brand.muted, size: 40);
    } else if (img.isAsset) {
      child = Image.asset(img.path, fit: fit, width: size, height: size);
    } else {
      child = FutureBuilder<String>(
        future: MediaService.instance.absolute(img.path),
        builder: (_, s) => s.hasData
            ? Image.file(File(s.data!), fit: fit, width: size, height: size,
                errorBuilder: (_, _, _) => const Icon(Icons.broken_image_outlined))
            : SizedBox(width: size, height: size),
      );
    }
    return SizedBox(width: size, height: size, child: Center(child: child));
  }
}

class ChildAvatar extends StatelessWidget {
  final Child child;
  final double radius;
  const ChildAvatar(this.child, {super.key, this.radius = 28});

  @override
  Widget build(BuildContext context) {
    if (child.photoPath == null) {
      return CircleAvatar(
        radius: radius,
        backgroundColor: Brand.tealSoft,
        child: Text(child.name.characters.first,
            style: TextStyle(fontSize: radius * .8, fontWeight: FontWeight.w700, color: Brand.tealDark)),
      );
    }
    return FutureBuilder<String>(
      future: MediaService.instance.absolute(child.photoPath!),
      builder: (_, s) => CircleAvatar(
        radius: radius,
        backgroundColor: Brand.tealSoft,
        backgroundImage: s.hasData ? FileImage(File(s.data!)) : null,
      ),
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String text;
  final Widget? trailing;
  const SectionTitle(this.text, {super.key, this.trailing});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 20, 4, 10),
        child: Row(children: [
          Expanded(
              child: Text(text,
                  style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700, color: Brand.ink))),
          ?trailing,
        ]),
      );
}

class StatTile extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  final IconData icon;
  const StatTile({super.key, required this.label, required this.value, required this.color, required this.icon});

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: Brand.line),
        ),
        child: Row(children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(color: color.withValues(alpha: .15), borderRadius: BorderRadius.circular(12)),
            child: Icon(icon, color: color, size: 22),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
              Text(label, style: const TextStyle(fontSize: 13, color: Brand.muted), maxLines: 2),
            ]),
          ),
        ]),
      );
}

class EmptyState extends StatelessWidget {
  final String title;
  final String? body;
  final Widget? action;
  final IconData icon;
  const EmptyState({super.key, required this.title, this.body, this.action, this.icon = Icons.inbox_outlined});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.all(32),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 48, color: Brand.muted),
          const SizedBox(height: 12),
          Text(title, textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
          if (body != null) ...[
            const SizedBox(height: 6),
            Text(body!, textAlign: TextAlign.center, style: const TextStyle(color: Brand.muted)),
          ],
          if (action != null) ...[const SizedBox(height: 16), action!],
        ]),
      );
}

class InfoBanner extends StatelessWidget {
  final String text;
  final Color color;
  final IconData icon;
  const InfoBanner(this.text, {super.key, this.color = Brand.sky, this.icon = Icons.info_outline});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
            color: color.withValues(alpha: .12), borderRadius: BorderRadius.circular(16)),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(width: 10),
          Expanded(child: Text(text, style: const TextStyle(fontSize: 14, height: 1.5))),
        ]),
      );
}

/// شريط تقدم مع نسبة.
class PercentBar extends StatelessWidget {
  final double percent;
  final Color color;
  const PercentBar(this.percent, {super.key, this.color = Brand.teal});
  @override
  Widget build(BuildContext context) => ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: LinearProgressIndicator(
          value: (percent / 100).clamp(0, 1),
          minHeight: 8,
          backgroundColor: Brand.line,
          valueColor: AlwaysStoppedAnimation(color),
        ),
      );
}

String pct(double v) => '${v.round()}٪';

String formatDate(int ms) {
  final d = DateTime.fromMillisecondsSinceEpoch(ms);
  String two(int n) => n.toString().padLeft(2, '0');
  return '${d.year}/${two(d.month)}/${two(d.day)} ${two(d.hour)}:${two(d.minute)}';
}

String formatDuration(Duration d) {
  final m = d.inMinutes, s = d.inSeconds % 60;
  return m == 0 ? '$s ث' : '$m د ${s.toString().padLeft(2, '0')} ث';
}

Future<bool> confirmDialog(BuildContext context,
    {required String title, required String body, String confirm = 'تأكيد', bool danger = false}) async {
  final r = await showDialog<bool>(
    context: context,
    builder: (c) => AlertDialog(
      title: Text(title),
      content: Text(body),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('إلغاء')),
        FilledButton(
          style: danger ? FilledButton.styleFrom(backgroundColor: const Color(0xFFB4554B)) : null,
          onPressed: () => Navigator.pop(c, true),
          child: Text(confirm),
        ),
      ],
    ),
  );
  return r ?? false;
}

void toast(BuildContext context, String msg) =>
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));

/// حشوة تجعل المحتوى بعرض مريح للقراءة على الأجهزة اللوحية العريضة.
EdgeInsets readablePadding(BuildContext context, EdgeInsets base, {double maxWidth = 860}) {
  final w = MediaQuery.sizeOf(context).width;
  final extra = w > maxWidth ? (w - maxWidth) / 2 : 0.0;
  return base.copyWith(left: base.left + extra, right: base.right + extra);
}
