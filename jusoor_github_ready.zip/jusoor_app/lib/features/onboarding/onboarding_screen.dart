/// الإعداد الأول: التعريف والموافقة على الخصوصية، ثم رمز ولي الأمر، ثم رمز
/// الأخصائي (اختياري).
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/app_state.dart';
import '../../core/brand.dart';
import '../../data/models.dart';
import '../settings/privacy_screen.dart';
import '../shared/mascot.dart';
import '../shared/widgets.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});
  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  int _step = 0;
  bool _consent = false;
  final _parentName = TextEditingController();
  final _parentPin = TextEditingController();
  final _parentPin2 = TextEditingController();
  bool _addSpecialist = false;
  final _specName = TextEditingController();
  final _specPin = TextEditingController();
  String? _error;
  bool _busy = false;

  bool _validPin(String p) => RegExp(r'^\d{4}$').hasMatch(p);

  Future<void> _finish() async {
    setState(() => _error = null);
    if (_addSpecialist) {
      if (_specName.text.trim().isEmpty || !_validPin(_specPin.text)) {
        setState(() => _error = 'أدخل اسم الأخصائي ورمزًا من 4 أرقام');
        return;
      }
      if (_specPin.text == _parentPin.text) {
        setState(() => _error = 'اختر رمزًا مختلفًا عن رمز ولي الأمر');
        return;
      }
    }
    setState(() => _busy = true);
    final s = context.read<AppState>();
    if (_addSpecialist) {
      await s.createUser(UserRole.specialist, _specName.text.trim(), _specPin.text);
    }
    await s.createUser(UserRole.parent, _parentName.text.trim(), _parentPin.text);
  }

  void _next() {
    setState(() => _error = null);
    if (_step == 1) {
      if (_parentName.text.trim().isEmpty) {
        setState(() => _error = 'أدخل اسم ولي الأمر');
        return;
      }
      if (!_validPin(_parentPin.text)) {
        setState(() => _error = 'الرمز يجب أن يكون 4 أرقام');
        return;
      }
      if (_parentPin.text != _parentPin2.text) {
        setState(() => _error = 'الرمزان غير متطابقين');
        return;
      }
    }
    setState(() => _step++);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 520),
            child: ListView(padding: const EdgeInsets.all(24), children: [
              Row(mainAxisAlignment: MainAxisAlignment.center, children: List.generate(3, (i) =>
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    margin: const EdgeInsets.symmetric(horizontal: 4),
                    width: i == _step ? 28 : 10, height: 10,
                    decoration: BoxDecoration(color: i <= _step ? Brand.teal : Brand.line, borderRadius: BorderRadius.circular(5)),
                  ))),
              const SizedBox(height: 24),
              ...switch (_step) { 0 => _welcome(), 1 => _parent(), _ => _specialist() },
              if (_error != null) ...[
                const SizedBox(height: 12),
                Text(_error!, style: const TextStyle(color: Color(0xFFB4554B))),
              ],
              const SizedBox(height: 24),
              Row(children: [
                if (_step > 0)
                  Expanded(child: OutlinedButton(onPressed: () => setState(() => _step--), child: const Text('السابق'))),
                if (_step > 0) const SizedBox(width: 12),
                Expanded(
                  flex: 2,
                  child: FilledButton(
                    onPressed: _busy || (_step == 0 && !_consent) ? null : (_step == 2 ? _finish : _next),
                    child: Text(_step == 2 ? 'ابدأ استخدام ${Brand.nameAr}' : 'التالي'),
                  ),
                ),
              ]),
            ]),
          ),
        ),
      ),
    );
  }

  List<Widget> _welcome() => [
        const Center(child: Mascot(size: 130, mood: MascotMood.happy)),
        const SizedBox(height: 16),
        const Text('مرحبًا بك في ${Brand.nameAr}', textAlign: TextAlign.center,
            style: TextStyle(fontSize: 26, fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        const Text(Brand.taglineAr, textAlign: TextAlign.center, style: TextStyle(color: Brand.muted, fontSize: 16)),
        const SizedBox(height: 20),
        const InfoBanner(Brand.disclaimerAr, color: Brand.apricot, icon: Icons.health_and_safety_outlined),
        const SizedBox(height: 12),
        const InfoBanner(
            'تُحفظ بيانات طفلك على هذا الجهاز فقط ومشفرة. لا إعلانات، ولا روابط خارجية في وضع الطفل، ولا تُستخدم البيانات لأي غرض تجاري أو لتدريب نماذج الذكاء الاصطناعي.',
            color: Brand.teal,
            icon: Icons.lock_outline),
        const SizedBox(height: 12),
        CheckboxListTile(
          value: _consent,
          onChanged: (v) => setState(() => _consent = v ?? false),
          controlAffinity: ListTileControlAffinity.leading,
          contentPadding: EdgeInsets.zero,
          title: const Text('قرأت سياسة الخصوصية وأوافق عليها بصفتي ولي الأمر'),
        ),
        Align(
          alignment: AlignmentDirectional.centerStart,
          child: TextButton(
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PrivacyPolicyScreen())),
            child: const Text('عرض سياسة الخصوصية'),
          ),
        ),
      ];

  List<Widget> _parent() => [
        const Text('حساب ولي الأمر', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        const Text('يحمي هذا الرمز مساحة ولي الأمر ويمنع الطفل من الخروج من الجلسة أو تغيير الإعدادات.',
            style: TextStyle(color: Brand.muted)),
        const SizedBox(height: 20),
        TextField(controller: _parentName, decoration: const InputDecoration(labelText: 'الاسم')),
        const SizedBox(height: 12),
        TextField(
            controller: _parentPin, keyboardType: TextInputType.number, obscureText: true, maxLength: 4,
            decoration: const InputDecoration(labelText: 'رمز الدخول (4 أرقام)')),
        TextField(
            controller: _parentPin2, keyboardType: TextInputType.number, obscureText: true, maxLength: 4,
            decoration: const InputDecoration(labelText: 'تأكيد الرمز')),
      ];

  List<Widget> _specialist() => [
        const Text('مساحة الأخصائي', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        const Text(
            'يحدد الأخصائي الأهداف ومعايير الإتقان واستراتيجية التلقين. يمكنك إضافته الآن أو لاحقًا من الإعدادات.',
            style: TextStyle(color: Brand.muted)),
        const SizedBox(height: 12),
        SwitchListTile(
          value: _addSpecialist,
          onChanged: (v) => setState(() => _addSpecialist = v),
          contentPadding: EdgeInsets.zero,
          title: const Text('إضافة رمز للأخصائي الآن'),
        ),
        if (_addSpecialist) ...[
          TextField(controller: _specName, decoration: const InputDecoration(labelText: 'اسم الأخصائي')),
          const SizedBox(height: 12),
          TextField(
              controller: _specPin, keyboardType: TextInputType.number, obscureText: true, maxLength: 4,
              decoration: const InputDecoration(labelText: 'رمز الأخصائي (4 أرقام)')),
        ] else
          const InfoBanner('بدون رمز أخصائي، يمكن لولي الأمر فتح مساحة الأخصائي برمزه الخاص لضبط الخطة على هذا الجهاز.'),
      ];
}
