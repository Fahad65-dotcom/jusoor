/// مساحة الأخصائي: الخطة التدريبية، المتابعة ومراجعة البيانات، إدارة المحتوى.
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/app_state.dart';
import '../../core/brand.dart';
import '../../data/models.dart';
import '../../engine/mastery.dart';
import '../parent/child_hub.dart' show computeMastery, skillColor, skillIcon;
import '../shared/dashboard.dart';
import '../shared/widgets.dart';
import 'content_admin.dart';
import 'target_editor.dart';

class SpecialistHome extends StatefulWidget {
  const SpecialistHome({super.key});
  @override
  State<SpecialistHome> createState() => _SpecialistHomeState();
}

class _SpecialistHomeState extends State<SpecialistHome> {
  List<Child>? _kids;
  int _tab = 0;
  int _refresh = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final k = await context.read<AppState>().repo.children();
    if (mounted) setState(() => _kids = k);
  }

  @override
  Widget build(BuildContext context) {
    final kids = _kids;
    if (kids == null) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (kids.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: const Text('مساحة الأخصائي')),
        body: const EmptyState(title: 'لا يوجد ملف طفل', body: 'يُنشئ ولي الأمر ملف الطفل من مساحته أولًا.'),
      );
    }
    final c = kids.first;
    final pages = [
      PlanTab(key: ValueKey('p$_refresh'), child: c, onChanged: () => setState(() => _refresh++)),
      ProgressDashboard(key: ValueKey('d$_refresh'), childId: c.id, specialist: true),
      ContentAdminScreen(childId: c.id),
    ];
    return Scaffold(
      appBar: AppBar(title: Text('مساحة الأخصائي · ${c.name}')),
      body: pages[_tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.assignment_outlined), selectedIcon: Icon(Icons.assignment), label: 'الخطة'),
          NavigationDestination(icon: Icon(Icons.insights_outlined), selectedIcon: Icon(Icons.insights), label: 'البيانات'),
          NavigationDestination(icon: Icon(Icons.dashboard_customize_outlined), selectedIcon: Icon(Icons.dashboard_customize), label: 'المحتوى'),
        ],
      ),
    );
  }
}

class PlanTab extends StatefulWidget {
  final Child child;
  final VoidCallback onChanged;
  const PlanTab({super.key, required this.child, required this.onChanged});
  @override
  State<PlanTab> createState() => _PlanTabState();
}

class _PlanTabState extends State<PlanTab> {
  List<(Target, Skill, MasteryResult)>? _rows;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final repo = context.read<AppState>().repo;
    final skills = {for (final s in await repo.skills()) s.id: s};
    final out = <(Target, Skill, MasteryResult)>[];
    for (final t in await repo.targets(widget.child.id)) {
      final s = skills[t.skillId];
      if (s != null) out.add((t, s, await computeMastery(repo, t)));
    }
    if (mounted) setState(() => _rows = out);
  }

  Future<void> _add() async {
    final repo = context.read<AppState>().repo;
    final templates = await repo.targetTemplates();
    final skills = {for (final s in await repo.skills()) s.id: s};
    if (!mounted) return;
    final t = await showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      isScrollControlled: true,
      builder: (c) => SafeArea(
        child: ListView(shrinkWrap: true, padding: const EdgeInsets.all(16), children: [
          const Text('إضافة هدف من المنهج', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          for (final t in templates)
            if (skills[t['skill']]?.isAvailable ?? false)
              ListTile(
                leading: Icon(skillIcon(t['skill'] as String), color: skillColor(t['skill'] as String)),
                title: Text(t['title_ar'] as String),
                subtitle: Text(skills[t['skill']]!.nameAr),
                onTap: () => Navigator.pop(c, t),
              ),
        ]),
      ),
    );
    if (t == null) return;
    final id = await repo.addTargetFromTemplate(widget.child.id, t);
    if (!mounted) return;
    await Navigator.push(context, MaterialPageRoute(builder: (_) => TargetEditorScreen(targetId: id)));
    _load();
    widget.onChanged();
  }

  @override
  Widget build(BuildContext context) {
    final rows = _rows;
    if (rows == null) return const Center(child: CircularProgressIndicator());
    return Scaffold(
      floatingActionButton: FloatingActionButton.extended(onPressed: _add, icon: const Icon(Icons.add), label: const Text('هدف جديد')),
      body: ListView(padding: readablePadding(context, const EdgeInsets.fromLTRB(16, 12, 16, 96)), children: [
        const InfoBanner('المستوى الحالي: مبتدئ. اضبط لكل هدف عدد التجارب، مهلة الاستجابة، سلم التلقين وقواعد التلاشي، ومعيار الإتقان.'),
        const SizedBox(height: 12),
        for (final (t, s, m) in rows) ...[
          Card(
            child: ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              leading: Icon(skillIcon(s.id), color: skillColor(s.id)),
              title: Text(t.titleAr, style: const TextStyle(fontWeight: FontWeight.w600)),
              subtitle: Text(
                  '${s.nameAr} · ${m.labelAr}${t.status == TargetStatus.paused ? ' · موقوف' : ''}${t.enabledForParent ? '' : ' · غير متاح لولي الأمر'}\n'
                  '${t.trialsPerSession} تجارب · مهلة ${t.waitSeconds} ث · ${t.mastery.summaryAr}',
                  style: const TextStyle(fontSize: 12)),
              isThreeLine: true,
              trailing: const Icon(Icons.chevron_left),
              onTap: () async {
                await Navigator.push(context, MaterialPageRoute(builder: (_) => TargetEditorScreen(targetId: t.id)));
                _load();
                widget.onChanged();
              },
            ),
          ),
          const SizedBox(height: 10),
        ],
        const SizedBox(height: 8),
        const Text(Brand.disclaimerAr, textAlign: TextAlign.center, style: TextStyle(color: Brand.muted, fontSize: 12)),
      ]),
    );
  }
}
