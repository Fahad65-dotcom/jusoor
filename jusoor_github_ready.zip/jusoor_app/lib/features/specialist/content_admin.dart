/// إدارة المحتوى (منفصلة عن الكود): أسماء المهارات وتفعيلها، أوصاف مستويات
/// التلقين، ومكتبة الصور والأصوات. المنهج الأساسي يُحمّل من
/// assets/content/curriculum.json ويمكن تعديله دون تغيير الكود.
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/app_state.dart';
import '../../core/brand.dart';
import '../../data/models.dart';
import '../parent/child_hub.dart' show skillColor, skillIcon;
import '../parent/library_screen.dart';
import '../shared/widgets.dart';

class ContentAdminScreen extends StatefulWidget {
  final String childId;
  const ContentAdminScreen({super.key, required this.childId});
  @override
  State<ContentAdminScreen> createState() => _ContentAdminScreenState();
}

class _ContentAdminScreenState extends State<ContentAdminScreen> {
  List<Skill>? _skills;
  List<PromptLevelDef>? _levels;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final repo = context.read<AppState>().repo;
    final s = await repo.skills();
    final l = await repo.promptLevels();
    if (mounted) {
      setState(() {
        _skills = s;
        _levels = l;
      });
    }
  }

  Future<void> _edit({required String title, required String name, String? desc, required Future<void> Function(String, String?) save}) async {
    final n = TextEditingController(text: name);
    final d = desc == null ? null : TextEditingController(text: desc);
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(title),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: n, decoration: const InputDecoration(labelText: 'الاسم')),
          if (d != null) ...[
            const SizedBox(height: 8),
            TextField(controller: d, maxLines: 3, decoration: const InputDecoration(labelText: 'الوصف')),
          ],
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('حفظ')),
        ],
      ),
    );
    if (ok == true && n.text.trim().isNotEmpty) {
      await save(n.text.trim(), d?.text.trim());
      _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    final skills = _skills, levels = _levels;
    if (skills == null || levels == null) return const Center(child: CircularProgressIndicator());
    final repo = context.read<AppState>().repo;
    return ListView(padding: readablePadding(context, const EdgeInsets.all(16)), children: [
      Card(
        child: ListTile(
          leading: const Icon(Icons.photo_library_outlined, color: Brand.teal),
          title: const Text('مكتبة الصور والأصوات'),
          subtitle: const Text('إضافة بنود بصور حقيقية وتسجيلات صوتية وربطها بالمهارات'),
          trailing: const Icon(Icons.chevron_left),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => LibraryScreen(childId: widget.childId))),
        ),
      ),
      const SectionTitle('المهارات (منهج السلوك اللفظي)'),
      Card(
        child: Column(children: [
          for (final s in skills)
            ListTile(
              leading: Icon(skillIcon(s.id), color: s.phase == 1 ? skillColor(s.id) : Brand.muted),
              title: Text(s.nameAr),
              subtitle: Text(s.phase == 1 ? s.nameEn : '${s.nameEn} · مرحلة لاحقة (${s.phase})'),
              onLongPress: () => _edit(title: 'تعديل اسم المهارة', name: s.nameAr, save: (n, _) => repo.updateSkill(s.id, nameAr: n)),
              trailing: s.phase == 1
                  ? Row(mainAxisSize: MainAxisSize.min, children: [
                      IconButton(
                        tooltip: 'تعديل الاسم',
                        icon: const Icon(Icons.edit_outlined),
                        onPressed: () => _edit(title: 'تعديل اسم المهارة', name: s.nameAr, save: (n, _) => repo.updateSkill(s.id, nameAr: n)),
                      ),
                      Switch(
                        value: s.enabled,
                        onChanged: (v) async {
                          await repo.updateSkill(s.id, enabled: v);
                          _load();
                        },
                      ),
                    ])
                  : const Text('غير متاحة في النسخة الأولى', style: TextStyle(fontSize: 11, color: Brand.muted)),
            ),
        ]),
      ),
      const SectionTitle('مستويات التلقين'),
      Card(
        child: Column(children: [
          for (final l in levels)
            ListTile(
              title: Text(l.nameAr),
              subtitle: Text(l.descriptionAr, style: const TextStyle(fontSize: 12)),
              trailing: IconButton(
                tooltip: 'تعديل',
                icon: const Icon(Icons.edit_outlined),
                onPressed: () => _edit(
                  title: 'تعديل مستوى التلقين',
                  name: l.nameAr,
                  desc: l.descriptionAr,
                  save: (n, d) => repo.updatePromptLevel(l.code, nameAr: n, description: d),
                ),
              ),
            ),
        ]),
      ),
      const SizedBox(height: 8),
      const InfoBanner('المحتوى الأساسي للمنهج محفوظ في ملف مستقل (assets/content/curriculum.json) ويمكن تحديثه دون تعديل الكود البرمجي.'),
    ]);
  }
}
