/// تحرير هدف تدريبي: عدد التجارب، مهلة الاستجابة، سلم التلقين واستراتيجية
/// التلاشي، قواعد الاستراحة، معيار الإتقان، والبنود التدريبية.
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/app_state.dart';
import '../../core/brand.dart';
import '../../data/models.dart';
import '../../engine/prompt_fading.dart';
import '../shared/dashboard.dart';
import '../shared/widgets.dart';

class TargetEditorScreen extends StatefulWidget {
  final String targetId;
  const TargetEditorScreen({super.key, required this.targetId});
  @override
  State<TargetEditorScreen> createState() => _TargetEditorScreenState();
}

class _TargetEditorScreenState extends State<TargetEditorScreen> {
  Target? _t;
  final _title = TextEditingController();
  final _desc = TextEditingController();
  final _fields = TextEditingController();
  List<String> _ladder = [];
  Set<String> _enabledLevels = {};
  int _itemCount = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final repo = context.read<AppState>().repo;
    final t = await repo.target(widget.targetId);
    if (t == null || !mounted) return;
    final n = (await repo.resolveTargetItems(t)).length;
    setState(() {
      _t = t;
      _title.text = t.titleAr;
      _desc.text = t.descriptionAr;
      _fields.text = t.fieldSizes.join(',');
      final enabled = t.promptLadder.where((c) => c != kIndependent).toList();
      _ladder = [...enabled, ...kAllPromptCodes.where((c) => c != kIndependent && !enabled.contains(c))];
      _enabledLevels = enabled.toSet();
      _itemCount = n;
    });
  }

  void _set(Target t) => setState(() => _t = t);

  Future<void> _save() async {
    final t = _t!;
    final sizes = _fields.text.split(RegExp(r'[,،\s]+')).map(int.tryParse).whereType<int>().where((n) => n >= 1 && n <= 6).toList();
    if (sizes.isEmpty) return toast(context, 'أدخل عدد الخيارات بشكل صحيح، مثل 2,3,5');
    final ladder = [..._ladder.where(_enabledLevels.contains), kIndependent];
    final start = ladder.contains(t.startPrompt) ? t.startPrompt : ladder.first;
    final nt = t.copyWith(
      titleAr: _title.text.trim().isEmpty ? t.titleAr : _title.text.trim(),
      descriptionAr: _desc.text.trim(),
      fieldSizes: t.skillId == 'tact' ? [1] : sizes,
      promptLadder: ladder,
      startPrompt: start,
    );
    await context.read<AppState>().repo.updateTarget(nt);
    if (mounted) {
      toast(context, 'حُفظ الهدف');
      Navigator.pop(context);
    }
  }

  Future<void> _pickItems() async {
    final t = _t!;
    final repo = context.read<AppState>().repo;
    final all = (await repo.items(t.childId)).where((i) => i.skillIds.contains(t.skillId)).toList();
    final selected = (await repo.targetItemIds(t.id)).toSet();
    if (!mounted) return;
    final r = await Navigator.push<List<String>>(
        context, MaterialPageRoute(builder: (_) => _ItemPicker(items: all, selected: selected)));
    if (r != null) {
      await repo.setTargetItems(t.id, r);
      _load();
    }
  }

  Widget _stepper(String label, int value, int min, int max, ValueChanged<int> on, {String? hint}) => ListTile(
        title: Text(label),
        subtitle: hint == null ? null : Text(hint, style: const TextStyle(fontSize: 12)),
        trailing: Row(mainAxisSize: MainAxisSize.min, children: [
          IconButton(onPressed: value > min ? () => on(value - 1) : null, icon: const Icon(Icons.remove_circle_outline)),
          SizedBox(width: 36, child: Text('$value', textAlign: TextAlign.center, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700))),
          IconButton(onPressed: value < max ? () => on(value + 1) : null, icon: const Icon(Icons.add_circle_outline)),
        ]),
      );

  @override
  Widget build(BuildContext context) {
    final t = _t;
    if (t == null) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final m = t.mastery;
    final ladderNow = [..._ladder.where(_enabledLevels.contains), kIndependent];
    return Scaffold(
      appBar: AppBar(
        title: const Text('ضبط الهدف'),
        actions: [
          IconButton(
            tooltip: 'التقرير',
            icon: const Icon(Icons.insights_outlined),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => TargetReportScreen(targetId: t.id, specialist: true))),
          ),
          IconButton(
            tooltip: 'حذف الهدف',
            icon: const Icon(Icons.delete_outline),
            onPressed: () async {
              final ok = await confirmDialog(context, title: 'حذف الهدف', body: 'ستُحذف جلسات هذا الهدف وبياناته نهائيًا. يمكنك بدلًا من ذلك إيقافه مؤقتًا.', confirm: 'حذف', danger: true);
              if (!ok || !context.mounted) return;
              await context.read<AppState>().repo.deleteTarget(t.id);
              if (context.mounted) Navigator.pop(context);
            },
          ),
        ],
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(padding: const EdgeInsets.all(12), child: FilledButton(onPressed: _save, child: const Text('حفظ التغييرات'))),
      ),
      body: ListView(padding: readablePadding(context, const EdgeInsets.all(16)), children: [
        TextField(controller: _title, decoration: const InputDecoration(labelText: 'عنوان الهدف')),
        const SizedBox(height: 10),
        TextField(controller: _desc, maxLines: 3, decoration: const InputDecoration(labelText: 'وصف وآلية التدريب')),
        const SectionTitle('الحالة'),
        Card(
          child: Column(children: [
            SwitchListTile(
              title: const Text('هدف نشط'),
              subtitle: const Text('إيقافه يخفيه من جلسات ولي الأمر'),
              value: t.status == TargetStatus.active,
              onChanged: (v) => _set(t.copyWith(status: v ? TargetStatus.active : TargetStatus.paused)),
            ),
            SwitchListTile(
              title: const Text('متاح لولي الأمر'),
              value: t.enabledForParent,
              onChanged: (v) => _set(t.copyWith(enabledForParent: v)),
            ),
          ]),
        ),
        const SectionTitle('التجارب'),
        Card(
          child: Column(children: [
            _stepper('عدد التجارب في الجلسة', t.trialsPerSession, 3, 40, (v) => _set(t.copyWith(trialsPerSession: v))),
            _stepper('مهلة انتظار الاستجابة (ثانية)', t.waitSeconds, 2, 30, (v) => _set(t.copyWith(waitSeconds: v))),
            if (t.skillId != 'tact')
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
                child: TextField(
                  controller: _fields,
                  keyboardType: TextInputType.text,
                  decoration: const InputDecoration(
                    labelText: 'عدد الخيارات (تدرج مفصول بفواصل)',
                    helperMaxLines: 3,
                    helperText: 'مثال المطابقة: 2,3,5 — ينتقل الطفل للمرحلة التالية بعد جلسة تحقق معيار النسبة',
                  ),
                ),
              ),
            if (t.itemSource == 'custom')
              ListTile(
                leading: const Icon(Icons.collections_outlined),
                title: Text('البنود التدريبية ($_itemCount)'),
                trailing: const Icon(Icons.chevron_left),
                onTap: _pickItems,
              )
            else
              ListTile(
                leading: const Icon(Icons.collections_outlined),
                title: Text('البنود: $_itemCount'),
                subtitle: Text(t.itemSource == 'reinforcers'
                    ? 'تُؤخذ من معززات الطفل المفعّلة (يحددها ولي الأمر)'
                    : 'تُؤخذ من البنود التي لها صورة حقيقية في المكتبة'),
              ),
          ]),
        ),
        const SectionTitle('التلقين والتلاشي'),
        Card(
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
              child: SegmentedButton<PromptOrder>(
                segments: const [
                  ButtonSegment(value: PromptOrder.mostToLeast, label: Text('من الأكثر إلى الأقل')),
                  ButtonSegment(value: PromptOrder.leastToMost, label: Text('من الأقل إلى الأكثر')),
                ],
                selected: {t.promptOrder},
                onSelectionChanged: (s) => _set(t.copyWith(promptOrder: s.first)),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
              child: Text(
                t.promptOrder == PromptOrder.mostToLeast
                    ? 'تبدأ التجربة بمستوى التلقين الحالي، وتقل المساعدة بعد نجاحات متتالية وترجع خطوة بعد أخطاء متتالية.'
                    : 'تبدأ كل تجربة دون مساعدة، وعند الخطأ أو انتهاء المهلة تُضاف مساعدة أكبر داخل التجربة نفسها.',
                style: const TextStyle(fontSize: 12, color: Brand.muted),
              ),
            ),
            const Padding(
              padding: EdgeInsets.fromLTRB(16, 14, 16, 4),
              child: Text('سلم التلقين (اسحب لإعادة الترتيب، من الأكثر مساعدة إلى الأقل)', style: TextStyle(fontWeight: FontWeight.w600)),
            ),
            ReorderableListView(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              buildDefaultDragHandles: false,
              onReorderItem: (a, b) => setState(() {
                final x = _ladder.removeAt(a);
                _ladder.insert(b, x);
              }),
              children: [
                for (var i = 0; i < _ladder.length; i++)
                  ListTile(
                    key: ValueKey(_ladder[i]),
                    leading: Checkbox(
                      value: _enabledLevels.contains(_ladder[i]),
                      onChanged: (v) => setState(() => v == true ? _enabledLevels.add(_ladder[i]) : _enabledLevels.remove(_ladder[i])),
                    ),
                    title: Text(promptNameAr(_ladder[i])),
                    trailing: ReorderableDragStartListener(index: i, child: const Icon(Icons.drag_handle)),
                  ),
              ],
            ),
            const ListTile(leading: Icon(Icons.check_circle, color: Brand.teal), title: Text('استجابة مستقلة (دائمًا الأخيرة)')),
            if (t.promptOrder == PromptOrder.mostToLeast) ...[
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: DropdownButtonFormField<String>(
                  initialValue: ladderNow.contains(t.startPrompt) ? t.startPrompt : ladderNow.first,
                  decoration: const InputDecoration(labelText: 'مستوى التلقين عند البدء'),
                  items: [for (final c in ladderNow) DropdownMenuItem(value: c, child: Text(promptNameAr(c)))],
                  onChanged: (v) => _set(t.copyWith(startPrompt: v)),
                ),
              ),
              SwitchListTile(
                title: const Text('الاستمرار من آخر مستوى في الجلسة السابقة'),
                value: t.carryOverPrompt,
                onChanged: (v) => _set(t.copyWith(carryOverPrompt: v)),
              ),
              _stepper('تقليل المساعدة بعد نجاحات متتالية', t.advanceAfterCorrect, 1, 10, (v) => _set(t.copyWith(advanceAfterCorrect: v))),
              _stepper('الرجوع خطوة بعد أخطاء متتالية', t.stepBackAfterErrors, 1, 5, (v) => _set(t.copyWith(stepBackAfterErrors: v)),
                  hint: 'الافتراضي حسب المنهج: خطآن'),
            ],
          ]),
        ),
        const SectionTitle('الاستراحة'),
        Card(
          child: Column(children: [
            _stepper('اقتراح استراحة بعد أخطاء متتالية', t.breakAfterErrors, 0, 10, (v) => _set(t.copyWith(breakAfterErrors: v)), hint: '0 = معطل'),
            _stepper('اقتراح استراحة بعد عدم استجابة متتالية', t.breakAfterNoResponse, 0, 10, (v) => _set(t.copyWith(breakAfterNoResponse: v)), hint: '0 = معطل'),
          ]),
        ),
        const SectionTitle('معيار الإتقان'),
        Card(
          child: Column(children: [
            _stepper('النسبة المطلوبة (استجابات صحيحة مستقلة) %', m.percent.round(), 50, 100,
                (v) => _set(t.copyWith(mastery: MasteryCriteria(percent: v.toDouble(), consecutiveSessions: m.consecutiveSessions, minTrainers: m.minTrainers, minTrialsPerSession: m.minTrialsPerSession, minDistinctIndependent: m.minDistinctIndependent)))),
            _stepper('عدد الجلسات المتتالية', m.consecutiveSessions, 1, 10,
                (v) => _set(t.copyWith(mastery: MasteryCriteria(percent: m.percent, consecutiveSessions: v, minTrainers: m.minTrainers, minTrialsPerSession: m.minTrialsPerSession, minDistinctIndependent: m.minDistinctIndependent)))),
            _stepper('أقل عدد مدربين مختلفين', m.minTrainers, 1, 5,
                (v) => _set(t.copyWith(mastery: MasteryCriteria(percent: m.percent, consecutiveSessions: m.consecutiveSessions, minTrainers: v, minTrialsPerSession: m.minTrialsPerSession, minDistinctIndependent: m.minDistinctIndependent)))),
            _stepper('أقل عدد تجارب لاحتساب الجلسة', m.minTrialsPerSession, 1, 40,
                (v) => _set(t.copyWith(mastery: MasteryCriteria(percent: m.percent, consecutiveSessions: m.consecutiveSessions, minTrainers: m.minTrainers, minTrialsPerSession: v, minDistinctIndependent: m.minDistinctIndependent)))),
            _stepper('عناصر مختلفة يُستجاب لها باستقلال', m.minDistinctIndependent, 0, 40,
                (v) => _set(t.copyWith(mastery: MasteryCriteria(percent: m.percent, consecutiveSessions: m.consecutiveSessions, minTrainers: m.minTrainers, minTrialsPerSession: m.minTrialsPerSession, minDistinctIndependent: v))),
                hint: 'الطلب: 10 معززات مختلفة دون تلقين'),
          ]),
        ),
        const SizedBox(height: 24),
      ]),
    );
  }
}

class _ItemPicker extends StatefulWidget {
  final List<Item> items;
  final Set<String> selected;
  const _ItemPicker({required this.items, required this.selected});
  @override
  State<_ItemPicker> createState() => _ItemPickerState();
}

class _ItemPickerState extends State<_ItemPicker> {
  late final Set<String> _sel = {...widget.selected};
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text('البنود (${_sel.length})')),
        bottomNavigationBar: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: FilledButton(
              onPressed: () => Navigator.pop(context, [for (final i in widget.items) if (_sel.contains(i.id)) i.id]),
              child: const Text('اعتماد'),
            ),
          ),
        ),
        body: GridView.builder(
          padding: const EdgeInsets.all(12),
          gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(maxCrossAxisExtent: 130, mainAxisSpacing: 8, crossAxisSpacing: 8, childAspectRatio: .85),
          itemCount: widget.items.length,
          itemBuilder: (c, i) {
            final it = widget.items[i];
            final on = _sel.contains(it.id);
            return Material(
              color: on ? Brand.tealSoft : Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: on ? Brand.teal : Brand.line, width: on ? 2 : 1)),
              child: InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: () => setState(() => on ? _sel.remove(it.id) : _sel.add(it.id)),
                child: Padding(
                  padding: const EdgeInsets.all(8),
                  child: Column(children: [
                    Expanded(child: ItemImageView(it.primaryImage)),
                    Text(it.labelAr, overflow: TextOverflow.ellipsis),
                  ]),
                ),
              ),
            );
          },
        ),
      );
}
