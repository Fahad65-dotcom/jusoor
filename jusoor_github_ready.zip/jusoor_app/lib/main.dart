import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import 'app.dart';
import 'core/app_state.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // تراخيص المواد المضمنة (تظهر في صفحة التراخيص).
  LicenseRegistry.addLicense(() async* {
    yield LicenseEntryWithLineBreaks(['Tajawal'], await rootBundle.loadString('assets/fonts/OFL.txt'));
    yield LicenseEntryWithLineBreaks(['Microsoft Fluent Emoji'], await rootBundle.loadString('assets/images/FLUENT_EMOJI_LICENSE.txt'));
  });
  await SystemChrome.setPreferredOrientations(DeviceOrientation.values);
  final state = AppState();
  runApp(ChangeNotifierProvider.value(value: state, child: const JusoorApp()));
  await state.init();
}
