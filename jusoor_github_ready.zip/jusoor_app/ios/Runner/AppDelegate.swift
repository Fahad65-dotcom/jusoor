import Flutter
import UIKit

@main
@objc class AppDelegate: FlutterAppDelegate, FlutterImplicitEngineDelegate {
  override func application(
    _ application: UIApplication,
    didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
  ) -> Bool {
    return super.application(application, didFinishLaunchingWithOptions: launchOptions)
  }

  func didInitializeImplicitFlutterEngine(_ engineBridge: FlutterImplicitEngineBridge) {
    GeneratedPluginRegistrant.register(with: engineBridge.pluginRegistry)

    // قناة وضع الطفل: على iOS لا يمكن للتطبيق قفل الجهاز بنفسه؛ نستخدم
    // "الوصول الموجّه" (Guided Access) الذي يفعّله ولي الأمر من الإعدادات،
    // ونتحقق من حالته لعرض التنبيه المناسب.
    if let registrar = engineBridge.pluginRegistry.registrar(forPlugin: "JusoorKiosk") {
      let channel = FlutterMethodChannel(name: "sa.jusoor/kiosk", binaryMessenger: registrar.messenger())
      channel.setMethodCallHandler { call, result in
        switch call.method {
        case "isGuidedAccessOn":
          result(UIAccessibility.isGuidedAccessEnabled)
        case "startLockTask":
          UIApplication.shared.isIdleTimerDisabled = true
          result(UIAccessibility.isGuidedAccessEnabled)
        case "stopLockTask":
          UIApplication.shared.isIdleTimerDisabled = false
          result(true)
        default:
          result(FlutterMethodNotImplemented)
        }
      }
    }
  }
}
