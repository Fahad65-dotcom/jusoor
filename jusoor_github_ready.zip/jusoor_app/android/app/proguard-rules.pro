# SQLCipher
-keep class net.sqlcipher.** { *; }
-keep class net.zetetic.** { *; }
-dontwarn net.sqlcipher.**
# Flutter deferred components (غير مستخدمة)
-dontwarn com.google.android.play.core.**
