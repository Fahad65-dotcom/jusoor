// أدوات مشتركة لاختبارات الواجهات: قاعدة بيانات FFI حقيقية، خطوط عربية،
// وتعطيل قنوات الصوت/التسجيل غير المتاحة في بيئة الاختبار.
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:jusoor/core/app_state.dart';
import 'package:jusoor/core/theme.dart';
import 'package:jusoor/services/security.dart';
import 'package:provider/provider.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

class FakeKeys extends DbKeyStore {
  String? _k;
  @override
  Future<String> getOrCreate() async => _k ??= 'test-key';
  @override
  Future<String?> read() async => _k;
  @override
  Future<void> write(String key) async => _k = key;
  @override
  Future<void> clear() async => _k = null;
}

Future<void> loadFonts() async {
  final t = FontLoader('Tajawal');
  for (final w in ['Regular', 'Medium', 'Bold']) {
    t.addFont(Future.value(ByteData.sublistView(File('assets/fonts/Tajawal-$w.ttf').readAsBytesSync())));
  }
  await t.load();
  final flutterRoot = File(Platform.resolvedExecutable).parent.parent.parent.parent.parent.parent.path;
  final icons = File('$flutterRoot/bin/cache/artifacts/material_fonts/MaterialIcons-Regular.otf');
  if (icons.existsSync()) {
    final m = FontLoader('MaterialIcons')..addFont(Future.value(ByteData.sublistView(icons.readAsBytesSync())));
    await m.load();
  }
}

void mockPlatformChannels() {
  final m = TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;
  for (final ch in [
    'xyz.luan/audioplayers',
    'xyz.luan/audioplayers.global',
    'com.llfbandit.record/messages',
    'sa.jusoor/kiosk',
    'plugins.it_nomads.com/flutter_secure_storage',
    'xyz.luan/audioplayers.global/events',
    'xyz.luan/audioplayers/events/fx',
    'xyz.luan/audioplayers/events/voice',
    'xyz.luan/audioplayers/events/praise',
  ]) {
    m.setMockMethodCallHandler(MethodChannel(ch), (call) async => null);
  }
}

Future<AppState> newState() async {
  sqfliteFfiInit();
  final s = AppState(
    keys: FakeKeys(),
    dbPathOverride: () async => inMemoryDatabasePath,
    opener: (path, pw, o) => databaseFactoryFfi.openDatabase(path, options: o),
  );
  await s.init();
  return s;
}

Widget wrap(AppState s, Widget child) => ChangeNotifierProvider.value(
      value: s,
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: buildTheme(),
        locale: const Locale('ar'),
        supportedLocales: const [Locale('ar')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        builder: (c, w) => Directionality(textDirection: TextDirection.rtl, child: w!),
        home: child,
      ),
    );

/// ينتظر عمليات قاعدة البيانات الحقيقية ثم يعيد رسم الإطارات.
Future<void> settle(WidgetTester t, {int rounds = 6}) async {
  for (var i = 0; i < rounds; i++) {
    await t.runAsync(() => Future<void>.delayed(const Duration(milliseconds: 60)));
    await t.pump(const Duration(milliseconds: 50));
  }
}
