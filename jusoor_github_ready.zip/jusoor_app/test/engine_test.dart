import 'dart:math';

import 'package:flutter_test/flutter_test.dart';
import 'package:jusoor/data/models.dart';
import 'package:jusoor/engine/dtt_engine.dart';
import 'package:jusoor/engine/prompt_fading.dart';

const ladder = ['full', 'partial', 'verbal', 'visual', 'independent'];

EngineConfig cfg(EngineKind k,
        {int trials = 10, int field = 3, String start = 'partial', PromptOrder order = PromptOrder.mostToLeast, int bonus = 5}) =>
    EngineConfig(
      kind: k,
      trialsPerSession: trials,
      fieldSize: field,
      waitSeconds: 5,
      ladder: ladder,
      startPrompt: start,
      order: order,
      bonusEvery: bonus,
    );

final items = List.generate(20, (i) => 'i$i');

void main() {
  group('PromptFader — التلقين والتلاشي', () {
    test('يقل التلقين بعد نجاحين متتاليين', () {
      final f = PromptFader(ladder: ladder, start: 'full');
      expect(f.record(correct: true), FadeChange.none);
      expect(f.record(correct: true), FadeChange.lessHelp);
      expect(f.current, 'partial');
    });
    test('يرجع خطوة بعد خطأين متتاليين', () {
      final f = PromptFader(ladder: ladder, start: 'visual');
      f.record(correct: false);
      expect(f.current, 'visual');
      expect(f.record(correct: false), FadeChange.moreHelp);
      expect(f.current, 'verbal');
    });
    test('خطأ واحد ثم نجاح لا يرجع المستوى', () {
      final f = PromptFader(ladder: ladder, start: 'visual');
      f.record(correct: false);
      f.record(correct: true);
      f.record(correct: false);
      expect(f.current, 'visual');
    });
    test('لا يتجاوز الاستقلال ولا أعلى مساعدة', () {
      final f = PromptFader(ladder: ladder, start: 'independent');
      for (var i = 0; i < 6; i++) { f.record(correct: true); }
      expect(f.current, 'independent');
      final g = PromptFader(ladder: ladder, start: 'full');
      for (var i = 0; i < 6; i++) { g.record(correct: false); }
      expect(g.current, 'full');
    });
    test('السلم ينتهي دائمًا بالاستجابة المستقلة ويحترم ترتيب الأخصائي', () {
      final f = PromptFader(ladder: ['verbal', 'full'], start: 'verbal');
      expect(f.ladder, ['verbal', 'full', 'independent']);
    });
  });

  group('DttSession — محرك التجارب المنفصلة', () {
    test('ينتج العدد المطلوب من التجارب ثم يتوقف', () {
      final s = DttSession(config: cfg(EngineKind.listener), items: items, random: Random(1));
      var n = 0;
      TrialPlan? p;
      while ((p = s.next()) != null) {
        n++;
        s.submit(p!, outcome: TrialOutcome.correct, promptUsed: p.prompt);
      }
      expect(n, 10);
      expect(s.isFinished, isTrue);
    });

    test('المستمع: ثلاث خيارات تتضمن الصحيح ودون تكرار', () {
      final s = DttSession(config: cfg(EngineKind.listener), items: items, random: Random(2));
      for (var i = 0; i < 10; i++) {
        final p = s.next()!;
        expect(p.choices.length, 3);
        expect(p.choices.toSet().length, 3);
        expect(p.choices, contains(p.stimulusId));
        s.submit(p, outcome: TrialOutcome.correct, promptUsed: p.prompt);
      }
    });

    test('موضع الإجابة الصحيحة لا يتكرر أكثر من مرتين متتاليتين', () {
      final s = DttSession(config: cfg(EngineKind.matching, trials: 200, field: 3), items: items, random: Random(3));
      final pos = <int>[];
      for (var i = 0; i < 200; i++) {
        final p = s.next()!;
        pos.add(p.correctIndex);
        s.submit(p, outcome: TrialOutcome.correct, promptUsed: p.prompt);
      }
      for (var i = 2; i < pos.length; i++) {
        expect(pos[i] == pos[i - 1] && pos[i] == pos[i - 2], isFalse);
      }
    });

    test('كل البنود تُعرض قبل التكرار (تدوير المثيرات)', () {
      final s = DttSession(config: cfg(EngineKind.listener, trials: 20), items: items, random: Random(4));
      final seen = <String>{};
      for (var i = 0; i < 20; i++) {
        final p = s.next()!;
        seen.add(p.stimulusId);
        s.submit(p, outcome: TrialOutcome.correct, promptUsed: p.prompt);
      }
      expect(seen.length, 20);
    });

    test('تصحيح الخطأ: إعادة نفس المثير بتلقين أعلى ولا تُحتسب', () {
      final s = DttSession(config: cfg(EngineKind.listener, start: 'visual'), items: items, random: Random(5));
      final p = s.next()!;
      final fb = s.submit(p, outcome: TrialOutcome.incorrect, promptUsed: p.prompt);
      expect(fb.showCorrection, isTrue);
      final c = s.next()!;
      expect(c.isCorrection, isTrue);
      expect(c.stimulusId, p.stimulusId);
      expect(c.prompt, 'verbal');
      s.submit(c, outcome: TrialOutcome.correct, promptUsed: c.prompt);
      expect(s.completedTrials, 1);
    });

    test('الطلب: أي اختيار يُعد طلبًا صحيحًا ولا تصحيح', () {
      final s = DttSession(config: cfg(EngineKind.mand, field: 4, start: 'independent'), items: items.take(10).toList(), random: Random(6));
      final p = s.next()!;
      final other = p.choices.firstWhere((c) => c != p.stimulusId);
      expect(s.evaluateSelection(p, other), TrialOutcome.correct);
      final fb = s.submit(p, outcome: TrialOutcome.correct, promptUsed: 'independent');
      expect(fb.independent, isTrue);
      expect(fb.showCorrection, isFalse);
      expect(p.choices.length, 4);
    });

    test('التسمية: خيار واحد فقط', () {
      final s = DttSession(config: cfg(EngineKind.tact), items: items, random: Random(7));
      expect(s.next()!.choices.length, 1);
    });

    test('مكافأة إضافية كل N استجابات صحيحة', () {
      final s = DttSession(config: cfg(EngineKind.listener, bonus: 3), items: items, random: Random(8));
      final bonuses = <bool>[];
      for (var i = 0; i < 6; i++) {
        final p = s.next()!;
        bonuses.add(s.submit(p, outcome: TrialOutcome.correct, promptUsed: p.prompt).bonusDue);
      }
      expect(bonuses, [false, false, true, false, false, true]);
    });

    test('اقتراح استراحة بعد عدم استجابة متكرر', () {
      final s = DttSession(config: cfg(EngineKind.listener), items: items, random: Random(9));
      var brk = false;
      for (var i = 0; i < 3; i++) {
        final p = s.next()!;
        if (p.isCorrection) { s.submit(p, outcome: TrialOutcome.correct, promptUsed: p.prompt); continue; }
        brk = s.submit(p, outcome: TrialOutcome.noResponse, promptUsed: p.prompt).breakSuggested;
        s.next(); // تجربة التصحيح
      }
      expect(brk, isTrue);
    });

    test('نمط من الأقل إلى الأكثر: يبدأ مستقلًا ويصعّد داخل التجربة', () {
      final s = DttSession(config: cfg(EngineKind.listener, order: PromptOrder.leastToMost), items: items, random: Random(10));
      final p = s.next()!;
      expect(p.prompt, 'independent');
      expect(s.escalate('independent'), 'visual');
      expect(s.escalate('full'), isNull);
    });

    test('المطابقة: عدد الخيارات لا يتجاوز البنود', () {
      final s = DttSession(config: cfg(EngineKind.matching, field: 5), items: ['a', 'b'], random: Random(11));
      expect(s.next()!.choices.length, 2);
    });
  });
}
