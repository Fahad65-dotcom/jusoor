// اختبارات طبقة البيانات على SQLite حقيقية (FFI) بنفس المخطط والمحتوى.
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:jusoor/data/database.dart';
import 'package:jusoor/data/models.dart';
import 'package:jusoor/data/repository.dart';
import 'package:jusoor/services/backup_service.dart';
import 'package:jusoor/services/security.dart';
import 'package:sqflite_common/utils/utils.dart' show firstIntValue;
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  sqfliteFfiInit();
  final curriculum = jsonDecode(File('assets/content/curriculum.json').readAsStringSync()) as Map<String, dynamic>;
  late Database db;
  late Repository repo;

  setUp(() async {
    db = await databaseFactoryFfi.openDatabase(inMemoryDatabasePath, options: AppDatabase.options(curriculum));
    repo = Repository(db);
  });
  tearDown(() => db.close());

  test('المنهج: 8 مهارات و4 منها متاحة في النسخة الأولى', () async {
    final skills = await repo.skills();
    expect(skills.length, 8);
    expect(skills.where((s) => s.isAvailable).map((s) => s.id).toSet(), {'mand', 'listener', 'tact', 'matching'});
    expect((await repo.promptLevels()).length, 5);
  });

  test('إنشاء طفل يولّد أهداف المنهج المبتدئ ببنوده', () async {
    final c = await repo.createChild(name: 'سارة');
    final targets = await repo.targets(c.id);
    expect(targets.length, greaterThanOrEqualTo(4));
    final listener = targets.firstWhere((t) => t.skillId == 'listener');
    expect(listener.mastery.percent, 80);
    expect(listener.mastery.consecutiveSessions, 3);
    expect((await repo.resolveTargetItems(listener)).length, 20);
    final match = targets.firstWhere((t) => t.skillId == 'matching');
    expect(match.mastery.percent, 90);
    expect(match.mastery.consecutiveSessions, 2);
    expect(match.fieldSizes, [2, 3, 5]);
    final tact = targets.firstWhere((t) => t.skillId == 'tact');
    expect(tact.mastery.minTrainers, greaterThan(1));
    expect(listener.stepBackAfterErrors, 2);
  });

  test('تسجيل التجارب يحفظ كل الحقول ويحذف الطفل بالكامل', () async {
    final c = await repo.createChild(name: 'علي');
    final t = (await repo.targets(c.id)).firstWhere((t) => t.skillId == 'listener');
    final items = await repo.resolveTargetItems(t);
    final s = await repo.startSession(childId: c.id, targetId: t.id, trainerName: 'الأم', plannedMinutes: 5);
    await repo.insertTrial(
      TrialRecord(
        id: newId(), sessionId: s.id, childId: c.id, targetId: t.id, skillId: 'listener', trialNumber: 1,
        stimulusItemId: items.first.id, stimulusLabel: items.first.labelAr,
        choiceItemIds: items.take(3).map((e) => e.id).toList(), fieldSize: 3, promptCode: 'independent',
        isCorrection: false, outcome: TrialOutcome.correct, independent: true,
        selectedItemId: items.first.id, latencyMs: 1200, presentedAt: DateTime.now().millisecondsSinceEpoch, scoredBy: 'auto',
      ),
      [ResponseEvent(kind: 'touch', selectedItemId: items.first.id, outcome: TrialOutcome.correct, promptCode: 'independent', latencyMs: 1200)],
    );
    await repo.endSession(s.id, 'completed');
    final trials = await repo.trials(childId: c.id);
    expect(trials.single.latencyMs, 1200);
    expect(trials.single.independent, isTrue);
    expect(trials.single.promptCode, 'independent');

    await repo.deleteChildCompletely(c.id);
    for (final table in ['children', 'targets', 'sessions', 'trials', 'responses', 'reinforcers']) {
      final n = firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM $table'));
      expect(n, 0, reason: table);
    }
  });

  test('لا تُخزن قيم مشتقة: لا أعمدة للنسب أو الإتقان', () async {
    for (final table in ['sessions', 'targets']) {
      final cols = (await db.rawQuery('PRAGMA table_info($table)')).map((r) => r['name'] as String);
      expect(cols.any((c) => c.contains('percent') && table == 'sessions'), isFalse);
      expect(cols.any((c) => c.contains('mastered')), isFalse);
    }
  });

  test('رمز PIN يُخزن مجزّأً ويُتحقق منه', () {
    final salt = PinHasher.newSalt();
    final h = PinHasher.hash('2468', salt);
    expect(h, isNot(contains('2468')));
    expect(PinHasher.verify('2468', salt, h), isTrue);
    expect(PinHasher.verify('1111', salt, h), isFalse);
  });

  test('النسخة الاحتياطية مشفرة وتُرفض بكلمة مرور خاطئة', () async {
    final plain = Uint8List.fromList(utf8.encode('بيانات اختبار'));
    final enc = await BackupCodec.encrypt(plain, 'كلمة-سر-قوية');
    expect(utf8.decode(enc, allowMalformed: true).contains('بيانات'), isFalse);
    expect(await BackupCodec.decrypt(enc, 'كلمة-سر-قوية'), plain);
    expect(() => BackupCodec.decrypt(enc, 'خطأ'), throwsA(isA<BackupException>()));
  });

  test('نسخ احتياطي واستعادة كاملة لقاعدة البيانات والوسائط', () async {
    final tmp = await Directory.systemTemp.createTemp('jusoor_bk');
    final dbPath = '${tmp.path}/app.db';
    final media = Directory('${tmp.path}/media')..createSync();
    File('${media.path}/photo.jpg').writeAsBytesSync([1, 2, 3, 4]);
    final fdb = await databaseFactoryFfi.openDatabase(dbPath, options: AppDatabase.options(curriculum));
    await Repository(fdb).createChild(name: 'نوف');
    await fdb.close();

    final zip = BackupCodec.pack(dbFile: File(dbPath), mediaDir: media, dbKey: 'k1', schemaVersion: kSchemaVersion);
    final enc = await BackupCodec.encrypt(zip, 'سر-النسخة');

    // جهاز جديد فارغ
    final tmp2 = await Directory.systemTemp.createTemp('jusoor_rs');
    final dbPath2 = '${tmp2.path}/app.db';
    final media2 = Directory('${tmp2.path}/media');
    final r = BackupCodec.unpack(await BackupCodec.decrypt(enc, 'سر-النسخة'), dbFile: File(dbPath2), mediaDir: media2);
    expect(r.dbKey, 'k1');
    expect(File('${media2.path}/photo.jpg').readAsBytesSync(), [1, 2, 3, 4]);
    final rdb = await databaseFactoryFfi.openDatabase(dbPath2, options: AppDatabase.options(curriculum));
    final kids = await Repository(rdb).children();
    expect(kids.single.name, 'نوف');
    expect((await Repository(rdb).targets(kids.single.id)), isNotEmpty);
    await rdb.close();
    await tmp.delete(recursive: true);
    await tmp2.delete(recursive: true);
  });
}
