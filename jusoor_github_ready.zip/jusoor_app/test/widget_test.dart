// اختبارات واجهة على قاعدة بيانات حقيقية: الاتجاه RTL، لوحة الرمز،
// وتسجيل تجربة فعلية من شاشة جلسة الطفل.
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:jusoor/data/models.dart';
import 'package:jusoor/features/child/session_screen.dart';
import 'package:jusoor/features/onboarding/onboarding_screen.dart';
import 'package:jusoor/features/shared/pin_pad.dart';

import 'support/harness.dart';

void main() {
  setUpAll(mockPlatformChannels);

  testWidgets('الواجهة عربية واتجاهها من اليمين لليسار', (t) async {
    final s = (await t.runAsync(newState))!;
    await t.pumpWidget(wrap(s, const OnboardingScreen()));
    await settle(t);
    final ctx = t.element(find.byType(OnboardingScreen));
    expect(Directionality.of(ctx), TextDirection.rtl);
    expect(find.textContaining('جسور'), findsWidgets);
  });

  testWidgets('لوحة الرمز ترسل الأرقام الأربعة', (t) async {
    String? got;
    final s = (await t.runAsync(newState))!;
    await t.pumpWidget(wrap(s, Scaffold(body: PinPad(title: 'أدخل الرمز', onSubmit: (p) async { got = p; return true; }))));
    for (final d in ['1', '9', '7', '3']) {
      await t.tap(find.text(d));
      await t.pump();
    }
    await t.pump(const Duration(milliseconds: 300));
    expect(got, '1973');
  });

  testWidgets('جلسة الاستماع تسجل التجربة من استجابة الطفل', (t) async {
    t.view.physicalSize = const Size(1600, 1000);
    t.view.devicePixelRatio = 1;
    addTearDown(t.view.reset);
    final s = (await t.runAsync(newState))!;
    final child = (await t.runAsync(() => s.repo.createChild(name: 'ريم')))!;
    final target = (await t.runAsync(() => s.repo.targets(child.id)))!.firstWhere((x) => x.skillId == 'listener');
    final skill = (await t.runAsync(() => s.repo.skills()))!.firstWhere((x) => x.id == 'listener');
    await t.pumpWidget(wrap(
        s, ChildSessionScreen(child: child, target: target, skill: skill, trainerName: 'الأم', minutes: 5, random: Random(3))));
    await settle(t);
    expect(find.textContaining('هيا يا ريم'), findsOneWidget);
    await t.tap(find.byIcon(Icons.play_arrow_rounded));
    await settle(t);
    expect(find.textContaining('أين'), findsWidgets);
    // يلمس الطفل إحدى الصور الثلاث.
    final cards = find.byWidgetPredicate((w) => w.key is ValueKey<String> && (w.key as ValueKey<String>).value.startsWith('1-'));
    expect(cards, findsNWidgets(3));
    await t.tap(cards.first);
    await settle(t, rounds: 12);
    await t.pump(const Duration(seconds: 3));
    await settle(t, rounds: 12);
    final trials = (await t.runAsync(() => s.repo.trials(childId: child.id)))!;
    expect(trials, isNotEmpty);
    final first = trials.firstWhere((x) => x.trialNumber == 1 && !x.isCorrection);
    expect(first.fieldSize, 3);
    expect(first.choiceItemIds.length, 3);
    expect(first.latencyMs, isNotNull);
    expect(first.outcome, isNot(TrialOutcome.noResponse));
    await t.pumpWidget(const SizedBox());
    await settle(t);
  });

  testWidgets('جلسة المطابقة تعرض النموذج والخيارات وتقبل اللمس', (t) async {
    t.view.physicalSize = const Size(1600, 1000);
    t.view.devicePixelRatio = 1;
    addTearDown(t.view.reset);
    final s = (await t.runAsync(newState))!;
    final child = (await t.runAsync(() => s.repo.createChild(name: 'ريم')))!;
    final target = (await t.runAsync(() => s.repo.targets(child.id)))!.firstWhere((x) => x.skillId == 'matching');
    final skill = (await t.runAsync(() => s.repo.skills()))!.firstWhere((x) => x.id == 'matching');
    await t.pumpWidget(wrap(
        s, ChildSessionScreen(child: child, target: target, skill: skill, trainerName: 'الأب', minutes: 5, random: Random(1))));
    await settle(t);
    await t.tap(find.byIcon(Icons.play_arrow_rounded));
    await settle(t);
    expect(t.takeException(), isNull);
    expect(find.byType(DragTarget<String>), findsNWidgets(2)); // تبدأ المطابقة بخيارين
    expect(find.byType(Draggable<String>), findsOneWidget);
    await t.tap(find.byType(DragTarget<String>).first);
    await settle(t, rounds: 12);
    await t.pump(const Duration(seconds: 3));
    await settle(t, rounds: 12);
    final trials = (await t.runAsync(() => s.repo.trials(childId: child.id)))!;
    expect(trials.where((x) => x.skillId == 'matching'), isNotEmpty);
    await t.pumpWidget(const SizedBox());
    await settle(t);
  });
}
