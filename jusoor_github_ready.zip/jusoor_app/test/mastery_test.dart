import 'package:flutter_test/flutter_test.dart';
import 'package:jusoor/data/models.dart';
import 'package:jusoor/engine/mastery.dart';
import 'package:jusoor/engine/metrics.dart';

int _t = 0;
TrialRecord tr(String session, {required bool correct, bool independent = true, bool correction = false, int field = 3, String item = 'x', String? selected, TrialOutcome? outcome}) =>
    TrialRecord(
      id: 't${_t++}', sessionId: session, childId: 'c', targetId: 'g', skillId: 'listener',
      trialNumber: _t, stimulusItemId: item, stimulusLabel: item, choiceItemIds: const [],
      fieldSize: field, promptCode: independent ? 'independent' : 'partial', isCorrection: correction,
      outcome: outcome ?? (correct ? TrialOutcome.correct : TrialOutcome.incorrect),
      independent: correct && independent, selectedItemId: selected, latencyMs: 1000,
      presentedAt: _t, scoredBy: 'auto');

SessionRecord ses(String id, int at, {String trainer = 'أ'}) => SessionRecord(
    id: id, childId: 'c', targetId: 'g', trainerName: trainer, startedAt: at, plannedMinutes: 7);

/// جلسة من 10 تجارب بعدد [ind] صحيحة مستقلة و[prompted] صحيحة بمساعدة والباقي أخطاء.
List<TrialRecord> block(String s, int ind, {int prompted = 0, int field = 3, int corrections = 0}) => [
      for (var i = 0; i < ind; i++) tr(s, correct: true, field: field, item: 'i$i'),
      for (var i = 0; i < prompted; i++) tr(s, correct: true, independent: false, field: field),
      for (var i = 0; i < 10 - ind - prompted; i++) tr(s, correct: false, field: field),
      for (var i = 0; i < corrections; i++) tr(s, correct: true, independent: false, correction: true, field: field),
    ];

void main() {
  test('حساب النسب من السجلات الأصلية واستبعاد التجارب التصحيحية', () {
    final st = PerformanceStats.fromTrials(block('s1', 6, prompted: 2, corrections: 2));
    expect(st.trials, 10);
    expect(st.correctPct, 80);
    expect(st.independentPct, 60);
    expect(st.promptedPct, 20);
    expect(st.errorPct, 20);
    expect(st.correctionTrials, 2);
  });

  const listener = MasteryCriteria(percent: 80, consecutiveSessions: 3);

  test('المستمع: 80% في ثلاث جلسات متتالية = متقن', () {
    final s = [ses('a', 1), ses('b', 2), ses('c', 3)];
    final t = [...block('a', 8), ...block('b', 9), ...block('c', 8)];
    final r = MasteryEvaluator.evaluate(SessionSummary.build(s, t), listener);
    expect(r.state, MasteryState.mastered);
  });

  test('جلسة أقل من 80% تكسر السلسلة', () {
    final s = [ses('a', 1), ses('b', 2), ses('c', 3), ses('d', 4)];
    final t = [...block('a', 8), ...block('b', 7), ...block('c', 9), ...block('d', 10)];
    final r = MasteryEvaluator.evaluate(SessionSummary.build(s, t), listener);
    expect(r.state, MasteryState.inProgress);
    expect(r.streak, 2);
  });

  test('الاستجابات بمساعدة لا تُحتسب للإتقان', () {
    final s = [ses('a', 1), ses('b', 2), ses('c', 3)];
    final t = [...block('a', 5, prompted: 5), ...block('b', 5, prompted: 5), ...block('c', 5, prompted: 5)];
    expect(MasteryEvaluator.evaluate(SessionSummary.build(s, t), listener).state, MasteryState.inProgress);
  });

  test('التسمية: يشترط أكثر من مدرب', () {
    const tact = MasteryCriteria(percent: 80, consecutiveSessions: 3, minTrainers: 2);
    final one = [ses('a', 1), ses('b', 2), ses('c', 3)];
    final t = [...block('a', 9), ...block('b', 9), ...block('c', 9)];
    expect(MasteryEvaluator.evaluate(SessionSummary.build(one, t), tact).state, MasteryState.inProgress);
    final two = [ses('a', 1), ses('b', 2, trainer: 'ب'), ses('c', 3)];
    expect(MasteryEvaluator.evaluate(SessionSummary.build(two, t), tact).state, MasteryState.mastered);
  });

  test('الطلب: يشترط 10 معززات مختلفة دون تلقين', () {
    const mand = MasteryCriteria(percent: 80, consecutiveSessions: 3, minDistinctIndependent: 10);
    final s = [ses('a', 1), ses('b', 2), ses('c', 3)];
    List<TrialRecord> m(String id, int from) => [
          for (var i = 0; i < 10; i++) tr(id, correct: true, selected: 'r${(from + i) % 6}'),
        ];
    var r = MasteryEvaluator.evaluate(SessionSummary.build(s, [...m('a', 0), ...m('b', 1), ...m('c', 2)], selectionBased: true), mand);
    expect(r.distinctItems, 6);
    expect(r.state, MasteryState.inProgress);
    List<TrialRecord> m2(String id) => [for (var i = 0; i < 10; i++) tr(id, correct: true, selected: 'r$i')];
    r = MasteryEvaluator.evaluate(SessionSummary.build(s, [...m2('a'), ...m2('b'), ...m2('c')], selectionBased: true), mand);
    expect(r.state, MasteryState.mastered);
  });

  test('المطابقة: التدرج 2→3→5 و90% في جلستين على خمسة خيارات', () {
    const match = MasteryCriteria(percent: 90, consecutiveSessions: 2);
    const sizes = [2, 3, 5];
    final s = [ses('a', 1), ses('b', 2), ses('c', 3), ses('d', 4)];
    final t = [...block('a', 9, field: 2), ...block('b', 10, field: 3), ...block('c', 9, field: 5), ...block('d', 10, field: 5)];
    final sum = SessionSummary.build(s, t);
    expect(MasteryEvaluator.currentFieldSize(sum.sublist(0, 1), sizes, 90), 3);
    expect(MasteryEvaluator.currentFieldSize(sum.sublist(0, 2), sizes, 90), 5);
    final r = MasteryEvaluator.evaluate(sum, match, fieldSizes: sizes);
    expect(r.state, MasteryState.mastered);
    // جلستان ناجحتان على 2 و3 فقط لا تكفيان.
    final early = MasteryEvaluator.evaluate(sum.sublist(0, 2), match, fieldSizes: sizes);
    expect(early.state, MasteryState.inProgress);
  });

  test('لا جلسات = لم يبدأ', () {
    expect(MasteryEvaluator.evaluate([], listener).state, MasteryState.notStarted);
  });
}
